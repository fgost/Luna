package ModeloDao;

import ModeloBeans.BeansProduto;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoProduto 
    {
        ConexaoBD conex = new ConexaoBD();
        BeansProduto mod = new BeansProduto();
    
        public void Salvar(BeansProduto mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("insert into produto (nome_pro,tipo_pro,preco_pro,qtd) values(?,?,?,?)");
                        pst.setString(1, mod.getNome());
                        pst.setString(2, mod.getTipo());
                        pst.setDouble(3, mod.getPreco());
                        pst.setInt(4, mod.getQtd());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao inserir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public void Editar(BeansProduto mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("update produto set nome_pro=?, preco_pro=?,tipo_pro=?,qtd=? where cod_pro = ?");
                        pst.setString(1, mod.getNome());
                        pst.setDouble(2, mod.getPreco()); 
                        pst.setString(3, mod.getTipo());
                        pst.setInt(4, mod.getQtd());
                        pst.setInt(5, mod.getCod());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados alterados com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao atualizar dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public void Excluir(BeansProduto mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("delete from produto where cod_pro=?");
                        pst.setInt(1, mod.getCod());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados excluidos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao excluir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public BeansProduto buscaProdutoNome(BeansProduto mod)
            {
                conex.conexao();
                conex.executaSql("select * from produto where nome_pro like '%"+mod.getPesquisa()+"%'");
                try 
                    {
                        conex.rs.first();
                        mod.setCod(conex.rs.getInt("cod_pro"));
                        mod.setNome(conex.rs.getString("nome_pro"));
                        mod.setPreco(conex.rs.getDouble("preco_pro"));
                        mod.setTipo(conex.rs.getString("tipo_pro"));
                        
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"produto não cadastrado"+ex);
                    }
                conex.desconecta();
                return mod;
            }
    }