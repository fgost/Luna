package ModeloDao;

import ModeloBeans.BeansSangria;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoSangria 
    {
        BeansSangria mod = new BeansSangria();
        ConexaoBD conex = new ConexaoBD();
        
        public void Salvar(BeansSangria mod)
            {
                conex.conexao();
                try 
                    {   
                        PreparedStatement pst = conex.con.prepareStatement("insert into sangria (nome,usuario,senha,datas,valor,motivo) values (?,?,?,?,?,?)");
                        pst.setString(1, mod.getNome());  
                        pst.setString(2,mod.getUsuario());
                        pst.setString(3, mod.getSenha());
                        pst.setDate(4,new java.sql.Date(mod.getData().getTime()));
                        pst.setDouble(5, mod.getSangria());
                        pst.setString(6,mod.getMotivo());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Gravado com Sucesso");
                    }     
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao Gravar!\n"+ex );
                    }
                conex.desconecta();
            }
    }