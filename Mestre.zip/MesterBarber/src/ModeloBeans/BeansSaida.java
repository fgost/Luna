package ModeloBeans;

public class BeansSaida 
    {
    private String pesquisa;
    private String nome;
    private String tipo;
    private String pesquisa1;
    private double preco;        
    private double pesquisa2;

    public String getPesquisa1(){
        return pesquisa1;}
    public void setPesquisa1(String pesquisa1){
        this.pesquisa1 = pesquisa1;}
    public double getPesquisa2(){
        return pesquisa2;}
    public void setPesquisa2(double pesquisa2){
        this.pesquisa2 = pesquisa2;}
    public String getPesquisa(){
        return pesquisa;}
    public void setPesquisa(String pesquisa){
        this.pesquisa = pesquisa;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public String getTipo(){
        return tipo;}
    public void setTipo(String tipo){
        this.tipo = tipo;}
    public double getPreco(){
        return preco;}
    public void setPreco(double preco){
        this.preco = preco;}}