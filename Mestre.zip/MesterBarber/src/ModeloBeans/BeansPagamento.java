package ModeloBeans;

public class BeansPagamento{
    private String mes;
    private String funicionario;
    private String cargo;
    private String servico1;
    private String servico2;
    private String servico3;
    private int qtd_cortes;
    private int qtd_servico1;
    private int qtd_servico2;
    private int qtd_servico3;
    private double total_servicos;
    private double descontos;
    private double total;
    private double preco_cortes;
    private double preco_servico1;
    private double preco_servico2;
    private double preco_servico3;

    public String getMes(){
        return mes;}
    public void setMes(String mes){
        this.mes = mes;}
    public String getFunicionario(){
        return funicionario;}
    public void setFunicionario(String funicionario){
        this.funicionario = funicionario;}
    public String getCargo(){
        return cargo;}
    public void setCargo(String cargo){
        this.cargo = cargo;}
    public int getQtd_cortes(){
        return qtd_cortes;}
    public void setQtd_cortes(int qtd_cortes){
        this.qtd_cortes = qtd_cortes;}
    public double getPreco_cortes(){
        return preco_cortes;}
    public void setPreco_cortes(double preco_cortes){
        this.preco_cortes = preco_cortes;}
    public String getServico1(){
        return servico1;}
    public void setServico1(String servico1){
        this.servico1 = servico1;}
    public String getServico2(){
        return servico2;}
    public void setServico2(String servico2){
        this.servico2 = servico2;}
    public String getServico3(){
        return servico3;}
    public void setServico3(String servico3){
        this.servico3 = servico3;}
    public double getPreco_servico1(){
        return preco_servico1;}
    public void setPreco_servico1(double preco_servico1){
        this.preco_servico1 = preco_servico1;}
    public double getPreco_servico2(){
        return preco_servico2;}
    public void setPreco_servico2(double preco_servico2){
        this.preco_servico2 = preco_servico2;}
    public double getPreco_servico3(){
        return preco_servico3;}
    public void setPreco_servico3(double preco_servico3){
        this.preco_servico3 = preco_servico3;}
    public int getQtd_servico1(){
        return qtd_servico1;}
    public void setQtd_servico1(int qtd_servico1){
        this.qtd_servico1 = qtd_servico1;}
    public int getQtd_servico2(){
        return qtd_servico2;}
    public void setQtd_servico2(int qtd_servico2){
        this.qtd_servico2 = qtd_servico2;}
    public int getQtd_servico3(){
        return qtd_servico3;}
    public void setQtd_servico3(int qtd_servico3){
        this.qtd_servico3 = qtd_servico3;}
    public double getTotal_servicos(){
        return total_servicos;}
    public void setTotal_servicos(double total_servicos){
        this.total_servicos = total_servicos;}
    public double getDescontos(){
        return descontos;}
    public void setDescontos(double descontos){
        this.descontos = descontos;}
    public double getTotal(){
        return total;}
    public void setTotal(double total){
        this.total = total;}}