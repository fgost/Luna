package ModeloDao;

import ModeloBeans.BeansCaixa;
import javax.swing.JOptionPane;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DaoCaixa{
    ConexaoBD conex = new ConexaoBD();
    BeansCaixa mod = new BeansCaixa();
    
    public void salvarTabela(BeansCaixa mod){
        conex.conexao();
        try{
            PreparedStatement pst = conex.con.prepareStatement("insert into caixaproduto (nome,tipo,preco,qtd) values(?,?,?,?)");
            pst.setString(1, mod.getProduto());
            pst.setString(2, mod.getTipo());
            pst.setDouble(3, mod.getPreco());
            pst.setInt(4,mod.getQtd());
            pst.execute();
            JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso!");}
            catch (SQLException ex){
                JOptionPane.showMessageDialog(null,"Erro ao inserir dados!\n"+ex );}
                conex.desconecta();}
    public void salvar(BeansCaixa mod){
        conex.conexao();
        try{
            PreparedStatement pst = conex.con.prepareStatement("insert into caixa (datas,barbeiro,formapagamento,obs,total,total_aberto,total_pago,nome_cleinte) values(?,?,?,?,?,?,?,?)");
            pst.setString(1, mod.getData());
            pst.setString(2, mod.getBarbeiro());
            pst.setString(3, mod.getPagamento());
            pst.setString(4,mod.getObs());
            pst.setDouble(5,mod.getTotal());
            pst.setDouble(6,mod.getTotalaberto());
            pst.setDouble(7,mod.getTotalpago());
            pst.setString(8,mod.getNome());
            pst.execute();
            JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso!");}
            catch (SQLException ex){
                JOptionPane.showMessageDialog(null,"Erro ao inserir dados!\n"+ex );}
                conex.desconecta();}
    /*public void AtualizarProduto(BeansCaixa mod){
        conex.conexao();
        try{
            PreparedStatement pst = conex.con.prepareStatement("update produto set qtd = qtd - "+mod.getQtd_produto()+" where nome_pro = '"+mod.getProduto()+"'");}
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Erro ao Atualizar Estoque!\n"+ex );}
            conex.desconecta();}
        
    public void AtualizarConsumo(BeansCaixa mod){
        conex.conexao();
        try{
            PreparedStatement pst = conex.con.prepareStatement("update produto set qtd = qtd - "+mod.getQtd_consumo()+" where nome_pro = '"+mod.getConsumo()+"'");}
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null,"Erro ao Atualizar Estoque!\n"+ex );}
            conex.desconecta();}*/
}