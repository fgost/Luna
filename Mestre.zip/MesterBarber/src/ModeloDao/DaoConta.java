package ModeloDao;

import ModeloBeans.BeansConta;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoConta 
    {
        ConexaoBD conex = new ConexaoBD();
        BeansConta mod = new BeansConta();
    
        public void Salvar(BeansConta mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("insert into conta (datas,nome,tipo,preco,fornecedor,qtd,total,status) values(?,?,?,?,?,?,?,?)");
                        pst.setString(1,mod.getData());
                        pst.setString(2, mod.getNome());
                        pst.setString(3, mod.getTipo());
                        pst.setDouble(4, mod.getPreco());
                        pst.setString(5, mod.getFornecedor());
                        pst.setInt(6, mod.getQtd());
                        pst.setDouble(7, mod.getTotal());
                        pst.setString(8, mod.getStatus());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao inserir dados!\n"+ex );
                    }
                conex.desconecta();
            }
        public BeansConta buscaConta(BeansConta mod)
            {
                conex.conexao();
                conex.executaSql("select * from conta where nome like '%"+mod.getPesquisa()+"%'");
                try 
                    {
                        conex.rs.first();
                        mod.setCod(conex.rs.getInt("cod"));
                        mod.setNome(conex.rs.getString("nome"));
                        mod.setTipo(conex.rs.getString("tipo"));
                        mod.setFornecedor(conex.rs.getString("fornecedor"));
                        mod.setData(conex.rs.getString("datas"));
                        mod.setQtd(conex.rs.getInt("qtd"));
                        
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Funcionario não cadastrado");
                    }
                conex.desconecta();
                return mod;
            }
    }