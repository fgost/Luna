package visao;

import ModeloConection.ConexaoBD;

public class FormCadastro extends javax.swing.JFrame 
    {
        ConexaoBD conecta = new ConexaoBD();
        
        public FormCadastro() 
            {
                initComponents();
            }
        @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButtonClientes = new javax.swing.JButton();
        jButtonUsuarios = new javax.swing.JButton();
        jButtonFuncionarios = new javax.swing.JButton();
        jButtonFornecedores = new javax.swing.JButton();
        jButtonProdutos = new javax.swing.JButton();
        jButtonTipoCorte = new javax.swing.JButton();
        jButtonServiço = new javax.swing.JButton();
        jButtonContas = new javax.swing.JButton();
        jLabelCadastros = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jButtonClientes.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonClientes.setText("CLIENTES");
        jButtonClientes.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonClientesActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonClientes);
        jButtonClientes.setBounds(10, 10, 150, 30);

        jButtonUsuarios.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonUsuarios.setText("USUARIOS");
        jButtonUsuarios.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonUsuariosActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonUsuarios);
        jButtonUsuarios.setBounds(170, 130, 150, 30);

        jButtonFuncionarios.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonFuncionarios.setText("FUNCIONARIOS");
        jButtonFuncionarios.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonFuncionarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFuncionariosActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonFuncionarios);
        jButtonFuncionarios.setBounds(170, 50, 150, 30);

        jButtonFornecedores.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonFornecedores.setText("FORNECEDORES");
        jButtonFornecedores.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonFornecedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFornecedoresActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonFornecedores);
        jButtonFornecedores.setBounds(10, 50, 150, 30);

        jButtonProdutos.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonProdutos.setText("PRODUTOS");
        jButtonProdutos.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonProdutos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonProdutosActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonProdutos);
        jButtonProdutos.setBounds(10, 90, 150, 30);

        jButtonTipoCorte.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonTipoCorte.setText("TIPOS DE CORTE");
        jButtonTipoCorte.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonTipoCorte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTipoCorteActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonTipoCorte);
        jButtonTipoCorte.setBounds(10, 130, 150, 30);

        jButtonServiço.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonServiço.setText("SERVIÇO");
        jButtonServiço.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonServiço.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonServiçoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonServiço);
        jButtonServiço.setBounds(170, 90, 150, 30);

        jButtonContas.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonContas.setText("CONTAS");
        jButtonContas.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonContas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonContasActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonContas);
        jButtonContas.setBounds(170, 10, 150, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 40, 330, 170);

        jLabelCadastros.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabelCadastros.setText("CADASTROS");
        getContentPane().add(jLabelCadastros);
        jLabelCadastros.setBounds(100, 0, 150, 40);

        setSize(new java.awt.Dimension(367, 257));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonClientesActionPerformed
    FormClientes telacli = new FormClientes();
    telacli.setVisible(true);
    }//GEN-LAST:event_jButtonClientesActionPerformed

    private void jButtonContasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonContasActionPerformed
    FormContas telacon = new FormContas();
    telacon.setVisible(true);                     
    }//GEN-LAST:event_jButtonContasActionPerformed

    private void jButtonFornecedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFornecedoresActionPerformed
    FormFornecedor telafor = new FormFornecedor();
    telafor.setVisible(true);
    }//GEN-LAST:event_jButtonFornecedoresActionPerformed

    private void jButtonFuncionariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFuncionariosActionPerformed
    FormFuncionario telafun = new FormFuncionario();
    telafun.setVisible(true);    
    }//GEN-LAST:event_jButtonFuncionariosActionPerformed

    private void jButtonProdutosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonProdutosActionPerformed
    FormProdutos telapro = new FormProdutos();
    telapro.setVisible(true);
    }//GEN-LAST:event_jButtonProdutosActionPerformed

    private void jButtonServiçoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonServiçoActionPerformed
    FormServiços telaser = new FormServiços();
    telaser.setVisible(true);
    }//GEN-LAST:event_jButtonServiçoActionPerformed

    private void jButtonTipoCorteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTipoCorteActionPerformed
    FormTipoCorte telacor = new FormTipoCorte();
    telacor.setVisible(true);
    }//GEN-LAST:event_jButtonTipoCorteActionPerformed

    private void jButtonUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonUsuariosActionPerformed
    FormUsuario telaUsu = new FormUsuario();         
    telaUsu.setVisible(true); 
    }//GEN-LAST:event_jButtonUsuariosActionPerformed
    public static void main(String args[]) 
        {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormCadastro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                        {
                            new FormCadastro().setVisible(true);
                        }
                });
        }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonClientes;
    private javax.swing.JButton jButtonContas;
    private javax.swing.JButton jButtonFornecedores;
    private javax.swing.JButton jButtonFuncionarios;
    private javax.swing.JButton jButtonProdutos;
    private javax.swing.JButton jButtonServiço;
    private javax.swing.JButton jButtonTipoCorte;
    private javax.swing.JButton jButtonUsuarios;
    private javax.swing.JLabel jLabelCadastros;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
    }