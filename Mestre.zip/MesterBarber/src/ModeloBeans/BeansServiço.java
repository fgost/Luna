package ModeloBeans;

public class BeansServiço{
    private String tipo; 
    private String pesquisa;
    private String nome;
    private int codigo;
    private double preço;
        
    public String getPesquisa(){
        return pesquisa;}
    public void setPesquisa(String pesquisa){
        this.pesquisa = pesquisa;}
    public int getCodigo(){
        return codigo;}
    public void setCodigo(int codigo){
        this.codigo = codigo;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public double getPreço(){
        return preço;}
    public void setPreço(double preço){
        this.preço = preço;}
    public String getTipo(){
        return tipo;}
    public void setTipo(String tipo){
        this.tipo = tipo;}}