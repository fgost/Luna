package visao;

import ModeloBeans.BeansSangria;
import ModeloConection.ConexaoBD;
import ModeloDao.DaoSangria;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class FormSangria extends javax.swing.JFrame 
    {
        ConexaoBD con = new ConexaoBD();
        DaoSangria control = new DaoSangria();
        BeansSangria mod = new BeansSangria();
        FormCaixa telaini = new FormCaixa();
        
        public FormSangria() 
            {
                initComponents();
                con.conexao();
            }
        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonValidar = new javax.swing.JButton();
        jTextFieldNome = new javax.swing.JTextField();
        jTextFieldSangria = new javax.swing.JTextField();
        jTextFieldUsuario = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jDateChooserDia = new com.toedter.calendar.JDateChooser();
        jPasswordFieldSenha = new javax.swing.JPasswordField();
        jButton2 = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jTextFieldMotivo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jButtonValidar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonValidar.setText("VALIDAR");
        jButtonValidar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonValidarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonValidar);
        jButtonValidar.setBounds(190, 360, 100, 40);

        jTextFieldNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        getContentPane().add(jTextFieldNome);
        jTextFieldNome.setBounds(40, 20, 240, 30);

        jTextFieldSangria.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        getContentPane().add(jTextFieldSangria);
        jTextFieldSangria.setBounds(440, 20, 110, 30);

        jTextFieldUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldUsuario.setEnabled(false);
        getContentPane().add(jTextFieldUsuario);
        jTextFieldUsuario.setBounds(160, 280, 210, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("no dia");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(160, 60, 60, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Usuário");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(90, 280, 70, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Realizei a sangria de R$");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(290, 20, 160, 30);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Senha");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(90, 320, 38, 30);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Eu,");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(10, 20, 30, 30);

        jDateChooserDia.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        getContentPane().add(jDateChooserDia);
        jDateChooserDia.setBounds(230, 60, 140, 30);

        jPasswordFieldSenha.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPasswordFieldSenha.setEnabled(false);
        getContentPane().add(jPasswordFieldSenha);
        jPasswordFieldSenha.setBounds(160, 320, 210, 30);

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setText("CONFIRMAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(210, 100, 120, 30);

        jButtonSalvar.setText("SALVAR");
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSalvar);
        jButtonSalvar.setBounds(300, 370, 71, 23);

        jTextFieldMotivo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldMotivo.setEnabled(false);
        getContentPane().add(jTextFieldMotivo);
        jTextFieldMotivo.setBounds(10, 180, 540, 70);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("MOTIVO");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(250, 140, 60, 30);

        setSize(new java.awt.Dimension(579, 461));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    jPasswordFieldSenha.setEnabled(true);
    jTextFieldMotivo.setEnabled(true);
    jTextFieldUsuario.setText((jTextFieldNome.getText()));
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButtonValidarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonValidarActionPerformed
    try 
        {
            con.executaSql("select * from usuarios where usu_nome = '"+jTextFieldUsuario.getText()+"'");
            con.rs.first();
            if(con.rs.getString("usu_senha").equals(jPasswordFieldSenha.getText()))
                {
                    jButtonSalvar.setEnabled(true);
                }
            else
                {
                    JOptionPane.showMessageDialog(rootPane, "senha ou usuario incorretos");
                } 
            con.desconecta();
        }
    catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(rootPane, "senha ou usuario incorretos");
            jTextFieldNome.setText("");
            jTextFieldSangria.setText("");
            jTextFieldUsuario.setText("");
            jPasswordFieldSenha.setText("");
            jTextFieldMotivo.setText("");
            
            jTextFieldMotivo.setEnabled(false);
            jPasswordFieldSenha.setEnabled(false);
        }
    }//GEN-LAST:event_jButtonValidarActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
    mod.setNome(jTextFieldNome.getText());
    mod.setSenha(jPasswordFieldSenha.getText());
    mod.setUsuario(jTextFieldUsuario.getText());
    mod.setSangria(Double.parseDouble(jTextFieldSangria.getText()));
    mod.setData( jDateChooserDia.getDate());
    mod.setMotivo(jTextFieldMotivo.getText());
    
    control.Salvar(mod);
        
    dispose();
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormSangria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormSangria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormSangria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormSangria.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormSangria().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JButton jButtonValidar;
    private com.toedter.calendar.JDateChooser jDateChooserDia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPasswordField jPasswordFieldSenha;
    private javax.swing.JTextField jTextFieldMotivo;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldSangria;
    private javax.swing.JTextField jTextFieldUsuario;
    // End of variables declaration//GEN-END:variables
}
