package ModeloDao;

import ModeloBeans.BeansInicio;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoInicio 
    {
    BeansInicio mod = new BeansInicio();
    ConexaoBD conex = new ConexaoBD();
        public void Salvar(BeansInicio mod)
        {
            conex.conexao();
            try 
                {   
                    PreparedStatement pst = conex.con.prepareStatement("insert into inicio (usuario1,senha1,nome,datas,valor) values (?,?,?,?,?)");
                    pst.setString(1,mod.getUsuario1());
                    pst.setString(2, mod.getSenha1());
                    pst.setString(3, mod.getNome());  
                    pst.setDate(4,new java.sql.Date(mod.getData().getTime()));
                    pst.setDouble(5, mod.getValor());
                    pst.execute();
                    JOptionPane.showMessageDialog(null,"Gravado com Sucesso");
                }     
            catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(null,"Erro ao Gravar!\n"+ex );
                }
            conex.desconecta();
        }
    }
