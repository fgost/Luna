package visao;

import ModeloBeans.BeansAgenda;
import ModeloBeans.ModeloTabela;
import ModeloConection.ConexaoBD;
import ModeloDao.DaoAgenda;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormAgendamento extends javax.swing.JFrame 
    {
        BeansAgenda agenda = new BeansAgenda();
        DaoAgenda dao = new DaoAgenda();
        ConexaoBD conex = new ConexaoBD();
        
        public FormAgendamento() 
            {
                initComponents();
                preencherBarbeiro();
                preencherServico();
                preencherTabela("select * from cliente a join agenda b on a.cli_cod=b.codcli_agenda order by datas");
            }        
        public void preencherBarbeiro()
            {
                conex.conexao();
                conex.executaSql("select * from funcionario where cargo_funcionario like'%Barbeiro%' order by nome_Funcionario");
                try
                    {
                        conex.rs.first();
                        jComboBoxBarbeiro.removeAllItems();
                        do
                            {
                                jComboBoxBarbeiro.addItem(conex.rs.getString("nome_funcionario"));
                            }
                        while(conex.rs.next());
                    }
                catch (SQLException ex)
                    {
                        JOptionPane.showMessageDialog(rootPane, "Erro ao preencher barbeiro\n"+ex);
                    }
                conex.desconecta();
            }    
        public void preencherServico()
            {
                conex.conexao();
                conex.executaSql("select * from servico order by nome_serv");
                try
                    {
                        conex.rs.first();
                        jComboBoxServiço.removeAllItems();
                        do
                            {
                                jComboBoxServiço.addItem(conex.rs.getString("nome_serv"));
                            }
                        while(conex.rs.next());
                    }
                catch (SQLException ex)
                    {
                        JOptionPane.showMessageDialog(rootPane, "Erro ao preencher serviço\n"+ex);
                    }
                conex.desconecta();
            }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelCliente = new javax.swing.JLabel();
        jLabelBarbeiro = new javax.swing.JLabel();
        jLabelServiço = new javax.swing.JLabel();
        jLabelHorario = new javax.swing.JLabel();
        jLabelData = new javax.swing.JLabel();
        jTextFieldPesquisar = new javax.swing.JTextField();
        jTextFieldHorario = new javax.swing.JTextField();
        jButtonCancelar = new javax.swing.JButton();
        jButtonBuscar = new javax.swing.JButton();
        jButtonAgendar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableCliente = new javax.swing.JTable();
        jComboBoxBarbeiro = new javax.swing.JComboBox<>();
        jComboBoxServiço = new javax.swing.JComboBox<>();
        jTextFieldData = new javax.swing.JTextField();
        jLabelTitulo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setToolTipText("");
        jPanel1.setLayout(null);

        jLabelCliente.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelCliente.setText("CLIENTE");
        jPanel1.add(jLabelCliente);
        jLabelCliente.setBounds(10, 10, 60, 30);

        jLabelBarbeiro.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelBarbeiro.setText("BARBEIRO");
        jPanel1.add(jLabelBarbeiro);
        jLabelBarbeiro.setBounds(10, 110, 80, 30);

        jLabelServiço.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelServiço.setText("SERVIÇO");
        jPanel1.add(jLabelServiço);
        jLabelServiço.setBounds(220, 110, 60, 30);

        jLabelHorario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelHorario.setText("HORARIO");
        jPanel1.add(jLabelHorario);
        jLabelHorario.setBounds(70, 60, 80, 30);

        jLabelData.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelData.setText("DATA");
        jPanel1.add(jLabelData);
        jLabelData.setBounds(220, 60, 50, 30);

        jTextFieldPesquisar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldPesquisar);
        jTextFieldPesquisar.setBounds(70, 10, 240, 30);

        jTextFieldHorario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldHorario);
        jTextFieldHorario.setBounds(140, 60, 70, 30);

        jButtonCancelar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButtonCancelar.setText("CANCELAR");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCancelar);
        jButtonCancelar.setBounds(250, 300, 130, 30);

        jButtonBuscar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonBuscar.setText("BUSCAR");
        jButtonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonBuscar);
        jButtonBuscar.setBounds(320, 10, 90, 30);

        jButtonAgendar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jButtonAgendar.setText("AGENDAR");
        jButtonAgendar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAgendarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonAgendar);
        jButtonAgendar.setBounds(40, 300, 130, 30);

        jTableCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableCliente.setEnabled(false);
        jTableCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableClienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableCliente);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 150, 400, 140);

        jComboBoxBarbeiro.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxBarbeiro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxBarbeiroActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBoxBarbeiro);
        jComboBoxBarbeiro.setBounds(80, 110, 130, 30);

        jComboBoxServiço.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel1.add(jComboBoxServiço);
        jComboBoxServiço.setBounds(280, 110, 130, 30);
        jPanel1.add(jTextFieldData);
        jTextFieldData.setBounds(290, 60, 80, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 60, 420, 350);

        jLabelTitulo.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabelTitulo.setText("AGENDAMENTO");
        getContentPane().add(jLabelTitulo);
        jLabelTitulo.setBounds(20, 10, 350, 40);

        setSize(new java.awt.Dimension(459, 463));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
    jTextFieldPesquisar.setText("");
    jTextFieldHorario.setText("");
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jButtonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBuscarActionPerformed
    preencherTabela("select * from cliente a join agenda b on a.cli_cod=b.codcli_agenda where cli_nome like '%"+jTextFieldPesquisar.getText()+"%'");
    }//GEN-LAST:event_jButtonBuscarActionPerformed

    private void jTableClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableClienteMouseClicked
    
    }//GEN-LAST:event_jTableClienteMouseClicked

    private void jComboBoxBarbeiroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxBarbeiroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxBarbeiroActionPerformed

    private void jButtonAgendarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAgendarActionPerformed
    if(jTextFieldData.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o nome para continuar");
            jTextFieldData.requestFocus();
        }
        else if(jTextFieldHorario.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Preencha o Telefone para continuar");
                jTextFieldHorario.requestFocus();
            }
        
    agenda.setNomeCliente(jTextFieldPesquisar.getText());
    agenda.setNomeBarbeiro((String) jComboBoxBarbeiro.getSelectedItem());
    agenda.setData( jTextFieldData.getText());
    agenda.setHora(jTextFieldHorario.getText());
    agenda.setServiço((String) jComboBoxServiço.getSelectedItem());
    
    dao.Salvar(agenda);     
    
    preencherTabela("select * from cliente a join agenda b on a.cli_cod=b.codcli_agenda where cli_nome like '%"+jTextFieldPesquisar.getText()+"%'");
    }//GEN-LAST:event_jButtonAgendarActionPerformed
    public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"NOME",
                                              "TELEFONE",
                                              "HORA",
                                              "DATA"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{conex.rs.getString("cli_nome")
                                                  ,conex.rs.getString("cli_tel")
                                                  ,conex.rs.getString("hora_agenda")
                                                  ,conex.rs.getString("datas")});
                                                 
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados");
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTableCliente.setModel(modelo);
             
            jTableCliente.getColumnModel().getColumn(0).setPreferredWidth(162);
            jTableCliente.getColumnModel().getColumn(0).setResizable(false);
            
            jTableCliente.getColumnModel().getColumn(1).setPreferredWidth(110);
            jTableCliente.getColumnModel().getColumn(1).setResizable(false);
            
            jTableCliente.getColumnModel().getColumn(2).setPreferredWidth(55);
            jTableCliente.getColumnModel().getColumn(2).setResizable(false);
            
            jTableCliente.getColumnModel().getColumn(3).setPreferredWidth(70);
            jTableCliente.getColumnModel().getColumn(3).setResizable(false);
            
            jTableCliente.getTableHeader().setReorderingAllowed(false);
            jTableCliente.setAutoResizeMode(jTableCliente.AUTO_RESIZE_OFF);
            jTableCliente.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }    
    public static void main(String args[]) 
        {
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                        {
                            new FormAgendamento().setVisible(true);
                        }
                });
         }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAgendar;
    private javax.swing.JButton jButtonBuscar;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JComboBox<String> jComboBoxBarbeiro;
    private javax.swing.JComboBox<String> jComboBoxServiço;
    private javax.swing.JLabel jLabelBarbeiro;
    private javax.swing.JLabel jLabelCliente;
    private javax.swing.JLabel jLabelData;
    private javax.swing.JLabel jLabelHorario;
    private javax.swing.JLabel jLabelServiço;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableCliente;
    private javax.swing.JTextField jTextFieldData;
    private javax.swing.JTextField jTextFieldHorario;
    private javax.swing.JTextField jTextFieldPesquisar;
    // End of variables declaration//GEN-END:variables
}