package ModeloBeans;


public class BeansAgenda{
    private String NomeCliente;
    private String hora;
    private String NomeBarbeiro;
    private String data;
    private String serviço;
    private String pesquisa;
        
    public String getNomeCliente(){
        return NomeCliente;}
    public void setNomeCliente(String NomeCliente){
        this.NomeCliente = NomeCliente;}
    public String getHora(){
        return hora;}
    public void setHora(String hora){
        this.hora = hora;}
    public String getNomeBarbeiro(){
        return NomeBarbeiro;}
    public void setNomeBarbeiro(String NomeBarbeiro){
        this.NomeBarbeiro = NomeBarbeiro;}
    public String getData(){
        return data;}
    public void setData(String data){
        this.data = data;}
    public String getServiço(){
        return serviço;}
    public void setServiço(String serviço){
        this.serviço = serviço;}
    public String getPesquisa(){
        return pesquisa;}
    public void setPesquisa(String pesquisa){
        this.pesquisa = pesquisa;}}