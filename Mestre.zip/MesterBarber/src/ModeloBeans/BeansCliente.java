package ModeloBeans;

public class BeansCliente{
    private String nome;
    private String telefone;
    private String pesquisa;  
    private int codigo;
    
    public int getCodigo(){
        return codigo;}
    public void setCodigo(int codigo){
        this.codigo = codigo;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public String getTelefone(){
        return telefone;}
    public void setTelefone(String telefone){
        this.telefone = telefone;}
    public String getPesquisa(){
        return pesquisa;}
    public void setPesquisa(String pesquisa){
        this.pesquisa = pesquisa;}}