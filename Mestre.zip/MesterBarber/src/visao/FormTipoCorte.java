package visao;

import ModeloConection.ConexaoBD;
import ModeloBeans.BeansTipoCorte;
import ModeloDao.DaoTipoCorte;
import ModeloBeans.ModeloTabela;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormTipoCorte extends javax.swing.JFrame 
    {
        BeansTipoCorte mod = new BeansTipoCorte();
        DaoTipoCorte control = new DaoTipoCorte();
        ConexaoBD conex = new ConexaoBD();
        int flag = 0;
    
        public FormTipoCorte() 
            {
                initComponents();
            preencherTabela("select * from tipocorte order by nome_corte");
            }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelNomeProduto = new javax.swing.JLabel();
        jTextFieldTipoCorte = new javax.swing.JTextField();
        jButtonNovo = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jTextFieldPesquisa = new javax.swing.JTextField();
        jButtonPesquisarTipoCorte = new javax.swing.JButton();
        jLabelIDProduto = new javax.swing.JLabel();
        jTextFieldCodTipoCorte = new javax.swing.JTextField();
        jLabelCad = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabelNomeProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelNomeProduto.setText("TIPO DE CORTE");
        jPanel1.add(jLabelNomeProduto);
        jLabelNomeProduto.setBounds(210, 20, 110, 30);

        jTextFieldTipoCorte.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldTipoCorte.setEnabled(false);
        jPanel1.add(jTextFieldTipoCorte);
        jTextFieldTipoCorte.setBounds(320, 20, 160, 30);

        jButtonNovo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonNovo.setText("NOVO");
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonNovo);
        jButtonNovo.setBounds(10, 20, 100, 30);

        jButtonSalvar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonSalvar.setText("SALVAR");
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalvar);
        jButtonSalvar.setBounds(10, 60, 100, 30);

        jButtonCancelar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonCancelar.setText("CANCELAR");
        jButtonCancelar.setEnabled(false);
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCancelar);
        jButtonCancelar.setBounds(10, 100, 100, 30);

        jButtonEditar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonEditar.setText("EDITAR");
        jButtonEditar.setEnabled(false);
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEditar);
        jButtonEditar.setBounds(10, 140, 100, 30);

        jButtonExcluir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonExcluir.setText("EXCLUIR");
        jButtonExcluir.setEnabled(false);
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonExcluir);
        jButtonExcluir.setBounds(10, 180, 100, 30);

        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisa);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(120, 100, 360, 110);

        jTextFieldPesquisa.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldPesquisa);
        jTextFieldPesquisa.setBounds(120, 60, 240, 30);

        jButtonPesquisarTipoCorte.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonPesquisarTipoCorte.setText("PESQUISAR");
        jButtonPesquisarTipoCorte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarTipoCorteActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonPesquisarTipoCorte);
        jButtonPesquisarTipoCorte.setBounds(370, 60, 110, 30);

        jLabelIDProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelIDProduto.setText("ID");
        jPanel1.add(jLabelIDProduto);
        jLabelIDProduto.setBounds(120, 20, 30, 30);

        jTextFieldCodTipoCorte.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldCodTipoCorte.setEnabled(false);
        jPanel1.add(jTextFieldCodTipoCorte);
        jTextFieldCodTipoCorte.setBounds(150, 20, 50, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 40, 490, 230);

        jLabelCad.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabelCad.setText("CADASTRO DE CORTES");
        getContentPane().add(jLabelCad);
        jLabelCad.setBounds(70, 0, 400, 40);

        setSize(new java.awt.Dimension(526, 319));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
   if(jTextFieldTipoCorte.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o nome para continuar");
            jTextFieldTipoCorte.requestFocus();
        }
        else 
            {     
            }
    if(flag==1)
        {
            mod.setNome(jTextFieldTipoCorte.getText());
            control.Salvar(mod);
            jTextFieldTipoCorte.setText("");
            jTextFieldTipoCorte.setEnabled(false);
            jButtonSalvar.setEnabled(false);
            jButtonCancelar.setEnabled(false);
            preencherTabela("select * from tipocorte order by nome_corte");
        }
        else
            {
                mod.setCod((Integer.parseInt(jTextFieldCodTipoCorte.getText())));
                mod.setNome(jTextFieldTipoCorte.getText());
                control.Editar(mod);
                jTextFieldTipoCorte.setEnabled(false);
                jButtonSalvar.setEnabled(false);
                jButtonCancelar.setEnabled(false);  
                jTextFieldTipoCorte.setText("");
                jTextFieldCodTipoCorte.setText("");
                jTextFieldPesquisa.setText("");
            preencherTabela("select * from tipocorte order by nome_corte");
            }
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
    flag = 1;
    jTextFieldTipoCorte.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    jTextFieldTipoCorte.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldCodTipoCorte.setText("");
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
    jTextFieldTipoCorte.setEnabled(!true);
    jButtonSalvar.setEnabled(!true);
    jButtonCancelar.setEnabled(!true);
    jButtonNovo.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    jTextFieldTipoCorte.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldPesquisa.setEnabled(true);
    jButtonPesquisarTipoCorte.setEnabled(true);
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jTablePesquisaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaMouseClicked
    String nome_corte = ""+jTablePesquisa.getValueAt(jTablePesquisa.getSelectedRow(), 1);
    conex.conexao();
    conex.executaSql("select * from tipocorte where nome_corte ='"+nome_corte+"'");
    try 
        {      
            conex.rs.first();
            jTextFieldTipoCorte.setText(conex.rs.getString("nome_corte"));
            jTextFieldCodTipoCorte.setText(String.valueOf(conex.rs.getInt("cod_corte")));
            
        } 
    catch (SQLException ex) 
        {
                JOptionPane.showMessageDialog(rootPane, "Erro ao selecionar dados"+ex);
        }
    conex.desconecta();
    jButtonEditar.setEnabled(true);
    jButtonExcluir.setEnabled(true);
    }//GEN-LAST:event_jTablePesquisaMouseClicked

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
    flag = 2;
    jTextFieldTipoCorte.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonNovo.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
int resposta = 0;
    resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente excluir?");
    if(resposta==JOptionPane.YES_OPTION)
        {
            mod.setCod((Integer.parseInt(jTextFieldCodTipoCorte.getText())));
            control.Excluir(mod);
            jButtonEditar.setEnabled(false);
            jButtonExcluir.setEnabled(false);
            jButtonCancelar.setEnabled(false);
            jButtonNovo.setEnabled(true);
            jTextFieldTipoCorte.setText("");
            jTextFieldCodTipoCorte.setText("");
            jTextFieldPesquisa.setText("");
            preencherTabela("select * from tipocorte order by nome_corte");
        }
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonPesquisarTipoCorteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarTipoCorteActionPerformed
        BeansTipoCorte model = control.buscaProdutoNome(mod);
        mod.setPesquisa(jTextFieldPesquisa.getText());
        jTextFieldTipoCorte.setText(model.getNome());
        jTextFieldCodTipoCorte.setText(String.valueOf(model.getCod()));
        jButtonEditar.setEnabled(true);
        jButtonExcluir.setEnabled(true);
        jButtonNovo.setEnabled(false);
        jButtonSalvar.setEnabled(false);
        jTextFieldTipoCorte.setEnabled(false);
        
    }//GEN-LAST:event_jButtonPesquisarTipoCorteActionPerformed
public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"cod","nome"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{conex.rs.getInt("cod_corte"),conex.rs.getString("nome_corte")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTablePesquisa.setModel(modelo);
            jTablePesquisa.getColumnModel().getColumn(0).setPreferredWidth(57);
            jTablePesquisa.getColumnModel().getColumn(0).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(1).setPreferredWidth(300);
            jTablePesquisa.getColumnModel().getColumn(1).setResizable(false);
            
            jTablePesquisa.getTableHeader().setReorderingAllowed(false);
            jTablePesquisa.setAutoResizeMode(jTablePesquisa.AUTO_RESIZE_OFF);
            jTablePesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    public static void main(String args[]) 
        {
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                    {
                        new FormTipoCorte().setVisible(true);
                    }
                });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonPesquisarTipoCorte;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JLabel jLabelCad;
    private javax.swing.JLabel jLabelIDProduto;
    private javax.swing.JLabel jLabelNomeProduto;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextFieldCodTipoCorte;
    private javax.swing.JTextField jTextFieldPesquisa;
    private javax.swing.JTextField jTextFieldTipoCorte;
    // End of variables declaration//GEN-END:variables
}