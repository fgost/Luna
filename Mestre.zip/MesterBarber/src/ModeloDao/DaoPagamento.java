package ModeloDao;

import ModeloBeans.BeansPagamento;
import ModeloBeans.BeansServiço;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoPagamento 
    {
        ConexaoBD conex = new ConexaoBD();
        
        public void Salvar(BeansPagamento mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("insert into pagamento (mes,funcionario, cargo,qtd_cortes,preco_cortes,servico1,servico2,servico3,preco_servico1,preco_servico2,preco_servico3,qtd_servico1,qtd_servico2,qtd_servico3,total_servicos,descontos,total) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                        
                        
                        pst.setString(1, mod.getMes());
                        pst.setString(2, mod.getFunicionario()); 
                        pst.setString(3, mod.getCargo());
                        pst.setInt(4, mod.getQtd_cortes());
                        pst.setDouble(5, mod.getPreco_cortes());
                        pst.setString(6, mod.getServico1());
                        pst.setString(7, mod.getServico2());
                        pst.setString(8, mod.getServico3());
                        pst.setDouble(9, mod.getPreco_servico1());
                        pst.setDouble(10, mod.getPreco_servico2());
                        pst.setDouble(11, mod.getPreco_servico3());
                        pst.setInt(12, mod.getQtd_servico1());
                        pst.setInt(13, mod.getQtd_servico2());
                        pst.setInt(14, mod.getQtd_servico3());
                        pst.setDouble(15, mod.getTotal_servicos());
                        pst.setDouble(16, mod.getDescontos());
                        pst.setDouble(17, mod.getTotal());                        
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao inserir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    }
