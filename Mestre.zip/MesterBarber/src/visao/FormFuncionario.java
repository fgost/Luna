package visao;

import ModeloConection.ConexaoBD;
import ModeloDao.DaoFuncionario;
import ModeloBeans.BeansFuncionario;
import ModeloBeans.ModeloTabela;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormFuncionario extends javax.swing.JFrame 
    {
        BeansFuncionario mod = new BeansFuncionario();
        DaoFuncionario control = new DaoFuncionario();
        ConexaoBD conex = new ConexaoBD();
        int flag = 0;
    
        public FormFuncionario() 
            {
                initComponents();
                preencherTabela("select * from funcionario order by nome_funcionario");
            }    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelNome = new javax.swing.JLabel();
        jLabelLogin = new javax.swing.JLabel();
        jLabelCargo = new javax.swing.JLabel();
        jTextFieldNome = new javax.swing.JTextField();
        jComboBoxCargo = new javax.swing.JComboBox<>();
        jButtonNovo = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jTextFieldPesquisa = new javax.swing.JTextField();
        jButtonPesquisar = new javax.swing.JButton();
        jFormattedTextFieldLogin = new javax.swing.JFormattedTextField();
        jTextFieldCod = new javax.swing.JTextField();
        jLabelCod = new javax.swing.JLabel();
        jLabelCad = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabelNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelNome.setText("NOME");
        jPanel1.add(jLabelNome);
        jLabelNome.setBounds(210, 10, 50, 30);

        jLabelLogin.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelLogin.setText("TELEFONE");
        jPanel1.add(jLabelLogin);
        jLabelLogin.setBounds(323, 60, 80, 30);

        jLabelCargo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelCargo.setText("CARGO");
        jPanel1.add(jLabelCargo);
        jLabelCargo.setBounds(130, 60, 60, 30);

        jTextFieldNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldNome.setEnabled(false);
        jPanel1.add(jTextFieldNome);
        jTextFieldNome.setBounds(260, 10, 310, 30);

        jComboBoxCargo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxCargo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Barbeiro", "Administrador", "Gerente" }));
        jComboBoxCargo.setEnabled(false);
        jComboBoxCargo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxCargoActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBoxCargo);
        jComboBoxCargo.setBounds(190, 60, 120, 30);

        jButtonNovo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonNovo.setText("NOVO");
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonNovo);
        jButtonNovo.setBounds(10, 10, 100, 30);

        jButtonSalvar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonSalvar.setText("SALVAR");
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalvar);
        jButtonSalvar.setBounds(10, 60, 100, 30);

        jButtonCancelar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonCancelar.setText("CANCELAR");
        jButtonCancelar.setEnabled(false);
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCancelar);
        jButtonCancelar.setBounds(10, 110, 100, 30);

        jButtonEditar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonEditar.setText("EDITAR");
        jButtonEditar.setEnabled(false);
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEditar);
        jButtonEditar.setBounds(10, 160, 100, 30);

        jButtonExcluir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonExcluir.setText("EXCLUIR");
        jButtonExcluir.setEnabled(false);
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonExcluir);
        jButtonExcluir.setBounds(10, 210, 100, 30);

        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisa);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(120, 160, 450, 130);
        jPanel1.add(jTextFieldPesquisa);
        jTextFieldPesquisa.setBounds(120, 110, 320, 30);

        jButtonPesquisar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonPesquisar.setText("PESQUISAR");
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(450, 110, 120, 30);

        jFormattedTextFieldLogin.setEnabled(false);
        jPanel1.add(jFormattedTextFieldLogin);
        jFormattedTextFieldLogin.setBounds(410, 60, 160, 30);

        jTextFieldCod.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldCod.setEnabled(false);
        jPanel1.add(jTextFieldCod);
        jTextFieldCod.setBounds(160, 10, 40, 30);

        jLabelCod.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelCod.setText("ID");
        jPanel1.add(jLabelCod);
        jLabelCod.setBounds(130, 10, 50, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 40, 590, 300);

        jLabelCad.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabelCad.setText("CADASTRO DE FUNCIONARIOS");
        getContentPane().add(jLabelCad);
        jLabelCad.setBounds(170, 10, 260, 30);

        setSize(new java.awt.Dimension(624, 390));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxCargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxCargoActionPerformed
       
    }//GEN-LAST:event_jComboBoxCargoActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
    if(jTextFieldNome.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o nome para continuar");
            jTextFieldNome.requestFocus();
        }
        else if(jFormattedTextFieldLogin.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Preencha o Telefone para continuar");
                jFormattedTextFieldLogin.requestFocus();
            }
    if(flag==1)
        {
            mod.setNome(jTextFieldNome.getText());
            mod.setCargo((String)jComboBoxCargo.getSelectedItem());
            mod.setLogin(Integer.parseInt(jFormattedTextFieldLogin.getText()));        
            control.Salvar(mod);
            jTextFieldNome.setText("");
            jFormattedTextFieldLogin.setText("");
            jTextFieldNome.setEnabled(false);
            jFormattedTextFieldLogin.setEnabled(false);
            jComboBoxCargo.setEnabled(false);
            jButtonSalvar.setEnabled(false);
            jButtonCancelar.setEnabled(false);
            preencherTabela("select * from funcionario order by nome_funcionario");
        }
    else
        {
            mod.setCodigo((Integer.parseInt(jTextFieldCod.getText())));
            mod.setNome(jTextFieldNome.getText());
            mod.setCargo((String)jComboBoxCargo.getSelectedItem());
            mod.setLogin(Integer.parseInt(jFormattedTextFieldLogin.getText()));
            control.Editar(mod);
            jTextFieldNome.setEnabled(false);
            jFormattedTextFieldLogin.setEnabled(false);
            jComboBoxCargo.setEnabled(false);
            jButtonSalvar.setEnabled(false);
            jButtonCancelar.setEnabled(false);  
            jTextFieldNome.setText("");
            jFormattedTextFieldLogin.setText("");
            jTextFieldCod.setText("");
            jTextFieldPesquisa.setText("");
            preencherTabela("select * from funcionario order by nome_funcionario");
        }
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
    BeansFuncionario model = control.buscaFuncionario(mod);
    mod.setPesquisa(jTextFieldPesquisa.getText());
    jTextFieldNome.setText(model.getNome());
    jTextFieldCod.setText(String.valueOf(model.getCodigo()));
    jFormattedTextFieldLogin.setText(String.valueOf(model.getLogin()));
    jComboBoxCargo.setSelectedItem(model.getCargo());
    jButtonSalvar.setEnabled(false);
    jTextFieldNome.setEnabled(false);
    jFormattedTextFieldLogin.setEnabled(false);
    jComboBoxCargo.setEnabled(false);
    jButtonExcluir.setEnabled(true);
    jButtonEditar.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jButtonNovo.setEnabled(false);
    preencherTabela("select * from funcionario where nome_funcionario like '%"+mod.getPesquisa()+"%'");
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
    flag = 1;
    jTextFieldNome.setEnabled(true);
    jFormattedTextFieldLogin.setEnabled(true);
    jComboBoxCargo.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    jTextFieldNome.setText("");
    jFormattedTextFieldLogin.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldCod.setText("");
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
    jTextFieldNome.setEnabled(!true);
    jFormattedTextFieldLogin.setEnabled(!true);
    jComboBoxCargo.setEnabled(!true);
    jButtonSalvar.setEnabled(!true);
    jButtonCancelar.setEnabled(!true);
    jButtonNovo.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    jTextFieldNome.setText("");
    jFormattedTextFieldLogin.setText("");
    jTextFieldCod.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldPesquisa.setEnabled(true);
    jButtonPesquisar.setEnabled(true);
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
    flag = 2;
    jTextFieldNome.setEnabled(true);
    jFormattedTextFieldLogin.setEnabled(true);
    jComboBoxCargo.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonNovo.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
    int resposta = 0;
    resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente excluir?");
    if(resposta==JOptionPane.YES_OPTION)
        {
            mod.setCodigo((Integer.parseInt(jTextFieldCod.getText())));
            control.Excluir(mod);
            jButtonEditar.setEnabled(false);
            jButtonExcluir.setEnabled(false);
            jButtonCancelar.setEnabled(false);
            jButtonNovo.setEnabled(true);
            jTextFieldNome.setText("");
            jFormattedTextFieldLogin.setText("");
            jTextFieldCod.setText("");
            jTextFieldPesquisa.setText("");
            preencherTabela("select * from funcionario order by nome_funcionario");
        }
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jTablePesquisaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaMouseClicked
    String nome_funcionario = ""+jTablePesquisa.getValueAt(jTablePesquisa.getSelectedRow(), 1);
    conex.conexao();
    conex.executaSql("select * from funcionario where nome_funcionario ='"+nome_funcionario+"'");
    try 
        {      
            conex.rs.first();
            jTextFieldCod.setText(String.valueOf(conex.rs.getInt("cod_funcionario")));
            jTextFieldNome.setText(conex.rs.getString("nome_funcionario"));
            jComboBoxCargo.setSelectedItem(conex.rs.getString("cargo_funcionario"));
            jFormattedTextFieldLogin.setText(conex.rs.getString("login_funcionario"));
        } 
    catch (SQLException ex) 
        {
                JOptionPane.showMessageDialog(rootPane, "Erro ao selecionar dados"+ex);
        }
    conex.desconecta();
    jButtonEditar.setEnabled(true);
    jButtonExcluir.setEnabled(true);
    }//GEN-LAST:event_jTablePesquisaMouseClicked
    public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"id"
                                             ,"nome"
                                             ,"cargo"
                                             ,"Telefone"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{conex.rs.getInt("cod_funcionario")
                                                  ,conex.rs.getString("nome_funcionario")
                                                  ,conex.rs.getString("cargo_funcionario")
                                                  ,conex.rs.getInt("login_funcionario")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTablePesquisa.setModel(modelo);
            jTablePesquisa.getColumnModel().getColumn(0).setPreferredWidth(30);
            jTablePesquisa.getColumnModel().getColumn(0).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(1).setPreferredWidth(170);
            jTablePesquisa.getColumnModel().getColumn(1).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(2).setPreferredWidth(170);
            jTablePesquisa.getColumnModel().getColumn(2).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(3).setPreferredWidth(77);
            jTablePesquisa.getColumnModel().getColumn(3).setResizable(false);
            
            jTablePesquisa.getTableHeader().setReorderingAllowed(false);
            jTablePesquisa.setAutoResizeMode(jTablePesquisa.AUTO_RESIZE_OFF);
            jTablePesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    public static void main(String args[]) 
        {
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                        {
                            new FormFuncionario().setVisible(true);
                        }
                });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox<String> jComboBoxCargo;
    private javax.swing.JFormattedTextField jFormattedTextFieldLogin;
    private javax.swing.JLabel jLabelCad;
    private javax.swing.JLabel jLabelCargo;
    private javax.swing.JLabel jLabelCod;
    private javax.swing.JLabel jLabelLogin;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextFieldCod;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldPesquisa;
    // End of variables declaration//GEN-END:variables
}