package visao;

import ModeloConection.ConexaoBD;
import ModeloDao.DaoServiço;
import ModeloBeans.BeansServiço;
import ModeloBeans.ModeloTabela;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormServiços extends javax.swing.JFrame 
    {
        BeansServiço mod = new BeansServiço();
        DaoServiço control = new DaoServiço();
        ConexaoBD conex = new ConexaoBD();
        int flag = 0;
    
        public FormServiços() 
            {
                initComponents();
                preencherTabela("select * from servico order by nome_serv");
            }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelNomeProduto = new javax.swing.JLabel();
        jLabelPreçoProduto = new javax.swing.JLabel();
        jTextFieldNomeProduto = new javax.swing.JTextField();
        jButtonNovo = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jTextFieldPesquisa = new javax.swing.JTextField();
        jButtonPesquisarNome = new javax.swing.JButton();
        jTextFieldPreçoProduto = new javax.swing.JTextField();
        jLabelIDProduto = new javax.swing.JLabel();
        jTextFieldCodProduto = new javax.swing.JTextField();
        jLabelCad = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabelNomeProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelNomeProduto.setText("NOME");
        jPanel1.add(jLabelNomeProduto);
        jLabelNomeProduto.setBounds(210, 20, 50, 30);

        jLabelPreçoProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelPreçoProduto.setText("PREÇO");
        jPanel1.add(jLabelPreçoProduto);
        jLabelPreçoProduto.setBounds(190, 60, 50, 30);

        jTextFieldNomeProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldNomeProduto.setEnabled(false);
        jPanel1.add(jTextFieldNomeProduto);
        jTextFieldNomeProduto.setBounds(270, 20, 150, 30);

        jButtonNovo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonNovo.setText("NOVO");
        jButtonNovo.setBorderPainted(false);
        jButtonNovo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonNovo);
        jButtonNovo.setBounds(10, 20, 100, 30);

        jButtonSalvar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonSalvar.setText("SALVAR");
        jButtonSalvar.setBorderPainted(false);
        jButtonSalvar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalvar);
        jButtonSalvar.setBounds(10, 70, 100, 30);

        jButtonCancelar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonCancelar.setText("CANCELAR");
        jButtonCancelar.setBorderPainted(false);
        jButtonCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonCancelar.setEnabled(false);
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCancelar);
        jButtonCancelar.setBounds(10, 120, 100, 30);

        jButtonEditar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonEditar.setText("EDITAR");
        jButtonEditar.setBorderPainted(false);
        jButtonEditar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonEditar.setEnabled(false);
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEditar);
        jButtonEditar.setBounds(10, 170, 100, 30);

        jButtonExcluir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonExcluir.setText("EXCLUIR");
        jButtonExcluir.setBorderPainted(false);
        jButtonExcluir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonExcluir.setEnabled(false);
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonExcluir);
        jButtonExcluir.setBounds(10, 220, 100, 30);

        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisa.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTablePesquisa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisa);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(120, 140, 300, 110);

        jTextFieldPesquisa.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldPesquisa);
        jTextFieldPesquisa.setBounds(120, 100, 180, 30);

        jButtonPesquisarNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonPesquisarNome.setText("PESQUISAR");
        jButtonPesquisarNome.setBorderPainted(false);
        jButtonPesquisarNome.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonPesquisarNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarNomeActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonPesquisarNome);
        jButtonPesquisarNome.setBounds(310, 100, 110, 30);

        jTextFieldPreçoProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldPreçoProduto.setEnabled(false);
        jPanel1.add(jTextFieldPreçoProduto);
        jTextFieldPreçoProduto.setBounds(250, 60, 60, 30);

        jLabelIDProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelIDProduto.setText("ID");
        jPanel1.add(jLabelIDProduto);
        jLabelIDProduto.setBounds(120, 20, 20, 30);

        jTextFieldCodProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldCodProduto.setEnabled(false);
        jPanel1.add(jTextFieldCodProduto);
        jTextFieldCodProduto.setBounds(150, 20, 50, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 70, 430, 260);

        jLabelCad.setFont(new java.awt.Font("Tahoma", 0, 30)); // NOI18N
        jLabelCad.setText("CADASTRO DE SERVIÇOS");
        getContentPane().add(jLabelCad);
        jLabelCad.setBounds(50, 30, 350, 30);

        setSize(new java.awt.Dimension(463, 377));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
   if(jTextFieldNomeProduto.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o nome para continuar");
            jTextFieldNomeProduto.requestFocus();
        }
    else if(jTextFieldPreçoProduto.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o Preço para continuar");
            jTextFieldPreçoProduto.requestFocus();
        }
    if(flag==1)
        {
            mod.setNome(jTextFieldNomeProduto.getText());
            
            mod.setPreço(Double.parseDouble(jTextFieldPreçoProduto.getText()));    
            control.Salvar(mod);
            
            jTextFieldNomeProduto.setText("");
            jTextFieldPreçoProduto.setText("");
            
            jTextFieldNomeProduto.setEnabled(false);
            jTextFieldPreçoProduto.setEnabled(false);
            
            jButtonSalvar.setEnabled(false);
            jButtonCancelar.setEnabled(false);
            jButtonNovo.setEnabled(true);
            
            preencherTabela("select * from servico order by nome_serv");
        }
    else
        {
            mod.setCodigo((Integer.parseInt(jTextFieldCodProduto.getText())));
            mod.setNome(jTextFieldNomeProduto.getText());
            mod.setPreço(Double.parseDouble(jTextFieldPreçoProduto.getText()));
            control.Editar(mod);
                
            jTextFieldNomeProduto.setEnabled(false);
            jTextFieldPreçoProduto.setEnabled(false);
            jButtonSalvar.setEnabled(false);
            jButtonCancelar.setEnabled(false);  
                
            jTextFieldNomeProduto.setText("");
            jTextFieldPreçoProduto.setText("");
            jTextFieldCodProduto.setText("");
            jTextFieldPesquisa.setText("");
            jButtonNovo.setEnabled(true);
                
            preencherTabela("select * from servico order by nome_serv");
        }
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
    flag = 1;
    
    jTextFieldNomeProduto.setEnabled(true);
    jTextFieldPreçoProduto.setEnabled(true);
    
    jTextFieldNomeProduto.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    
    jButtonCancelar.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    
    jTextFieldNomeProduto.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldCodProduto.setText("");
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
    jTextFieldNomeProduto.setEnabled(!true);
    jTextFieldPreçoProduto.setEnabled(!true);
    jButtonSalvar.setEnabled(!true);
    jButtonCancelar.setEnabled(!true);
    jButtonNovo.setEnabled(true);
    jTextFieldPesquisa.setEnabled(true);
    jButtonPesquisarNome.setEnabled(true); 
    
    jButtonEditar.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    
    jTextFieldNomeProduto.setText("");
    jTextFieldPreçoProduto.setText("");
    jTextFieldPesquisa.setText("");
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jTablePesquisaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaMouseClicked
    String nome_serv = ""+jTablePesquisa.getValueAt(jTablePesquisa.getSelectedRow(), 1);
    conex.conexao();
    conex.executaSql("select * from servico where nome_serv ='"+nome_serv+"'");
    try 
        {      
            conex.rs.first();
            jTextFieldCodProduto.setText(String.valueOf(conex.rs.getInt("cod_serv")));
            jTextFieldNomeProduto.setText(conex.rs.getString("nome_serv"));
            jTextFieldPreçoProduto.setText(conex.rs.getString("preco_serv"));
        } 
    catch (SQLException ex) 
        {
                JOptionPane.showMessageDialog(rootPane, "Erro ao selecionar dados"+ex);
        }
    conex.desconecta();
    jButtonEditar.setEnabled(true);
    jButtonExcluir.setEnabled(true);
    }//GEN-LAST:event_jTablePesquisaMouseClicked

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
    flag = 2;
    
    jTextFieldNomeProduto.setEnabled(true);
    jTextFieldPreçoProduto.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    
    jButtonCancelar.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonNovo.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
    int resposta = 0;
    resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente excluir?");
    if(resposta==JOptionPane.YES_OPTION)
        {
            mod.setCodigo((Integer.parseInt(jTextFieldCodProduto.getText())));
            control.Excluir(mod);
            
            jButtonEditar.setEnabled(false);
            jButtonExcluir.setEnabled(false);
            jButtonCancelar.setEnabled(false);
            jButtonNovo.setEnabled(true);
            
            jTextFieldNomeProduto.setText("");
            jTextFieldPreçoProduto.setText("");
            jTextFieldCodProduto.setText("");
            jTextFieldPesquisa.setText("");
            
            preencherTabela("select * from servico order by nome_serv");
        }
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonPesquisarNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarNomeActionPerformed
    BeansServiço model = control.buscaProdutoNome(mod);
    mod.setPesquisa(jTextFieldPesquisa.getText());
        
    jTextFieldNomeProduto.setText(model.getNome());
    jTextFieldPreçoProduto.setText(String.valueOf(model.getPreço()));
    jTextFieldCodProduto.setText(String.valueOf(model.getCodigo()));
        
    jButtonEditar.setEnabled(true);
    jButtonExcluir.setEnabled(true);
        
    jButtonNovo.setEnabled(false);
    jButtonSalvar.setEnabled(false);
    jTextFieldNomeProduto.setEnabled(false);
    }//GEN-LAST:event_jButtonPesquisarNomeActionPerformed
    public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"cod"
                                             ,"nome"
                                             ,"preço"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]
                                                {
                                                   conex.rs.getInt("cod_serv")
                                                  ,conex.rs.getString("nome_serv")
                                                  ,conex.rs.getString("preco_serv")
                                                });
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTablePesquisa.setModel(modelo);
            jTablePesquisa.getColumnModel().getColumn(0).setPreferredWidth(30);
            jTablePesquisa.getColumnModel().getColumn(0).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(1).setPreferredWidth(207);
            jTablePesquisa.getColumnModel().getColumn(1).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(2).setPreferredWidth(60);
            jTablePesquisa.getColumnModel().getColumn(2).setResizable(false);
            
            jTablePesquisa.getTableHeader().setReorderingAllowed(false);
            jTablePesquisa.setAutoResizeMode(jTablePesquisa.AUTO_RESIZE_OFF);
            jTablePesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    public static void main(String args[]) 
        {
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                    {
                        new FormServiços().setVisible(true);
                    }
                });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonPesquisarNome;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JLabel jLabelCad;
    private javax.swing.JLabel jLabelIDProduto;
    private javax.swing.JLabel jLabelNomeProduto;
    private javax.swing.JLabel jLabelPreçoProduto;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextFieldCodProduto;
    private javax.swing.JTextField jTextFieldNomeProduto;
    private javax.swing.JTextField jTextFieldPesquisa;
    private javax.swing.JTextField jTextFieldPreçoProduto;
    // End of variables declaration//GEN-END:variables
}