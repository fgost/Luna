package ModeloBeans;

public class BeansUsuario{
    private String usuNome;
    private String usuTipo;
    private String usuSenha;
    private String usuPesquisa;
    private int usuCod;
    
    public String getUsuPesquisa(){
        return usuPesquisa;}
    public void setUsuPesquisa(String usuPesquisa){
        this.usuPesquisa = usuPesquisa;}
    public Integer getUsuCod(){
        return usuCod;}
    public void setUsuCod(Integer usuCod){
        this.usuCod = usuCod;}
    public String getUsuNome(){
        return usuNome;}
    public void setUsuNome(String usuNome){
        this.usuNome = usuNome;}
    public String getUsuTipo(){
        return usuTipo;}
    public void setUsuTipo(String usuTipo){
        this.usuTipo = usuTipo;}
    public String getUsuSenha(){   
        return usuSenha;}
    public void setUsuSenha(String usuSenha){
        this.usuSenha = usuSenha;}}