package visao;

import ModeloBeans.ModeloTabela;
import ModeloConection.ConexaoBD;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormContasRelato extends javax.swing.JFrame 
    {
        ConexaoBD conex = new ConexaoBD();
        
        public FormContasRelato() 
            {
                initComponents();
                preencherTabela("select * from conta order by datas");
            }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jTextFieldNome = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldData = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 48)); // NOI18N
        jLabel1.setText("STATUS DAS CONTAS");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(240, 10, 470, 40);

        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTablePesquisa);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(10, 60, 530, 402);
        getContentPane().add(jTextFieldNome);
        jTextFieldNome.setBounds(610, 80, 130, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("DATA");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(560, 120, 40, 30);
        getContentPane().add(jTextFieldData);
        jTextFieldData.setBounds(610, 120, 130, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("NOME");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(560, 80, 40, 30);

        jButton1.setText("BUSCAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(760, 120, 100, 30);

        jButton2.setText("BUSCAR");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(760, 80, 100, 30);

        jButton3.setText("RESTAURAR CONSULTA");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3);
        jButton3.setBounds(630, 180, 200, 40);

        setSize(new java.awt.Dimension(929, 536));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    preencherTabela("SELECT * FROM conta where SUBSTRING(datas, 4, 2) like '"+jTextFieldData.getText()+"' ORDER BY datas");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    preencherTabela("SELECT * FROM conta where nome like '"+jTextFieldNome.getText()+"' order by datas");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
    preencherTabela("SELECT * FROM conta order by datas");
    }//GEN-LAST:event_jButton3ActionPerformed
    public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"ID"
                                             ,"DATA"
                                             ,"NOME"
                                             ,"TIPO"
                                             ,"FORNECEDOR"
                                             ,"TOTAL"
                                             ,"STATUS"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{  conex.rs.getInt("cod")
                                                    ,conex.rs.getString("datas")
                                                    ,conex.rs.getString("nome")
                                                    ,conex.rs.getString("tipo")
                                                    ,conex.rs.getString("fornecedor")
                                                    ,conex.rs.getDouble("total")
                                                    ,conex.rs.getString("status")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados\n"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTablePesquisa.setModel(modelo);
            
            jTablePesquisa.getColumnModel().getColumn(0).setPreferredWidth(35);
            jTablePesquisa.getColumnModel().getColumn(0).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(1).setPreferredWidth(75);
            jTablePesquisa.getColumnModel().getColumn(1).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(2).setPreferredWidth(98);
            jTablePesquisa.getColumnModel().getColumn(2).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(3).setPreferredWidth(80);
            jTablePesquisa.getColumnModel().getColumn(3).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(4).setPreferredWidth(100);
            jTablePesquisa.getColumnModel().getColumn(4).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(5).setPreferredWidth(60);
            jTablePesquisa.getColumnModel().getColumn(5).setResizable(false);
            
            jTablePesquisa.getTableHeader().setReorderingAllowed(false);
            jTablePesquisa.setAutoResizeMode(jTablePesquisa.AUTO_RESIZE_OFF);
            jTablePesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormContasRelato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormContasRelato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormContasRelato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormContasRelato.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormContasRelato().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JList<String> jList1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextFieldData;
    private javax.swing.JTextField jTextFieldNome;
    // End of variables declaration//GEN-END:variables
}
