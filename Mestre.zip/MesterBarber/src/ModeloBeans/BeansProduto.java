package ModeloBeans;

public class BeansProduto{
    private String nome;
    private String tipo;
    private String Pesquisa;
    private int qtd;
    private int cod;
    private double preco;

    public int getQtd(){
        return qtd;}
    public void setQtd(int qtd){
        this.qtd = qtd;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public int getCod(){
        return cod;}
    public void setCod(int cod){
        this.cod = cod;}
    public double getPreco(){
        return preco;}
    public void setPreco(double preco){
        this.preco = preco;}
    public String getTipo(){
        return tipo;}
    public void setTipo(String tipo){
        this.tipo = tipo;}
    public String getPesquisa(){
        return Pesquisa;}
    public void setPesquisa(String Pesquisa){
        this.Pesquisa = Pesquisa;}}