package visao;

import ModeloBeans.BeansPagamento;
import ModeloBeans.ModeloTabela;
import ModeloConection.ConexaoBD;
import ModeloDao.DaoPagamento;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormPagamento extends javax.swing.JFrame {

        BeansPagamento mod = new BeansPagamento();
        DaoPagamento control = new DaoPagamento();
        ConexaoBD conex = new ConexaoBD();
    
    
    public FormPagamento() {
        initComponents();
        preencherFuncionario();
        preencherCargo();
        
        preencherTabela("select * from caixa order by nome");        
    }
    
    public void preencherFuncionario()
            {
                conex.conexao();
                conex.executaSql("select * from funcionario order by nome_Funcionario");
                try
                    {
                        conex.rs.first();
                        jComboBoxFuncionario.removeAllItems();
                        do
                            {
                                jComboBoxFuncionario.addItem(conex.rs.getString("nome_funcionario"));
                            }
                        
                        while(conex.rs.next());
                    }
                catch (SQLException ex)
                    {
                        JOptionPane.showMessageDialog(rootPane, "Erro ao preencher funcionario\n"+ex);
                    }
                conex.desconecta();
            }
    public void preencherCargo()
    {
        conex.conexao();
                conex.executaSql("select * from funcionario order by nome_Funcionario");
                try
                    {
                        conex.rs.first();
                        jComboBoxCargo.removeAllItems();
                        do
                            {
                                jComboBoxCargo.addItem(conex.rs.getString("cargo_funcionario"));
                            }
                        
                        while(conex.rs.next());
                    }
                catch (SQLException ex)
                    {
                        JOptionPane.showMessageDialog(rootPane, "Erro ao preencher cargo\n"+ex);
                    }
                conex.desconecta();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton4 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextFieldTotalOutros = new javax.swing.JTextField();
        jTextFieldQtdCortes = new javax.swing.JTextField();
        jTextFieldTotal = new javax.swing.JTextField();
        jComboBoxCargo = new javax.swing.JComboBox<>();
        jComboBoxFuncionario = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jButtonAbrirFuncionario = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jTextFieldPreçoCortes = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextFieldServiço3 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTextFieldPreço3 = new javax.swing.JTextField();
        jButtonHabilitarOutros = new javax.swing.JButton();
        jButtonAbriMes = new javax.swing.JButton();
        jTextFieldMes = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jTextFieldQtd3 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jTextFieldServiço1 = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jTextFieldPreço1 = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jTextFieldQtd1 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jTextFieldServiço2 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jTextFieldPreço2 = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jTextFieldQtd2 = new javax.swing.JTextField();
        jButtonAplicar = new javax.swing.JButton();
        jTextFieldDesconto = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jButtonAplicar1 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        jButton4.setText("jButton4");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setText("CALCULO DO PAGAMENTO");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 10, 450, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("FUNCIONARIO");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(10, 110, 110, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("CARGO");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(30, 150, 60, 30);

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("QUANTIDADE DE CORTES");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(10, 320, 170, 30);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("DESCONTOS");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(60, 570, 90, 30);

        jTextFieldTotalOutros.setEnabled(false);
        getContentPane().add(jTextFieldTotalOutros);
        jTextFieldTotalOutros.setBounds(310, 520, 120, 30);

        jTextFieldQtdCortes.setEnabled(false);
        getContentPane().add(jTextFieldQtdCortes);
        jTextFieldQtdCortes.setBounds(180, 320, 60, 30);

        jTextFieldTotal.setEnabled(false);
        getContentPane().add(jTextFieldTotal);
        jTextFieldTotal.setBounds(170, 610, 120, 30);

        jComboBoxCargo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        getContentPane().add(jComboBoxCargo);
        jComboBoxCargo.setBounds(110, 150, 220, 30);

        jComboBoxFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        getContentPane().add(jComboBoxFuncionario);
        jComboBoxFuncionario.setBounds(110, 110, 220, 30);

        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTablePesquisa);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(10, 190, 440, 120);

        jButtonAbrirFuncionario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonAbrirFuncionario.setText("ABRIR");
        jButtonAbrirFuncionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirFuncionarioActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbrirFuncionario);
        jButtonAbrirFuncionario.setBounds(340, 130, 100, 30);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("PREÇO");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(260, 320, 60, 30);

        jTextFieldPreçoCortes.setEnabled(false);
        getContentPane().add(jTextFieldPreçoCortes);
        jTextFieldPreçoCortes.setBounds(320, 320, 60, 30);

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("OUTROS");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(200, 360, 60, 30);

        jTextFieldServiço3.setEnabled(false);
        getContentPane().add(jTextFieldServiço3);
        jTextFieldServiço3.setBounds(80, 480, 150, 30);

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("PREÇO");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(240, 480, 60, 30);

        jTextFieldPreço3.setEnabled(false);
        getContentPane().add(jTextFieldPreço3);
        jTextFieldPreço3.setBounds(300, 480, 40, 30);

        jButtonHabilitarOutros.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonHabilitarOutros.setText("HABILITAR");
        jButtonHabilitarOutros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonHabilitarOutrosActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonHabilitarOutros);
        jButtonHabilitarOutros.setBounds(340, 360, 110, 30);

        jButtonAbriMes.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButtonAbriMes.setText("ABRIR");
        jButtonAbriMes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbriMesActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbriMes);
        jButtonAbriMes.setBounds(333, 50, 100, 40);

        jTextFieldMes.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        getContentPane().add(jTextFieldMes);
        jTextFieldMes.setBounds(260, 50, 70, 40);

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel10.setText("REFERENTE AO MES");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(30, 50, 217, 40);

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("SERVIÇO");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(10, 480, 60, 30);

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setText("QTD");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(350, 480, 40, 30);

        jTextFieldQtd3.setEnabled(false);
        getContentPane().add(jTextFieldQtd3);
        jTextFieldQtd3.setBounds(390, 480, 40, 30);

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel16.setText("SERVIÇO");
        getContentPane().add(jLabel16);
        jLabel16.setBounds(10, 400, 60, 30);

        jTextFieldServiço1.setEnabled(false);
        getContentPane().add(jTextFieldServiço1);
        jTextFieldServiço1.setBounds(80, 400, 150, 30);

        jLabel17.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel17.setText("PREÇO");
        getContentPane().add(jLabel17);
        jLabel17.setBounds(240, 400, 60, 30);

        jTextFieldPreço1.setEnabled(false);
        getContentPane().add(jTextFieldPreço1);
        jTextFieldPreço1.setBounds(300, 400, 40, 30);

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel18.setText("QTD");
        getContentPane().add(jLabel18);
        jLabel18.setBounds(350, 400, 40, 30);

        jTextFieldQtd1.setEnabled(false);
        getContentPane().add(jTextFieldQtd1);
        jTextFieldQtd1.setBounds(390, 400, 40, 30);

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel19.setText("SERVIÇO");
        getContentPane().add(jLabel19);
        jLabel19.setBounds(10, 440, 60, 30);

        jTextFieldServiço2.setEnabled(false);
        getContentPane().add(jTextFieldServiço2);
        jTextFieldServiço2.setBounds(80, 440, 150, 30);

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel20.setText("PREÇO");
        getContentPane().add(jLabel20);
        jLabel20.setBounds(240, 440, 60, 30);

        jTextFieldPreço2.setEnabled(false);
        getContentPane().add(jTextFieldPreço2);
        jTextFieldPreço2.setBounds(300, 440, 40, 30);

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel21.setText("QTD");
        getContentPane().add(jLabel21);
        jLabel21.setBounds(350, 440, 40, 30);

        jTextFieldQtd2.setEnabled(false);
        getContentPane().add(jTextFieldQtd2);
        jTextFieldQtd2.setBounds(390, 440, 40, 30);

        jButtonAplicar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonAplicar.setText("TOTAL OUTROS");
        jButtonAplicar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAplicarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAplicar);
        jButtonAplicar.setBounds(150, 520, 140, 30);
        getContentPane().add(jTextFieldDesconto);
        jTextFieldDesconto.setBounds(170, 570, 120, 30);

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("TOTAL");
        getContentPane().add(jLabel13);
        jLabel13.setBounds(70, 610, 60, 30);

        jButtonAplicar1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonAplicar1.setText("APLICAR");
        jButtonAplicar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAplicar1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAplicar1);
        jButtonAplicar1.setBounds(320, 570, 110, 30);

        jButton1.setText("SALVAR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(320, 610, 110, 30);

        setSize(new java.awt.Dimension(1142, 690));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAbrirFuncionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirFuncionarioActionPerformed
    preencherTabela("select * from caixa  WHERE barbeiro in ('"+((String)(jComboBoxFuncionario.getSelectedItem()))+"') order by nome"); 
    jTextFieldQtdCortes.setEnabled(true);
    jTextFieldPreçoCortes.setEnabled(true);
    }//GEN-LAST:event_jButtonAbrirFuncionarioActionPerformed

    private void jButtonAbriMesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbriMesActionPerformed
    preencherTabela("select * from caixa  WHERE SUBSTRING(datas,4,2) like '"+jTextFieldMes.getText()+"' order by nome"); 
    }//GEN-LAST:event_jButtonAbriMesActionPerformed

    private void jButtonHabilitarOutrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonHabilitarOutrosActionPerformed
        jTextFieldServiço1.setEnabled(true);
        jTextFieldServiço2.setEnabled(true);
        jTextFieldServiço3.setEnabled(true);
        jTextFieldPreço1.setEnabled(true);
        jTextFieldPreço2.setEnabled(true);
        jTextFieldPreço3.setEnabled(true);
        jTextFieldQtd1.setEnabled(true);
        jTextFieldQtd2.setEnabled(true);
        jTextFieldQtd3.setEnabled(true);
    }//GEN-LAST:event_jButtonHabilitarOutrosActionPerformed

    private void jButtonAplicarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAplicarActionPerformed
    if(jTextFieldServiço1.getText().isEmpty())
        {
            double i = 0.00;
            int b = 0;
            jTextFieldTotalOutros.setText(String.valueOf(i));  
            jTextFieldPreço1.setText(String.valueOf(i));
            jTextFieldPreço2.setText(String.valueOf(i));
            jTextFieldPreço3.setText(String.valueOf(i));
            jTextFieldQtd1.setText(String.valueOf(b));
            jTextFieldQtd2.setText(String.valueOf(b));
            jTextFieldQtd3.setText(String.valueOf(b));
        }
    else
        {
            double precoserviço1 = Double.parseDouble(jTextFieldPreço1.getText());
            double precoserviço2 = Double.parseDouble(jTextFieldPreço2.getText());
            double precoserviço3 = Double.parseDouble(jTextFieldPreço3.getText());
    
            int qtd1 = Integer.parseInt(jTextFieldQtd1.getText());
            int qtd2 = Integer.parseInt(jTextFieldQtd2.getText());
            int qtd3 = Integer.parseInt(jTextFieldQtd3.getText());
    
            double d = (precoserviço1*qtd1) + (precoserviço2*qtd2) + (precoserviço3*qtd3);    
            jTextFieldTotalOutros.setText(String.valueOf(d)); 
        }
    }//GEN-LAST:event_jButtonAplicarActionPerformed

    private void jButtonAplicar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAplicar1ActionPerformed
    int a = Integer.parseInt(jTextFieldQtdCortes.getText());
    double b = Double.parseDouble(jTextFieldPreçoCortes.getText());
    double c = Double.parseDouble(jTextFieldTotalOutros.getText());
    double d = Double.parseDouble(jTextFieldDesconto.getText());

    double e=a*b;
    double f= (e+c)-d;
    
    jTextFieldTotal.setText(String.valueOf(f)); 
    }//GEN-LAST:event_jButtonAplicar1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    mod.setCargo((String)jComboBoxCargo.getSelectedItem());
    mod.setFunicionario((String)jComboBoxFuncionario.getSelectedItem());
    mod.setDescontos(Double.parseDouble(jTextFieldDesconto.getText()));
    mod.setMes(jTextFieldMes.getText());
    mod.setPreco_cortes(Double.parseDouble(jTextFieldPreçoCortes.getText()));
    mod.setPreco_servico1(Double.parseDouble(jTextFieldPreço1.getText()));
    mod.setPreco_servico2(Double.parseDouble(jTextFieldPreço2.getText()));
    mod.setPreco_servico3(Double.parseDouble(jTextFieldPreço3.getText()));
    mod.setQtd_cortes(Integer.parseInt(jTextFieldQtdCortes.getText()));
    mod.setQtd_servico1(Integer.parseInt(jTextFieldQtd1.getText()));
    mod.setQtd_servico2(Integer.parseInt(jTextFieldQtd2.getText()));
    mod.setQtd_servico3(Integer.parseInt(jTextFieldQtd3.getText()));
    mod.setServico1(jTextFieldServiço1.getText());
    mod.setServico2(jTextFieldServiço2.getText());
    mod.setServico3(jTextFieldServiço3.getText());
    mod.setTotal(Double.parseDouble(jTextFieldTotal.getText()));
    mod.setTotal_servicos(Double.parseDouble(jTextFieldTotalOutros.getText()));
    control.Salvar(mod);
    }//GEN-LAST:event_jButton1ActionPerformed

    public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"CLIENTE"
                                             ,"DATA"
                                             ,"SERVIÇO"
                                             ,"TIPO DO CORTE"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{  conex.rs.getString("nome")
                                                    ,conex.rs.getString("datas")
                                                    ,conex.rs.getString("servico")
                                                    ,conex.rs.getString("tipocorte")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTablePesquisa.setModel(modelo);
            
            jTablePesquisa.getColumnModel().getColumn(0).setPreferredWidth(110);
            jTablePesquisa.getColumnModel().getColumn(0).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(1).setPreferredWidth(75);
            jTablePesquisa.getColumnModel().getColumn(1).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(2).setPreferredWidth(117);
            jTablePesquisa.getColumnModel().getColumn(2).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(3).setPreferredWidth(117);
            jTablePesquisa.getColumnModel().getColumn(3).setResizable(false);
            
            jTablePesquisa.getTableHeader().setReorderingAllowed(false);
            jTablePesquisa.setAutoResizeMode(jTablePesquisa.AUTO_RESIZE_OFF);
            jTablePesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormPagamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormPagamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormPagamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormPagamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormPagamento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButtonAbriMes;
    private javax.swing.JButton jButtonAbrirFuncionario;
    private javax.swing.JButton jButtonAplicar;
    private javax.swing.JButton jButtonAplicar1;
    private javax.swing.JButton jButtonHabilitarOutros;
    private javax.swing.JComboBox<String> jComboBoxCargo;
    private javax.swing.JComboBox<String> jComboBoxFuncionario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextFieldDesconto;
    private javax.swing.JTextField jTextFieldMes;
    private javax.swing.JTextField jTextFieldPreço1;
    private javax.swing.JTextField jTextFieldPreço2;
    private javax.swing.JTextField jTextFieldPreço3;
    private javax.swing.JTextField jTextFieldPreçoCortes;
    private javax.swing.JTextField jTextFieldQtd1;
    private javax.swing.JTextField jTextFieldQtd2;
    private javax.swing.JTextField jTextFieldQtd3;
    private javax.swing.JTextField jTextFieldQtdCortes;
    private javax.swing.JTextField jTextFieldServiço1;
    private javax.swing.JTextField jTextFieldServiço2;
    private javax.swing.JTextField jTextFieldServiço3;
    private javax.swing.JTextField jTextFieldTotal;
    private javax.swing.JTextField jTextFieldTotalOutros;
    // End of variables declaration//GEN-END:variables
}
