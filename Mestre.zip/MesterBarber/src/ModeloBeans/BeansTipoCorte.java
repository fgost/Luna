package ModeloBeans;

public class BeansTipoCorte{
    private String nome;
    private String pesquisa;
    private int cod;
    
    public int getCod(){
        return cod;}
    public void setCod(int cod){
        this.cod = cod;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public String getPesquisa(){
        return pesquisa;}
    public void setPesquisa(String pesquisa){
        this.pesquisa = pesquisa;}}