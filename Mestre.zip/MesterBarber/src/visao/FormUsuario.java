package visao;

import ModeloBeans.BeansUsuario;
import ModeloDao.DaoUsuario;
import ModeloBeans.ModeloTabela;
import ModeloConection.ConexaoBD;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormUsuario extends javax.swing.JFrame 
    {
        ConexaoBD conex = new ConexaoBD();
        BeansUsuario mod = new BeansUsuario();
        DaoUsuario dao = new DaoUsuario();
        int flag=0;
    
    public FormUsuario() 
        {
            initComponents();
            preencherTabela("select * from usuarios order by usu_nome");
        }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelUsuario = new javax.swing.JLabel();
        jLabelUsuarioSenha = new javax.swing.JLabel();
        jLabelConfirmarSenha = new javax.swing.JLabel();
        jLabelTipoUsuario = new javax.swing.JLabel();
        jTextFieldUsuario = new javax.swing.JTextField();
        jPasswordFieldSenhaUsuario = new javax.swing.JPasswordField();
        jPasswordFieldConfirmarSenhaUsuario = new javax.swing.JPasswordField();
        jComboBoxTipoUsuario = new javax.swing.JComboBox<>();
        jButtonNovoUsuario = new javax.swing.JButton();
        jButtonSalvarUsuario = new javax.swing.JButton();
        jButtonCancelarUsuario = new javax.swing.JButton();
        jButtonAlterarUsuario = new javax.swing.JButton();
        jButtonExcluirUsuario = new javax.swing.JButton();
        jButtonPesquisarUsuario = new javax.swing.JButton();
        jTextFieldPesquisarUsuario = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableUsuarios = new javax.swing.JTable();
        jLabelID = new javax.swing.JLabel();
        jTextFieldCOD = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabelUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelUsuario.setText("USUÁRIO");
        jPanel1.add(jLabelUsuario);
        jLabelUsuario.setBounds(230, 50, 70, 30);

        jLabelUsuarioSenha.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelUsuarioSenha.setText("SENHA");
        jPanel1.add(jLabelUsuarioSenha);
        jLabelUsuarioSenha.setBounds(120, 110, 42, 30);

        jLabelConfirmarSenha.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelConfirmarSenha.setText("CONFIRMAR SENHA");
        jPanel1.add(jLabelConfirmarSenha);
        jLabelConfirmarSenha.setBounds(300, 110, 130, 28);

        jLabelTipoUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelTipoUsuario.setText("TIPO");
        jPanel1.add(jLabelTipoUsuario);
        jLabelTipoUsuario.setBounds(420, 50, 30, 30);

        jTextFieldUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldUsuario.setEnabled(false);
        jPanel1.add(jTextFieldUsuario);
        jTextFieldUsuario.setBounds(300, 50, 110, 32);

        jPasswordFieldSenhaUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPasswordFieldSenhaUsuario.setEnabled(false);
        jPanel1.add(jPasswordFieldSenhaUsuario);
        jPasswordFieldSenhaUsuario.setBounds(170, 110, 110, 29);

        jPasswordFieldConfirmarSenhaUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPasswordFieldConfirmarSenhaUsuario.setEnabled(false);
        jPanel1.add(jPasswordFieldConfirmarSenhaUsuario);
        jPasswordFieldConfirmarSenhaUsuario.setBounds(440, 110, 110, 31);

        jComboBoxTipoUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxTipoUsuario.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Administrador", "Barbeiro", "Gerente" }));
        jComboBoxTipoUsuario.setEnabled(false);
        jPanel1.add(jComboBoxTipoUsuario);
        jComboBoxTipoUsuario.setBounds(460, 50, 150, 30);

        jButtonNovoUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonNovoUsuario.setText("NOVO");
        jButtonNovoUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonNovoUsuario);
        jButtonNovoUsuario.setBounds(10, 10, 100, 31);

        jButtonSalvarUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonSalvarUsuario.setText("SALVAR");
        jButtonSalvarUsuario.setEnabled(false);
        jButtonSalvarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalvarUsuario);
        jButtonSalvarUsuario.setBounds(10, 50, 100, 31);

        jButtonCancelarUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonCancelarUsuario.setText("CANCELAR");
        jButtonCancelarUsuario.setEnabled(false);
        jButtonCancelarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCancelarUsuario);
        jButtonCancelarUsuario.setBounds(10, 90, 100, 31);

        jButtonAlterarUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonAlterarUsuario.setText("ALTERAR");
        jButtonAlterarUsuario.setEnabled(false);
        jButtonAlterarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAlterarUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonAlterarUsuario);
        jButtonAlterarUsuario.setBounds(10, 130, 100, 31);

        jButtonExcluirUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonExcluirUsuario.setText("EXCLUIR");
        jButtonExcluirUsuario.setEnabled(false);
        jButtonExcluirUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonExcluirUsuario);
        jButtonExcluirUsuario.setBounds(10, 170, 100, 31);

        jButtonPesquisarUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonPesquisarUsuario.setText("BUSCAR");
        jButtonPesquisarUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarUsuarioActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonPesquisarUsuario);
        jButtonPesquisarUsuario.setBounds(500, 180, 100, 30);

        jTextFieldPesquisarUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldPesquisarUsuario);
        jTextFieldPesquisarUsuario.setBounds(140, 180, 340, 31);

        jTableUsuarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableUsuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableUsuariosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableUsuarios);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(22, 220, 580, 150);

        jLabelID.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelID.setText("ID");
        jPanel1.add(jLabelID);
        jLabelID.setBounds(120, 50, 20, 30);

        jTextFieldCOD.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldCOD.setText(" ");
        jTextFieldCOD.setEnabled(false);
        jPanel1.add(jTextFieldCOD);
        jTextFieldCOD.setBounds(150, 50, 70, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 61, 620, 390);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setText("Cadastro de Usuários");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(140, 10, 340, 44);

        setSize(new java.awt.Dimension(659, 511));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonNovoUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoUsuarioActionPerformed
    flag = 1;
    jTextFieldUsuario.setEnabled(true);
    jComboBoxTipoUsuario.setEnabled(true);
    jPasswordFieldSenhaUsuario.setEnabled(true);
    jPasswordFieldConfirmarSenhaUsuario.setEnabled(true);
    jButtonSalvarUsuario.setEnabled(true);
    jButtonCancelarUsuario.setEnabled(true);
    jButtonPesquisarUsuario.setEnabled(false);
    jTextFieldPesquisarUsuario.setEnabled(false);
    jTextFieldUsuario.setText("");
    jTextFieldCOD.setText("");
    jPasswordFieldConfirmarSenhaUsuario.setText("");
    jPasswordFieldSenhaUsuario.setText("");
    jTextFieldPesquisarUsuario.setText("");
    }//GEN-LAST:event_jButtonNovoUsuarioActionPerformed

    private void jButtonSalvarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarUsuarioActionPerformed
    if(jTextFieldUsuario.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o usuario para continuar");
            jTextFieldUsuario.requestFocus();
        }
        else if(jPasswordFieldConfirmarSenhaUsuario.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Confirme a senha para continuar");
                jPasswordFieldConfirmarSenhaUsuario.requestFocus();
            }
        else if(jPasswordFieldSenhaUsuario.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Preencha a senha para continuar");
                jPasswordFieldSenhaUsuario.requestFocus();
            }else 
        if(jPasswordFieldSenhaUsuario.getText().equals(jPasswordFieldConfirmarSenhaUsuario.getText())) 
            {
                if(flag==1)
                    {
                        mod.setUsuNome(jTextFieldUsuario.getText());
                        mod.setUsuTipo((String)jComboBoxTipoUsuario.getSelectedItem());
                        mod.setUsuSenha(jPasswordFieldSenhaUsuario.getText());        
                        dao.Salvar(mod);
                        preencherTabela("select * from usuarios order by usu_nome");
                        jTextFieldUsuario.setText("");
                        jPasswordFieldSenhaUsuario.setText("");
                        jPasswordFieldConfirmarSenhaUsuario.setText("");
                        jTextFieldUsuario.setEnabled(false);
                        jPasswordFieldSenhaUsuario.setEnabled(false);
                        jPasswordFieldConfirmarSenhaUsuario.setEnabled(false);
                        jComboBoxTipoUsuario.setEnabled(false);
                        jButtonSalvarUsuario.setEnabled(false);
                        jButtonCancelarUsuario.setEnabled(false);
                    }
                else
                    {
                        mod.setUsuCod((Integer.parseInt(jTextFieldCOD.getText())));
                        mod.setUsuNome(jTextFieldUsuario.getText());
                        mod.setUsuTipo((String)jComboBoxTipoUsuario.getSelectedItem());
                        mod.setUsuSenha(jPasswordFieldSenhaUsuario.getText());  
                        mod.setUsuSenha(jPasswordFieldConfirmarSenhaUsuario.getText());  
                        dao.Editar(mod);                     
                        jTextFieldUsuario.setEnabled(false);
                        jPasswordFieldConfirmarSenhaUsuario.setEnabled(false);
                        jPasswordFieldSenhaUsuario.setEnabled(false);
                        jComboBoxTipoUsuario.setEnabled(false);
                        jButtonSalvarUsuario.setEnabled(false);
                        jButtonCancelarUsuario.setEnabled(false);  
                        jTextFieldUsuario.setText("");
                        jPasswordFieldConfirmarSenhaUsuario.setText("");
                        jPasswordFieldSenhaUsuario.setText("");
                        jTextFieldCOD.setText("");
                        jTextFieldPesquisarUsuario.setText("");
                        jButtonNovoUsuario.setEnabled(true);
                        preencherTabela("select * from usuarios order by usu_nome");
                    }
            }
            else
                {
                    JOptionPane.showMessageDialog(rootPane, "as senhas não são iguais");
                }
    }//GEN-LAST:event_jButtonSalvarUsuarioActionPerformed

    private void jButtonPesquisarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarUsuarioActionPerformed
    mod.setUsuPesquisa(jTextFieldPesquisarUsuario.getText());
    BeansUsuario model = dao.buscaUsuario(mod);
    jTextFieldUsuario.setText(model.getUsuNome());
    jPasswordFieldConfirmarSenhaUsuario.setText(model.getUsuSenha());
    jPasswordFieldSenhaUsuario.setText(model.getUsuSenha());
    jComboBoxTipoUsuario.setSelectedItem(model.getUsuTipo());
    jTextFieldCOD.setText(String.valueOf(model.getUsuCod()));
    jButtonSalvarUsuario.setEnabled(false);
    jTextFieldUsuario.setEnabled(false);
    jPasswordFieldConfirmarSenhaUsuario.setEnabled(false);
    jPasswordFieldSenhaUsuario.setEnabled(false);
    jComboBoxTipoUsuario.setEnabled(false);
    jButtonAlterarUsuario.setEnabled(true);
    jButtonExcluirUsuario.setEnabled(true);
    }//GEN-LAST:event_jButtonPesquisarUsuarioActionPerformed

    private void jButtonAlterarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAlterarUsuarioActionPerformed
    flag = 2;
    jTextFieldUsuario.setEnabled(true);
    jComboBoxTipoUsuario.setEnabled(true);
    jPasswordFieldSenhaUsuario.setEnabled(true);
    jPasswordFieldConfirmarSenhaUsuario.setEnabled(true);
    jButtonSalvarUsuario.setEnabled(true);
    jButtonCancelarUsuario.setEnabled(true);
    jButtonAlterarUsuario.setEnabled(false);
    jButtonExcluirUsuario.setEnabled(false);
    jButtonNovoUsuario.setEnabled(false);
    jButtonPesquisarUsuario.setEnabled(false);
    jTextFieldPesquisarUsuario.setEnabled(false);
    }//GEN-LAST:event_jButtonAlterarUsuarioActionPerformed

    private void jButtonExcluirUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirUsuarioActionPerformed
    int resposta = 0;
    resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente excluir?");
    if(resposta==JOptionPane.YES_OPTION)
        {
            mod.setUsuCod(Integer.parseInt(jTextFieldCOD.getText()));
            dao.Excluir(mod);
            preencherTabela("select * from usuarios order by usu_nome");
            jButtonAlterarUsuario.setEnabled(false);
            jButtonExcluirUsuario.setEnabled(false);
            jButtonCancelarUsuario.setEnabled(false);
            jButtonNovoUsuario.setEnabled(true);
            jTextFieldUsuario.setText("");
            jTextFieldCOD.setText("");
            jPasswordFieldConfirmarSenhaUsuario.setText("");
            jPasswordFieldSenhaUsuario.setText("");
            jTextFieldPesquisarUsuario.setText("");
        }
    }//GEN-LAST:event_jButtonExcluirUsuarioActionPerformed

    private void jTableUsuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableUsuariosMouseClicked
    String usu_nome = ""+jTableUsuarios.getValueAt(jTableUsuarios.getSelectedRow(), 1);
    conex.conexao();
    conex.executaSql("select * from usuarios where usu_nome ='"+usu_nome+"'");
    try 
        {      
            conex.rs.first();
            jTextFieldCOD.setText(String.valueOf(conex.rs.getInt("usu_cod")));
            jTextFieldUsuario.setText(conex.rs.getString("usu_nome"));
            jComboBoxTipoUsuario.setSelectedItem(conex.rs.getString("usu_tipo"));
            jPasswordFieldSenhaUsuario.setText(conex.rs.getString("usu_senha"));
            jPasswordFieldConfirmarSenhaUsuario.setText(conex.rs.getString("usu_senha"));
        } 
    catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(rootPane, "Erro ao selecionar dados"+ex);
        }
    conex.desconecta();
    jButtonAlterarUsuario.setEnabled(true);
    jButtonExcluirUsuario.setEnabled(true);
    }//GEN-LAST:event_jTableUsuariosMouseClicked

    private void jButtonCancelarUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarUsuarioActionPerformed
    jTextFieldUsuario.setEnabled(!true);
    jPasswordFieldConfirmarSenhaUsuario.setEnabled(!true);
    jPasswordFieldSenhaUsuario.setEnabled(!true);
    jComboBoxTipoUsuario.setEnabled(!true);
    jButtonSalvarUsuario.setEnabled(!true);
    jButtonCancelarUsuario.setEnabled(!true);
    jButtonNovoUsuario.setEnabled(true);
    jButtonAlterarUsuario.setEnabled(false);
    jButtonExcluirUsuario.setEnabled(false);
    jTextFieldUsuario.setText("");
    jPasswordFieldSenhaUsuario.setText("");
    jTextFieldCOD.setText("");
    jPasswordFieldConfirmarSenhaUsuario.setText("");
    jTextFieldPesquisarUsuario.setText("");
    jTextFieldPesquisarUsuario.setEnabled(true);
    jButtonPesquisarUsuario.setEnabled(true);
    }//GEN-LAST:event_jButtonCancelarUsuarioActionPerformed
     public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"id","usuario","senha","tipo"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{conex.rs.getInt("usu_cod"),conex.rs.getString("usu_nome"),conex.rs.getString("usu_senha"),conex.rs.getString("usu_tipo")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao selecionar dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTableUsuarios.setModel(modelo);
            jTableUsuarios.getColumnModel().getColumn(0).setPreferredWidth(50);
            jTableUsuarios.getColumnModel().getColumn(0).setResizable(false);
            jTableUsuarios.getColumnModel().getColumn(1).setPreferredWidth(194);
            jTableUsuarios.getColumnModel().getColumn(1).setResizable(false);
            jTableUsuarios.getColumnModel().getColumn(2).setPreferredWidth(190);
            jTableUsuarios.getColumnModel().getColumn(2).setResizable(false);
            jTableUsuarios.getColumnModel().getColumn(3).setPreferredWidth(110);
            jTableUsuarios.getColumnModel().getColumn(3).setResizable(false);
            jTableUsuarios.getTableHeader().setReorderingAllowed(false);
            jTableUsuarios.setAutoResizeMode(jTableUsuarios.AUTO_RESIZE_OFF);
            jTableUsuarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    
    public static void main(String args[]) 
        {
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                        {
                            new FormUsuario().setVisible(true);
                        }
                });
        }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAlterarUsuario;
    private javax.swing.JButton jButtonCancelarUsuario;
    private javax.swing.JButton jButtonExcluirUsuario;
    private javax.swing.JButton jButtonNovoUsuario;
    private javax.swing.JButton jButtonPesquisarUsuario;
    private javax.swing.JButton jButtonSalvarUsuario;
    private javax.swing.JComboBox<String> jComboBoxTipoUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelConfirmarSenha;
    private javax.swing.JLabel jLabelID;
    private javax.swing.JLabel jLabelTipoUsuario;
    private javax.swing.JLabel jLabelUsuario;
    private javax.swing.JLabel jLabelUsuarioSenha;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordFieldConfirmarSenhaUsuario;
    private javax.swing.JPasswordField jPasswordFieldSenhaUsuario;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableUsuarios;
    private javax.swing.JTextField jTextFieldCOD;
    private javax.swing.JTextField jTextFieldPesquisarUsuario;
    private javax.swing.JTextField jTextFieldUsuario;
    // End of variables declaration//GEN-END:variables
    }