package ModeloDao;

import ModeloBeans.BeansServiço;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoServiço {
    ConexaoBD conex = new ConexaoBD();
        BeansServiço mod = new BeansServiço();
    
        public void Salvar(BeansServiço mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("insert into servico (nome_serv,preco_serv) values(?,?)");
                        pst.setString(1, mod.getNome());
                        pst.setDouble(2, mod.getPreço()); 
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao inserir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public void Editar(BeansServiço mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("update servico set nome_serv=?, preco_serv=? where cod_serv = ?");
                        pst.setString(1, mod.getNome());
                        pst.setDouble(2, mod.getPreço()); 
                        pst.setInt(4, mod.getCodigo());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados alterados com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao atualizar dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public void Excluir(BeansServiço mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("delete from servico where cod_serv=?");
                        pst.setInt(1, mod.getCodigo());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados excluidos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao excluir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public BeansServiço buscaProdutoNome(BeansServiço mod)
            {
                conex.conexao();
                conex.executaSql("select * from servico where nome_serv like '%"+mod.getPesquisa()+"%'");
                try 
                    {
                        conex.rs.first();
                        mod.setCodigo(conex.rs.getInt("cod_serv"));
                        mod.setNome(conex.rs.getString("nome_serv"));
                        mod.setPreço(conex.rs.getDouble("preco_serv"));
                        
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"servico não cadastrado"+ex);
                    }
                conex.desconecta();
                return mod;
            }
    
}
