package ModeloBeans;

import java.util.Date;

public class BeansFornecedor{
    private String nome;
    private String tipo;
    private String empresa;
    private String pesquisa;
    private Date data;
    private int telefone;
    private int id;

    public int getId(){
        return id;}
    public void setId(int id){
        this.id = id;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public String getTipo(){
        return tipo;}
    public void setTipo(String tipo){
        this.tipo = tipo;}
    public int getTelefone(){
        return telefone;}
    public void setTelefone(int telefone){
        this.telefone = telefone;}
    public String getEmpresa(){
        return empresa;}
    public void setEmpresa(String empresa){
        this.empresa = empresa;}
    public Date getData(){
        return data;}
    public void setData(Date data){
        this.data = data;}
    public String getPesquisa(){
        return pesquisa;}
    public void setPesquisa(String pesquisa){
        this.pesquisa = pesquisa;}}