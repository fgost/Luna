package visao;

import ModeloBeans.BeansInicio;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import ModeloConection.ConexaoBD;
import ModeloDao.DaoInicio;

public class FormInicioia extends javax.swing.JFrame 
    {
        ConexaoBD con = new ConexaoBD();
        DaoInicio control = new DaoInicio();
        BeansInicio mod = new BeansInicio();
        FormCaixa telaini = new FormCaixa();
            
        public FormInicioia() 
            {
                initComponents();
                con.conexao();
            }    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButtonSalvar = new javax.swing.JButton();
        jButtonLimpar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jDateChooserDia = new com.toedter.calendar.JDateChooser();
        jLabel4 = new javax.swing.JLabel();
        jTextFieldSaldo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextFieldUsuario1 = new javax.swing.JTextField();
        jPasswordFieldSenha1 = new javax.swing.JPasswordField();
        jButtonVerificar = new javax.swing.JButton();
        jButtonConfirmar = new javax.swing.JButton();
        jTextFieldNome = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jButtonSalvar.setText("SALVAR");
        jButtonSalvar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalvar);
        jButtonSalvar.setBounds(70, 210, 90, 30);

        jButtonLimpar.setText("LIMPAR");
        jButtonLimpar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLimparActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonLimpar);
        jButtonLimpar.setBounds(170, 210, 90, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("declaro que no dia");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(170, 20, 120, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Eu");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 20, 20, 30);
        jPanel1.add(jDateChooserDia);
        jDateChooserDia.setBounds(290, 20, 140, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("a Mestre Barber Shop iniciou suas atividades com ");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(10, 70, 310, 30);
        jPanel1.add(jTextFieldSaldo);
        jTextFieldSaldo.setBounds(320, 70, 50, 30);

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Reais.");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(380, 70, 35, 30);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Usuário");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(10, 150, 50, 30);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("senha");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(160, 150, 36, 30);

        jTextFieldUsuario1.setEnabled(false);
        jPanel1.add(jTextFieldUsuario1);
        jTextFieldUsuario1.setBounds(60, 150, 90, 30);

        jPasswordFieldSenha1.setEnabled(false);
        jPanel1.add(jPasswordFieldSenha1);
        jPasswordFieldSenha1.setBounds(200, 150, 110, 30);

        jButtonVerificar.setText("VERIFICAR");
        jButtonVerificar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonVerificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonVerificarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonVerificar);
        jButtonVerificar.setBounds(320, 150, 100, 30);

        jButtonConfirmar.setText("CONFIRMAR");
        jButtonConfirmar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonConfirmarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonConfirmar);
        jButtonConfirmar.setBounds(210, 110, 110, 30);
        jPanel1.add(jTextFieldNome);
        jTextFieldNome.setBounds(30, 20, 130, 30);

        jButton2.setText("CANCELAR");
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(270, 210, 110, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(12, 51, 440, 290);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setText("INICIO DO DIA");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(100, 10, 260, 30);

        setSize(new java.awt.Dimension(479, 389));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
    mod.setNome(jTextFieldNome.getText());
    mod.setSenha1(jPasswordFieldSenha1.getText());
    mod.setUsuario1(jTextFieldUsuario1.getText());
    mod.setValor(Double.parseDouble(jTextFieldSaldo.getText()));
    mod.setData( jDateChooserDia.getDate());
    
    control.Salvar(mod);
    jTextFieldNome.setText("");
    jTextFieldSaldo.setText("");
    jTextFieldUsuario1.setText("");
    jPasswordFieldSenha1.setText("");
    
    telaini.setVisible(true);
    telaini.setResizable(false);     
    
    dispose();
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonVerificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonVerificarActionPerformed
    try 
        {
            con.executaSql("select * from usuarios where usu_nome = '"+jTextFieldUsuario1.getText()+"'");
            con.rs.first();
            if(con.rs.getString("usu_senha").equals(jPasswordFieldSenha1.getText()))
                {
                    jButtonSalvar.setEnabled(true);
                }
            else
                {
                    
                } 
            con.desconecta();
        }
    catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(rootPane, "senha ou usuario incorretos");
            jTextFieldNome.setText("");
            jTextFieldSaldo.setText("");
            jTextFieldUsuario1.setText("");
            jPasswordFieldSenha1.setText("");
        } 
    }//GEN-LAST:event_jButtonVerificarActionPerformed

    private void jButtonConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonConfirmarActionPerformed
    jPasswordFieldSenha1.setEnabled(true);
    jTextFieldUsuario1.setText((jTextFieldNome.getText()));
    }//GEN-LAST:event_jButtonConfirmarActionPerformed

    private void jButtonLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLimparActionPerformed
    jTextFieldNome.setText("");
    jTextFieldSaldo.setText("");
    jTextFieldUsuario1.setText("");
    jPasswordFieldSenha1.setText("");
    }//GEN-LAST:event_jButtonLimparActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    int resposta = 0;
    resposta = JOptionPane.showConfirmDialog(rootPane, "DESEJA REALMENTE CANCELAR?");
    if(resposta==JOptionPane.YES_OPTION)
        {
            dispose();
        }            
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormInicioia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormInicioia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormInicioia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormInicioia.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormInicioia().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButtonConfirmar;
    private javax.swing.JButton jButtonLimpar;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JButton jButtonVerificar;
    private com.toedter.calendar.JDateChooser jDateChooserDia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordFieldSenha1;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldSaldo;
    private javax.swing.JTextField jTextFieldUsuario1;
    // End of variables declaration//GEN-END:variables
    }