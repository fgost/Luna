package ModeloBeans;

import java.util.Date;

public class BeansFim{
    private String usuario1;
    private String senha1;
    private String nome;
    private Date data;
    private double valor;

    public String getUsuario1(){
        return usuario1;}
    public void setUsuario1(String usuario1){
        this.usuario1 = usuario1;}
    public String getSenha1(){
        return senha1;}
    public void setSenha1(String senha1){
        this.senha1 = senha1;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public Date getData(){
        return data;}
    public void setData(Date data){
        this.data = data;}
    public double getValor(){
        return valor;}
    public void setValor(double valor){
        this.valor = valor;}}