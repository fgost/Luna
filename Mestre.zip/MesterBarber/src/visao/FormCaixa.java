package visao;

import ModeloBeans.BeansCaixa;
import ModeloBeans.ModeloTabela;
import ModeloConection.ConexaoBD;
import ModeloDao.DaoCaixa;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class FormCaixa extends javax.swing.JFrame {
    BeansCaixa mod = new BeansCaixa();
    DaoCaixa dao = new DaoCaixa();
    ConexaoBD conex = new ConexaoBD();
    String tipo;
    int qtd,cod;
    double pre_uni, tot, totger=0;
    
    public FormCaixa(){
        initComponents();
        this.setLocationRelativeTo(null);
        preencherBarbeiro();}
        
    public void preencherBarbeiro(){
        conex.conexao();
        conex.executaSql("select * from funcionario where cargo_funcionario like'%Barbeiro%' order by nome_Funcionario");
        try{
            conex.rs.first();
            jComboBoxBarbeiro.removeAllItems();
            do{
                jComboBoxBarbeiro.addItem(conex.rs.getString("nome_funcionario"));}
            while(conex.rs.next());}
        catch (SQLException ex){
            JOptionPane.showMessageDialog(rootPane, "Erro ao preencher barbeiro\n"+ex);}
        conex.desconecta();}    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldPreco = new javax.swing.JTextField();
        jbtnadd = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtableVenda = new javax.swing.JTable();
        jTextFieldTotal = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jBLimpar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jTextFieldTotalGeral = new javax.swing.JTextField();
        jB_Remover = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jComboBoxTipo = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jComboBoxBarbeiro = new javax.swing.JComboBox<>();
        jButtonPesquisar = new javax.swing.JButton();
        jTextFieldProduto = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jTextFieldQtd = new javax.swing.JTextField();
        jTextFieldObs = new javax.swing.JTextField();
        jTextFieldTotalPago = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jTextFieldTotalAberto = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jComboBoxFormaPagamento = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jComboBoxAno = new javax.swing.JComboBox<>();
        jComboBoxMes = new javax.swing.JComboBox<>();
        jComboBoxDia = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jTextFieldCod = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Calcular Venda");
        setResizable(false);
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(6, 90, 230));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 101, 82));
        jLabel1.setText("cod");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(140, 90, 20, 30);

        jLabel2.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 101, 82));
        jLabel2.setText("Qtde:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(500, 90, 29, 30);

        jLabel3.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 101, 82));
        jLabel3.setText("Preço Unitário:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(600, 90, 87, 30);

        jTextFieldPreco.setBackground(new java.awt.Color(240, 240, 240));
        jTextFieldPreco.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jTextFieldPreco.setEnabled(false);
        jTextFieldPreco.setSelectionColor(new java.awt.Color(153, 153, 255));
        jPanel1.add(jTextFieldPreco);
        jTextFieldPreco.setBounds(690, 90, 61, 30);

        jbtnadd.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jbtnadd.setForeground(new java.awt.Color(0, 101, 82));
        jbtnadd.setText("Add");
        jbtnadd.setToolTipText("Adicionar os dados na Tabela");
        jbtnadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnaddActionPerformed(evt);
            }
        });
        jPanel1.add(jbtnadd);
        jbtnadd.setBounds(760, 90, 113, 25);

        jtableVenda.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jtableVenda.setForeground(new java.awt.Color(0, 101, 82));
        jtableVenda.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "COD", "Tipo", "Produto", "Quantidade", "Preço Unitário", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jtableVenda.setGridColor(new java.awt.Color(153, 0, 153));
        jScrollPane1.setViewportView(jtableVenda);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(300, 190, 580, 143);

        jTextFieldTotal.setEditable(false);
        jTextFieldTotal.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jTextFieldTotal.setSelectionColor(new java.awt.Color(153, 153, 255));
        jPanel1.add(jTextFieldTotal);
        jTextFieldTotal.setBounds(690, 130, 61, 23);

        jLabel4.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 101, 82));
        jLabel4.setText("Total Pago");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(20, 460, 59, 17);

        jBLimpar.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jBLimpar.setForeground(new java.awt.Color(0, 101, 82));
        jBLimpar.setText("Limpar");
        jBLimpar.setToolTipText("Limpar os dados da tela");
        jBLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBLimparActionPerformed(evt);
            }
        });
        jPanel1.add(jBLimpar);
        jBLimpar.setBounds(760, 130, 113, 25);

        jLabel5.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 101, 82));
        jLabel5.setText("Total:");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(630, 130, 32, 17);

        jTextFieldTotalGeral.setEditable(false);
        jTextFieldTotalGeral.setBackground(new java.awt.Color(255, 204, 255));
        jTextFieldTotalGeral.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jTextFieldTotalGeral.setForeground(new java.awt.Color(204, 255, 51));
        jTextFieldTotalGeral.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldTotalGeral.setEnabled(false);
        jTextFieldTotalGeral.setSelectionColor(new java.awt.Color(153, 153, 255));
        jPanel1.add(jTextFieldTotalGeral);
        jTextFieldTotalGeral.setBounds(120, 410, 94, 34);

        jB_Remover.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jB_Remover.setForeground(new java.awt.Color(0, 101, 82));
        jB_Remover.setText("Remover");
        jB_Remover.setToolTipText("Remover linha da tabela");
        jB_Remover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_RemoverActionPerformed(evt);
            }
        });
        jPanel1.add(jB_Remover);
        jB_Remover.setBounds(760, 160, 83, 25);

        jLabel6.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 101, 82));
        jLabel6.setText("tipo");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(10, 90, 22, 30);

        jComboBoxTipo.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jComboBoxTipo.setForeground(new java.awt.Color(0, 101, 82));
        jComboBoxTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cosméticos", "Alimentos", "Serviço" }));
        jPanel1.add(jComboBoxTipo);
        jComboBoxTipo.setBounds(50, 90, 90, 30);

        jLabel7.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 101, 82));
        jLabel7.setText("Barbeiro");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(20, 360, 51, 17);

        jComboBoxBarbeiro.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jComboBoxBarbeiro.setForeground(new java.awt.Color(0, 101, 82));
        jPanel1.add(jComboBoxBarbeiro);
        jComboBoxBarbeiro.setBounds(110, 350, 210, 40);

        jButtonPesquisar.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jButtonPesquisar.setForeground(new java.awt.Color(0, 101, 82));
        jButtonPesquisar.setText("pesquisar");
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(10, 140, 100, 25);

        jTextFieldProduto.setBackground(new java.awt.Color(240, 240, 240));
        jTextFieldProduto.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jTextFieldProduto.setEnabled(false);
        jTextFieldProduto.setSelectionColor(new java.awt.Color(153, 153, 255));
        jPanel1.add(jTextFieldProduto);
        jTextFieldProduto.setBounds(300, 90, 190, 30);

        jTablePesquisa.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jTablePesquisa.setForeground(new java.awt.Color(0, 101, 82));
        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTablePesquisa);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(10, 190, 280, 140);

        jTextFieldQtd.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jTextFieldQtd.setSelectionColor(new java.awt.Color(153, 153, 255));
        jPanel1.add(jTextFieldQtd);
        jTextFieldQtd.setBounds(540, 90, 50, 30);

        jTextFieldObs.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jTextFieldObs.setForeground(new java.awt.Color(0, 101, 82));
        jPanel1.add(jTextFieldObs);
        jTextFieldObs.setBounds(350, 340, 530, 130);
        jPanel1.add(jTextFieldTotalPago);
        jTextFieldTotalPago.setBounds(120, 450, 90, 30);

        jLabel11.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 101, 82));
        jLabel11.setText("Total Geral");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(20, 420, 64, 17);

        jLabel12.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 101, 82));
        jLabel12.setText("Total Aberto");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(20, 500, 80, 17);
        jPanel1.add(jTextFieldTotalAberto);
        jTextFieldTotalAberto.setBounds(120, 490, 90, 30);

        jLabel13.setText("Forma de Pagamento");
        jPanel1.add(jLabel13);
        jLabel13.setBounds(240, 500, 102, 14);

        jComboBoxFormaPagamento.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dinheiro", "Débito", "Crédito" }));
        jPanel1.add(jComboBoxFormaPagamento);
        jComboBoxFormaPagamento.setBounds(350, 490, 100, 30);

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel3.setLayout(null);

        jComboBoxAno.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxAno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2019", "2020", "2021", "2022" }));
        jPanel3.add(jComboBoxAno);
        jComboBoxAno.setBounds(120, 0, 60, 40);

        jComboBoxMes.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez" }));
        jPanel3.add(jComboBoxMes);
        jComboBoxMes.setBounds(60, 0, 60, 40);

        jComboBoxDia.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxDia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));
        jPanel3.add(jComboBoxDia);
        jComboBoxDia.setBounds(0, 0, 60, 40);

        jPanel1.add(jPanel3);
        jPanel3.setBounds(410, 10, 180, 40);

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("DATA");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(370, 10, 40, 40);
        jPanel1.add(jTextFieldCod);
        jTextFieldCod.setBounds(180, 90, 50, 30);

        jLabel9.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 101, 82));
        jLabel9.setText("Produto:");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(240, 90, 49, 30);

        jLabel10.setText("cliente");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(40, 10, 31, 14);
        jPanel1.add(jTextField1);
        jTextField1.setBounds(90, 10, 140, 20);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(130, 0, 890, 530);

        jPanel2.setBackground(new java.awt.Color(79, 105, 149));
        jPanel2.setLayout(null);

        jButton3.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jButton3.setForeground(new java.awt.Color(0, 101, 82));
        jButton3.setText("Cancelar");
        jPanel2.add(jButton3);
        jButton3.setBounds(190, 450, 90, 25);

        jButton1.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 101, 82));
        jButton1.setText("Salvar");
        jButton1.setBorder(null);
        jButton1.setContentAreaFilled(false);
        jButton1.setFocusPainted(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);
        jButton1.setBounds(0, 0, 130, 30);

        jButton2.setFont(new java.awt.Font("Noto Serif", 0, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(0, 101, 82));
        jButton2.setText("Sair");
        jButton2.setBorder(null);
        jButton2.setContentAreaFilled(false);
        jButton2.setFocusPainted(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2);
        jButton2.setBounds(0, 30, 130, 30);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 0, 130, 530);

        setSize(new java.awt.Dimension(1030, 567));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnaddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnaddActionPerformed
    if(jTextFieldQtd.getText().isEmpty()){
        JOptionPane.showMessageDialog(null, "Preencha a quantidade para continuar");
        jTextFieldQtd.requestFocus();}
    cod  = Integer.parseInt(jTextFieldCod.getText());
    tipo = String.valueOf(jComboBoxTipo.getSelectedItem());
    qtd = Integer.parseInt(jTextFieldQtd.getText());
    pre_uni = Double.parseDouble(jTextFieldPreco.getText());
    tot = (qtd * pre_uni);
    jTextFieldTotal.setText(String.valueOf(tot));
    preenchertabela();        
    }//GEN-LAST:event_jbtnaddActionPerformed
    public void preenchertabela(){
        String cod1,tipo1,prod, qtd1, pre_uni1, tot1;
        cod1 = jTextFieldCod.getText();
        tipo1 = String.valueOf(jComboBoxTipo.getSelectedItem());
        prod = jTextFieldProduto.getText();
        qtd1 = String.valueOf(jTextFieldQtd.getText());
        pre_uni1 = jTextFieldPreco.getText();
        tot1 = jTextFieldTotal.getText();

        jtableVenda.getColumnModel().getColumn(0).setPreferredWidth(15);
        jtableVenda.getColumnModel().getColumn(1).setPreferredWidth(30);
        jtableVenda.getColumnModel().getColumn(0).setPreferredWidth(50);
        jtableVenda.getTableHeader().setReorderingAllowed(false);
        jtableVenda.setAutoResizeMode(jtableVenda.AUTO_RESIZE_OFF);
        jtableVenda.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        DefaultTableModel modelo = (DefaultTableModel)jtableVenda.getModel();
        modelo.addRow(new Object[]{cod1,tipo1,prod, qtd1, pre_uni1, tot1});   
        CalcularTotal();}

    private void CalcularTotal(){
        double totalger=0;
        for (int linha=0; linha<jtableVenda.getRowCount();linha++){
            String valor = ""+jtableVenda.getValueAt(linha,5);
            totalger += Double.parseDouble(valor);}
        //DecimalFormat df = new DecimalFormat("#,###.00");
        jTextFieldTotalGeral.setText((String.valueOf(totalger)));}
    
    private void jBLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBLimparActionPerformed
    jTextFieldPreco.setText(null);
    jTextFieldTotal.setText(null);
    }//GEN-LAST:event_jBLimparActionPerformed

    private void jB_RemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_RemoverActionPerformed
    //vetor para selecionar as linhas
    int[] linhas = jtableVenda.getSelectedRows();
        
    DefaultTableModel modelo = (DefaultTableModel)
    jtableVenda.getModel();        
    //Remove a linha da tabela que foi selecionada
    for (int i = linhas.length - 1; i >= 0; --i){
        modelo.removeRow(linhas[i]);}
    CalcularTotal();
    
    }//GEN-LAST:event_jB_RemoverActionPerformed

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
    if(jComboBoxTipo.getSelectedItem().equals("Serviço")){
        preencheTabela("select * from servico order by nome_serv");}
    else{
    preencheTabela("select * from produto where tipo_pro like '%"+jComboBoxTipo.getSelectedItem()+"%'");}
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jTablePesquisaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaMouseClicked
    String nome_pro = ""+jTablePesquisa.getValueAt(jTablePesquisa.getSelectedRow(), 1);
    String nome_serv = ""+jTablePesquisa.getValueAt(jTablePesquisa.getSelectedRow(), 1);
    conex.conexao();
    if((jComboBoxTipo.getSelectedItem().equals("Cosméticos"))||(jComboBoxTipo.getSelectedItem().equals("Alimentos"))){
        conex.executaSql("select * from produto where nome_pro ='"+nome_pro+"'");
        try{
            conex.rs.first();
            jTextFieldProduto.setText(String.valueOf(conex.rs.getString("nome_pro")));
            jTextFieldPreco.setText(String.valueOf(conex.rs.getDouble("preco_pro")));
            jTextFieldCod.setText(String.valueOf(conex.rs.getInt("cod_pro")));}
        catch (SQLException ex){
            JOptionPane.showMessageDialog(rootPane, "Erro ao selecionar dados"+ex);}}
    else{
        conex.executaSql("select * from servico where nome_serv ='"+nome_serv+"'");
        try{
            conex.rs.first();
            jTextFieldProduto.setText(String.valueOf(conex.rs.getString("nome_serv")));
            jTextFieldPreco.setText(String.valueOf(conex.rs.getDouble("preco_serv")));
            jTextFieldCod.setText(String.valueOf(conex.rs.getInt("cod_serv")));}
        catch (SQLException ex){
            JOptionPane.showMessageDialog(rootPane, "Erro ao selecionar dados"+ex);}}
    conex.desconecta();
    }//GEN-LAST:event_jTablePesquisaMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    if(jTextFieldTotalGeral.getText().isEmpty()){
        JOptionPane.showMessageDialog(null, "Preencha o Total para continuar");
        jTextFieldQtd.requestFocus();}
    String a = (String)jComboBoxDia.getSelectedItem(),
           b = (String)jComboBoxMes.getSelectedItem(),
           c = (String)jComboBoxAno.getSelectedItem(),
           d=(String)jComboBoxBarbeiro.getSelectedItem(),
           e=(String)jComboBoxFormaPagamento.getSelectedItem(),
           f=jTextFieldObs.getText(),
           nome=jTextField1.getText(),
           tipo ="",
           produto ="",
           qtd="",
           valor ="",
           cod="";
    double g = Double.parseDouble(jTextFieldTotalGeral.getText()),
           h = Double.parseDouble(jTextFieldTotalAberto.getText()),
           i = Double.parseDouble(jTextFieldTotalPago.getText());
    for (int linha=0; linha<jtableVenda.getRowCount();linha++){
        cod = ""+jtableVenda.getValueAt(linha,0);
        tipo = ""+jtableVenda.getValueAt(linha,1);
        produto = ""+jtableVenda.getValueAt(linha,2);
        qtd = (""+jtableVenda.getValueAt(linha,3));
        valor = (""+jtableVenda.getValueAt(linha,4));
    
        mod.setCodigo(Integer.parseInt(cod));
        mod.setTipo(tipo);
        mod.setProduto(produto);
        mod.setQtd(Integer.parseInt(qtd));
        mod.setPreco(Double.parseDouble(valor));
        
        dao.salvarTabela(mod);}
    mod.setNome(nome);
    mod.setData(a+b+c);
    mod.setBarbeiro(d);
    mod.setPagamento(e);
    mod.setObs(f);
    mod.setTotal((g));
    mod.setTotalaberto((h));
    mod.setTotalpago((i));
    dao.salvar(mod);
    
    }//GEN-LAST:event_jButton1ActionPerformed
    public void preencheTabela (String Sql){
        ArrayList dados = new ArrayList();
        String [] colunas = new String []{"cod"
                                         ,"nome"
                                         ,"valor Unitario"};
        conex.conexao();
        conex.executaSql(Sql);
        try{
            conex.rs.first();
            do{
                if((jComboBoxTipo.getSelectedItem().equals("Cosméticos"))||(jComboBoxTipo.getSelectedItem().equals("Alimentos"))){
                dados.add(new Object[]{
                    conex.rs.getInt("cod_pro")
                    ,conex.rs.getString("nome_pro")
                    ,conex.rs.getDouble("preco_pro")}
                );}
                else{
                    dados.add(new Object[]{
                    conex.rs.getInt("cod_serv")
                    ,conex.rs.getString("nome_serv")
                    ,conex.rs.getDouble("preco_serv")});}}
            while(conex.rs.next());}
        catch(SQLException ex){
            JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);}
        ModeloTabela modelo = new ModeloTabela(dados, colunas);
        jTablePesquisa.setModel(modelo);
        jTablePesquisa.getColumnModel().getColumn(0).setPreferredWidth(30);
        jTablePesquisa.getColumnModel().getColumn(0).setResizable(false);
            
        jTablePesquisa.getColumnModel().getColumn(1).setPreferredWidth(157);
        jTablePesquisa.getColumnModel().getColumn(1).setResizable(false);
            
        jTablePesquisa.getColumnModel().getColumn(2).setPreferredWidth(100);
        jTablePesquisa.getColumnModel().getColumn(2).setResizable(false);
        
        jTablePesquisa.getTableHeader().setReorderingAllowed(false);
        jTablePesquisa.setAutoResizeMode(jTablePesquisa.AUTO_RESIZE_OFF);
        jTablePesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        conex.desconecta();}
    
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormCaixa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBLimpar;
    private javax.swing.JButton jB_Remover;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JComboBox<String> jComboBoxAno;
    private javax.swing.JComboBox<String> jComboBoxBarbeiro;
    private javax.swing.JComboBox<String> jComboBoxDia;
    private javax.swing.JComboBox<String> jComboBoxFormaPagamento;
    private javax.swing.JComboBox<String> jComboBoxMes;
    private javax.swing.JComboBox<String> jComboBoxTipo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextFieldCod;
    private javax.swing.JTextField jTextFieldObs;
    private javax.swing.JTextField jTextFieldPreco;
    private javax.swing.JTextField jTextFieldProduto;
    private javax.swing.JTextField jTextFieldQtd;
    private javax.swing.JTextField jTextFieldTotal;
    private javax.swing.JTextField jTextFieldTotalAberto;
    private javax.swing.JTextField jTextFieldTotalGeral;
    private javax.swing.JTextField jTextFieldTotalPago;
    private javax.swing.JButton jbtnadd;
    private javax.swing.JTable jtableVenda;
    // End of variables declaration//GEN-END:variables
}
