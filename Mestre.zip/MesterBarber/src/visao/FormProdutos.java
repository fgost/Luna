package visao;

import ModeloConection.ConexaoBD;
import ModeloBeans.BeansProduto;
import ModeloBeans.ModeloTabela;
import ModeloDao.DaoProduto;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormProdutos extends javax.swing.JFrame 
    {
        BeansProduto mod = new BeansProduto();
        DaoProduto control = new DaoProduto();
        ConexaoBD conex = new ConexaoBD();
        int flag = 0;
    
        public FormProdutos() 
            {
                initComponents();
                preencherTabela("select * from produto order by nome_pro");
            }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelNomeProduto = new javax.swing.JLabel();
        jLabelPreçoProduto = new javax.swing.JLabel();
        jTextFieldNomeProduto = new javax.swing.JTextField();
        jButtonNovo = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jTextFieldPesquisa = new javax.swing.JTextField();
        jButtonPesquisarNome = new javax.swing.JButton();
        jTextFieldPreçoProduto = new javax.swing.JTextField();
        jLabelTipoProduto = new javax.swing.JLabel();
        jComboBoxTipoProduto = new javax.swing.JComboBox<>();
        jLabelIDProduto = new javax.swing.JLabel();
        jTextFieldCodProduto = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldQtd = new javax.swing.JTextField();
        jLabelCad = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabelNomeProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelNomeProduto.setText("NOME");
        jPanel1.add(jLabelNomeProduto);
        jLabelNomeProduto.setBounds(200, 20, 50, 30);

        jLabelPreçoProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelPreçoProduto.setText("PREÇO");
        jPanel1.add(jLabelPreçoProduto);
        jLabelPreçoProduto.setBounds(120, 70, 60, 30);

        jTextFieldNomeProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldNomeProduto.setEnabled(false);
        jPanel1.add(jTextFieldNomeProduto);
        jTextFieldNomeProduto.setBounds(250, 20, 260, 30);

        jButtonNovo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonNovo.setText("NOVO");
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonNovo);
        jButtonNovo.setBounds(10, 20, 100, 30);

        jButtonSalvar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonSalvar.setText("SALVAR");
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalvar);
        jButtonSalvar.setBounds(10, 70, 100, 30);

        jButtonCancelar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonCancelar.setText("CANCELAR");
        jButtonCancelar.setEnabled(false);
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCancelar);
        jButtonCancelar.setBounds(10, 120, 100, 30);

        jButtonEditar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonEditar.setText("EDITAR");
        jButtonEditar.setEnabled(false);
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEditar);
        jButtonEditar.setBounds(10, 170, 100, 30);

        jButtonExcluir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonExcluir.setText("EXCLUIR");
        jButtonExcluir.setEnabled(false);
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonExcluir);
        jButtonExcluir.setBounds(10, 220, 100, 30);

        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisa);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(120, 160, 480, 140);

        jTextFieldPesquisa.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldPesquisa);
        jTextFieldPesquisa.setBounds(120, 120, 300, 30);

        jButtonPesquisarNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonPesquisarNome.setText("Pesquisar");
        jButtonPesquisarNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarNomeActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonPesquisarNome);
        jButtonPesquisarNome.setBounds(430, 120, 120, 30);

        jTextFieldPreçoProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldPreçoProduto.setEnabled(false);
        jPanel1.add(jTextFieldPreçoProduto);
        jTextFieldPreçoProduto.setBounds(180, 70, 60, 30);

        jLabelTipoProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelTipoProduto.setText("TIPO DO PRODUTO");
        jPanel1.add(jLabelTipoProduto);
        jLabelTipoProduto.setBounds(250, 70, 140, 30);

        jComboBoxTipoProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxTipoProduto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Alimentos", "serviços", "Cosméticos" }));
        jComboBoxTipoProduto.setEnabled(false);
        jPanel1.add(jComboBoxTipoProduto);
        jComboBoxTipoProduto.setBounds(390, 70, 160, 30);

        jLabelIDProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelIDProduto.setText("ID");
        jPanel1.add(jLabelIDProduto);
        jLabelIDProduto.setBounds(120, 20, 20, 30);

        jTextFieldCodProduto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldCodProduto.setEnabled(false);
        jPanel1.add(jTextFieldCodProduto);
        jTextFieldCodProduto.setBounds(140, 20, 50, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("QTD");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(520, 20, 40, 30);

        jTextFieldQtd.setEnabled(false);
        jPanel1.add(jTextFieldQtd);
        jTextFieldQtd.setBounds(560, 20, 40, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 40, 610, 310);

        jLabelCad.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabelCad.setText("CADASTRO DE PRODUTOS");
        getContentPane().add(jLabelCad);
        jLabelCad.setBounds(190, 10, 230, 30);

        setSize(new java.awt.Dimension(645, 399));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
   if(jTextFieldNomeProduto.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o nome para continuar");
            jTextFieldNomeProduto.requestFocus();
        }
    else if(jTextFieldPreçoProduto.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o Telefone para continuar");
            jTextFieldPreçoProduto.requestFocus();
        }
    if(flag==1)
        {
            mod.setNome(jTextFieldNomeProduto.getText());
            mod.setTipo((String)jComboBoxTipoProduto.getSelectedItem());
            mod.setPreco(Double.parseDouble(jTextFieldPreçoProduto.getText()));
            mod.setQtd(Integer.parseInt(jTextFieldQtd.getText()));
            
            control.Salvar(mod);
            jTextFieldNomeProduto.setText("");
            jTextFieldPreçoProduto.setText("");
            jTextFieldNomeProduto.setEnabled(false);
            jTextFieldPreçoProduto.setEnabled(false);
            jComboBoxTipoProduto.setEnabled(false);
            jButtonSalvar.setEnabled(false);
            jButtonCancelar.setEnabled(false);
            preencherTabela("select * from produto order by nome_pro");
        }
    else
        {
            mod.setCod((Integer.parseInt(jTextFieldCodProduto.getText())));
            mod.setNome(jTextFieldNomeProduto.getText());
            mod.setTipo((String)jComboBoxTipoProduto.getSelectedItem());
            mod.setPreco(Double.parseDouble(jTextFieldPreçoProduto.getText()));
            control.Editar(mod);
            jTextFieldNomeProduto.setEnabled(false);
            jTextFieldPreçoProduto.setEnabled(false);
            jComboBoxTipoProduto.setEnabled(false);
            jButtonSalvar.setEnabled(false);
            jButtonCancelar.setEnabled(false);  
            jTextFieldNomeProduto.setText("");
            jTextFieldPreçoProduto.setText("");
            jTextFieldCodProduto.setText("");
            jTextFieldPesquisa.setText("");
            preencherTabela("select * from produto order by nome_pro");
        }
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonPesquisarNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarNomeActionPerformed
    BeansProduto model = control.buscaProdutoNome(mod);
    mod.setPesquisa(jTextFieldPesquisa.getText());
    jTextFieldNomeProduto.setText(model.getNome());
    jTextFieldPreçoProduto.setText(String.valueOf(model.getPreco()));
    jComboBoxTipoProduto.setSelectedItem(model.getTipo());
    jTextFieldCodProduto.setText(String.valueOf(model.getCod()));
    jButtonEditar.setEnabled(true);
    jButtonExcluir.setEnabled(true);
    jButtonNovo.setEnabled(false);
    jButtonSalvar.setEnabled(false);
    jTextFieldNomeProduto.setEnabled(false);
    jComboBoxTipoProduto.setEnabled(false);
    }//GEN-LAST:event_jButtonPesquisarNomeActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
    flag = 1;
    jTextFieldNomeProduto.setEnabled(true);
    jTextFieldPreçoProduto.setEnabled(true);
    jComboBoxTipoProduto.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    jTextFieldQtd.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    jTextFieldNomeProduto.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldCodProduto.setText("");
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
    jTextFieldNomeProduto.setEnabled(!true);
    jTextFieldPreçoProduto.setEnabled(!true);
    jComboBoxTipoProduto.setEnabled(!true);
    jComboBoxTipoProduto.setEnabled(!true);
    jButtonSalvar.setEnabled(!true);
    jButtonCancelar.setEnabled(!true);
    jButtonNovo.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    jTextFieldNomeProduto.setText("");
    jTextFieldPreçoProduto.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldPesquisa.setEnabled(true);
    jButtonPesquisarNome.setEnabled(true);
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jTablePesquisaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaMouseClicked
    String nome_pro = ""+jTablePesquisa.getValueAt(jTablePesquisa.getSelectedRow(), 1);
    conex.conexao();
    conex.executaSql("select * from produto where nome_pro ='"+nome_pro+"'");
    try 
        {      
            conex.rs.first();
            jTextFieldCodProduto.setText(String.valueOf(conex.rs.getInt("cod_pro")));
            jTextFieldNomeProduto.setText(conex.rs.getString("nome_pro"));
            jComboBoxTipoProduto.setSelectedItem(conex.rs.getString("tipo_pro"));
            jTextFieldPreçoProduto.setText(conex.rs.getString("preco_pro"));
            jTextFieldQtd.setText(String.valueOf(conex.rs.getInt("qtd")));
        } 
    catch (SQLException ex) 
        {
                JOptionPane.showMessageDialog(rootPane, "Erro ao selecionar dados"+ex);
        }
    conex.desconecta();
    jButtonEditar.setEnabled(true);
    jButtonExcluir.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jButtonNovo.setEnabled(false);
    }//GEN-LAST:event_jTablePesquisaMouseClicked

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
    flag = 2;
    jTextFieldNomeProduto.setEnabled(true);
    jTextFieldPreçoProduto.setEnabled(true);
    jComboBoxTipoProduto.setEnabled(true);
    jTextFieldQtd.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonNovo.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
    int resposta = 0;
    resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente excluir?");
    if(resposta==JOptionPane.YES_OPTION)
        {
            mod.setCod((Integer.parseInt(jTextFieldCodProduto.getText())));
            control.Excluir(mod);
            jButtonEditar.setEnabled(false);
            jButtonExcluir.setEnabled(false);
            jButtonCancelar.setEnabled(false);
            jButtonNovo.setEnabled(true);
            jTextFieldNomeProduto.setText("");
            jTextFieldPreçoProduto.setText("");
            jTextFieldCodProduto.setText("");
            jTextFieldPesquisa.setText("");
            preencherTabela("select * from produto order by nome_pro");
        }
    }//GEN-LAST:event_jButtonExcluirActionPerformed
    public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"COD"
                                             ,"NOME"
                                             ,"TIPO DO PRODUTO"
                                             ,"PREÇO"
                                             ,"QTD"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{conex.rs.getInt("cod_pro")
                                                  ,conex.rs.getString("nome_pro")
                                                  ,conex.rs.getString("tipo_pro")
                                                  ,conex.rs.getDouble("preco_pro")
                                                  ,conex.rs.getInt("qtd")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTablePesquisa.setModel(modelo);
            jTablePesquisa.getColumnModel().getColumn(0).setPreferredWidth(30);
            jTablePesquisa.getColumnModel().getColumn(0).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(1).setPreferredWidth(170);
            jTablePesquisa.getColumnModel().getColumn(1).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(2).setPreferredWidth(170);
            jTablePesquisa.getColumnModel().getColumn(2).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(3).setPreferredWidth(57);
            jTablePesquisa.getColumnModel().getColumn(3).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(4).setPreferredWidth(50);
            jTablePesquisa.getColumnModel().getColumn(4).setResizable(false);
            
            jTablePesquisa.getTableHeader().setReorderingAllowed(false);
            jTablePesquisa.setAutoResizeMode(jTablePesquisa.AUTO_RESIZE_OFF);
            jTablePesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    public static void main(String args[]) 
        {
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                    {
                        new FormProdutos().setVisible(true);
                    }
                });
        }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonPesquisarNome;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox<String> jComboBoxTipoProduto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelCad;
    private javax.swing.JLabel jLabelIDProduto;
    private javax.swing.JLabel jLabelNomeProduto;
    private javax.swing.JLabel jLabelPreçoProduto;
    private javax.swing.JLabel jLabelTipoProduto;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextFieldCodProduto;
    private javax.swing.JTextField jTextFieldNomeProduto;
    private javax.swing.JTextField jTextFieldPesquisa;
    private javax.swing.JTextField jTextFieldPreçoProduto;
    private javax.swing.JTextField jTextFieldQtd;
    // End of variables declaration//GEN-END:variables
}