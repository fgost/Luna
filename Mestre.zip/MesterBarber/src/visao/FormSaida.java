package visao;

import ModeloBeans.BeansSaida;
import ModeloBeans.ModeloTabela;
import ModeloConection.ConexaoBD;
import ModeloDao.DaoSaida;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormSaida extends javax.swing.JFrame 
    {
        BeansSaida mod = new BeansSaida();
        DaoSaida control = new DaoSaida();
        ConexaoBD conex = new ConexaoBD();
        public FormSaida() 
            {
                initComponents();
                preencherTabela("select * from conta order by nome");
            }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jButtonNome = new javax.swing.JButton();
        jButtonTipo = new javax.swing.JButton();
        jButtonPreço = new javax.swing.JButton();
        jLabelPreco = new javax.swing.JLabel();
        jLabelTipo = new javax.swing.JLabel();
        jLabelNome = new javax.swing.JLabel();
        jTextFieldTipo = new javax.swing.JTextField();
        jTextFieldPreco = new javax.swing.JTextField();
        jTextFieldNome = new javax.swing.JTextField();
        jLabelTitulo = new javax.swing.JLabel();
        jTextFieldSaida = new javax.swing.JTextField();
        jLabelSaida = new javax.swing.JLabel();
        jButtonAbrir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTablePesquisa);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(10, 142, 510, 260);

        jButtonNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonNome.setText("BUSCAR");
        jButtonNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNomeActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonNome);
        jButtonNome.setBounds(420, 20, 100, 30);

        jButtonTipo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonTipo.setText("BUSCAR");
        jButtonTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTipoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonTipo);
        jButtonTipo.setBounds(420, 60, 100, 30);

        jButtonPreço.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonPreço.setText("BUSCAR");
        jButtonPreço.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPreçoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonPreço);
        jButtonPreço.setBounds(420, 100, 100, 30);

        jLabelPreco.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelPreco.setText("BUSCAR POR PREÇO");
        jPanel1.add(jLabelPreco);
        jLabelPreco.setBounds(10, 100, 140, 30);

        jLabelTipo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelTipo.setText("BUSCAR POR TIPO");
        jPanel1.add(jLabelTipo);
        jLabelTipo.setBounds(10, 60, 140, 30);

        jLabelNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelNome.setText("BUSCAR POR NOME");
        jPanel1.add(jLabelNome);
        jLabelNome.setBounds(10, 20, 140, 30);

        jTextFieldTipo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldTipo);
        jTextFieldTipo.setBounds(160, 60, 250, 30);

        jTextFieldPreco.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldPreco);
        jTextFieldPreco.setBounds(160, 100, 250, 30);

        jTextFieldNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldNome);
        jTextFieldNome.setBounds(160, 20, 250, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 97, 530, 410);

        jLabelTitulo.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabelTitulo.setText("SAIDA DO CAIXA");
        getContentPane().add(jLabelTitulo);
        jLabelTitulo.setBounds(160, 20, 220, 60);

        jTextFieldSaida.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldSaida.setEnabled(false);
        getContentPane().add(jTextFieldSaida);
        jTextFieldSaida.setBounds(310, 510, 120, 30);

        jLabelSaida.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelSaida.setText("GASTOS TOTAIS");
        getContentPane().add(jLabelSaida);
        jLabelSaida.setBounds(180, 510, 120, 30);

        jButtonAbrir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonAbrir.setText("ABRIR");
        jButtonAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbrir);
        jButtonAbrir.setBounds(440, 510, 90, 30);

        setSize(new java.awt.Dimension(563, 597));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNomeActionPerformed
    BeansSaida model = control.buscaPorNome(mod);
    mod.setPesquisa(jTextFieldNome.getText());
    jTextFieldNome.setText(model.getNome());
    
    preencherTabela("select * from conta where nome like '%"+mod.getPesquisa()+"%'");
    }//GEN-LAST:event_jButtonNomeActionPerformed

    private void jButtonTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTipoActionPerformed
    BeansSaida model = control.buscaPorTipo(mod);
    mod.setPesquisa1(jTextFieldTipo.getText());
    jTextFieldTipo.setText(model.getTipo());
    preencherTabela("select * from conta where tipo like '%"+mod.getPesquisa1()+"%'");
    }//GEN-LAST:event_jButtonTipoActionPerformed

    private void jButtonPreçoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPreçoActionPerformed
    BeansSaida model = control.buscaPreco(mod);
    mod.setPesquisa2(Double.parseDouble(jTextFieldPreco.getText()));
    jTextFieldPreco.setText(String.valueOf(model.getPreco()));
    
    preencherTabela("select * from conta where total = '"+mod.getPesquisa2()+"'");
    }//GEN-LAST:event_jButtonPreçoActionPerformed

    private void jButtonAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirActionPerformed
    conex.conexao();
    conex.executaSql("SELECT sum(total)FROM conta");
    try
        {   
            conex.rs.first();// pega o primeiro registro
            jTextFieldSaida.setText(String.valueOf(conex.rs.getDouble(1)));// converte ele no primeiro registro para o textField
        }      
    catch (SQLException erro)   
        {   
            JOptionPane.showMessageDialog(null,"Erro ao somar os campos..."+erro);   
        }        
    }//GEN-LAST:event_jButtonAbrirActionPerformed
    public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []
                                            {
                                                "COD"
                                               ,"DATA"
                                               ,"NOME"
                                               ,"TIPO"
                                               ,"PREÇO"
                                               ,"FORNECEDOR"
                                               ,"QTD"
                                               ,"TOTAL"
                                            };
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{  conex.rs.getInt("cod")
                                                    ,conex.rs.getString("datas")
                                                    ,conex.rs.getString("nome")
                                                    ,conex.rs.getString("tipo")
                                                    ,conex.rs.getDouble("preco")
                                                    ,conex.rs.getString("fornecedor")
                                                    ,conex.rs.getInt("qtd")
                                                    ,conex.rs.getDouble("total")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTablePesquisa.setModel(modelo);
            jTablePesquisa.getColumnModel().getColumn(0).setPreferredWidth(40);
            jTablePesquisa.getColumnModel().getColumn(0).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(1).setPreferredWidth(80);
            jTablePesquisa.getColumnModel().getColumn(1).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(2).setPreferredWidth(150);
            jTablePesquisa.getColumnModel().getColumn(2).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(3).setPreferredWidth(85);
            jTablePesquisa.getColumnModel().getColumn(3).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(4).setPreferredWidth(85);
            jTablePesquisa.getColumnModel().getColumn(4).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(5).setPreferredWidth(100);
            jTablePesquisa.getColumnModel().getColumn(5).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(6).setPreferredWidth(60);
            jTablePesquisa.getColumnModel().getColumn(6).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(7).setPreferredWidth(80);
            jTablePesquisa.getColumnModel().getColumn(7).setResizable(false);
            
            jTablePesquisa.getTableHeader().setReorderingAllowed(false);
            jTablePesquisa.setAutoResizeMode(jTablePesquisa.AUTO_RESIZE_OFF);
            jTablePesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }    
    public static void main(String args[]) 
        {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormSaida.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                        {
                            new FormSaida().setVisible(true);
                        }
                });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbrir;
    private javax.swing.JButton jButtonNome;
    private javax.swing.JButton jButtonPreço;
    private javax.swing.JButton jButtonTipo;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JLabel jLabelPreco;
    private javax.swing.JLabel jLabelSaida;
    private javax.swing.JLabel jLabelTipo;
    private javax.swing.JLabel jLabelTitulo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldPreco;
    private javax.swing.JTextField jTextFieldSaida;
    private javax.swing.JTextField jTextFieldTipo;
    // End of variables declaration//GEN-END:variables
}
