package ModeloDao;

import ModeloBeans.BeansSaida;
import ModeloConection.ConexaoBD;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoSaida 
    {
    ConexaoBD conex = new ConexaoBD();

        public BeansSaida buscaPorNome(BeansSaida mod)
            {
                conex.conexao();
                conex.executaSql("select * from conta where nome like '%"+mod.getPesquisa()+"%'");
                try 
                    {
                        conex.rs.first();
                        mod.setNome(conex.rs.getString("nome"));
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"não cadastrado!\n"+ex );
                    }
                conex.desconecta();
                return mod;
            }
        
        public BeansSaida buscaPorTipo(BeansSaida mod)
            {
                conex.conexao();
                conex.executaSql("select * from conta where nome like '%"+mod.getPesquisa1()+"%'");
                try 
                    {
                        conex.rs.first();
                        mod.setTipo(conex.rs.getString("tipo"));
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"não cadastrado!\n"+ex );
                    }
                conex.desconecta();
                return mod;
            }
        
        public BeansSaida buscaPreco(BeansSaida mod)
            {
                conex.conexao();
                conex.executaSql("select * from conta where total ='"+mod.getPesquisa2()+"'");
                try  
                    {
                        conex.rs.first();
                        mod.setPreco(conex.rs.getDouble("total"));
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"não cadastrado!\n"+ex );
                    }
                conex.desconecta();
                return mod;
            }
    }
