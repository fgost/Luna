package ModeloDao;

import ModeloBeans.BeansFornecedor;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoFornecedor 
    {
        ConexaoBD conex = new ConexaoBD();
        BeansFornecedor mod = new BeansFornecedor();
    
        public void Salvar(BeansFornecedor mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("insert into fornecedor (nome,tipo,tel,empresa,datas) values(?,?,?,?,?)");
                        pst.setString(1, mod.getNome());
                        pst.setString(2, mod.getTipo()); 
                        pst.setInt(3, mod.getTelefone());
                        pst.setString(4, mod.getEmpresa());
                        pst.setDate(5,new java.sql.Date(mod.getData().getTime()));
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao inserir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public void Editar(BeansFornecedor mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("update fornecedor set nome=?, tipo=?,tel=?,empresa=?,datas=? where cod = ?");
                        pst.setString(1, mod.getNome());
                        pst.setString(2, mod.getTipo());
                        pst.setInt(3, mod.getTelefone());
                        pst.setString(4, mod.getEmpresa());
                        pst.setDate(5,new java.sql.Date(mod.getData().getTime()));
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados alterados com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao atualizar dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public void Excluir(BeansFornecedor mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("delete from fornecedor where cod=?");
                        pst.setInt(1, mod.getId());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados excluidos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao excluir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public BeansFornecedor buscaFuncionario(BeansFornecedor mod)
            {
                conex.conexao();
                conex.executaSql("select * from fornecedor where nome like '%"+mod.getPesquisa()+"%'");
                try 
                    {
                        conex.rs.first();
                        mod.setId(conex.rs.getInt("cod"));
                        mod.setNome(conex.rs.getString("nome"));
                        mod.setTelefone(conex.rs.getInt("tel"));
                        mod.setTipo(conex.rs.getString("tipo"));
                        mod.setData(conex.rs.getDate("datas"));
                        mod.setEmpresa(conex.rs.getString("empresa"));
                    } 
                catch (SQLException ex)
                    {
                        JOptionPane.showMessageDialog(null,"Funcionario não cadastrado");
                    }
                conex.desconecta();
                return mod;
            }
    }
