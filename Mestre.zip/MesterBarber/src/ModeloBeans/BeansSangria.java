package ModeloBeans;

import java.util.Date;

public class BeansSangria{
    private String nome;
    private String usuario;
    private String senha;
    private Date data;
    private double sangria;
    private String motivo;

    public String getMotivo(){
        return motivo;}
    public void setMotivo(String motivo){
        this.motivo = motivo;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public String getUsuario(){
        return usuario;}
    public void setUsuario(String usuario){
        this.usuario = usuario;}
    public String getSenha(){
        return senha;}
    public void setSenha(String senha){
        this.senha = senha;}
    public Date getData(){
        return data;}
    public void setData(Date data){
        this.data = data;}
    public double getSangria(){
        return sangria;}
    public void setSangria(double sangria){
        this.sangria = sangria;}}