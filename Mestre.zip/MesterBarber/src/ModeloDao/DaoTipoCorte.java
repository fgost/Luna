package ModeloDao;

import ModeloBeans.BeansTipoCorte;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoTipoCorte 
    {
        ConexaoBD conex = new ConexaoBD();
        BeansTipoCorte mod = new BeansTipoCorte();
    
        public void Salvar(BeansTipoCorte mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("insert into tipocorte (nome_corte) values(?)");
                        pst.setString(1, mod.getNome());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao inserir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public void Editar(BeansTipoCorte mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("update tipocorte set nome_corte=? where cod_corte = ?");
                        pst.setString(1, mod.getNome());
                        pst.setInt(2, mod.getCod());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados alterados com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao atualizar dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public void Excluir(BeansTipoCorte mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("delete from tipocorte where cod_corte=?");
                        pst.setInt(1, mod.getCod());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados excluidos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao excluir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public BeansTipoCorte buscaProdutoNome(BeansTipoCorte mod)
            {
                conex.conexao();
                conex.executaSql("select * from tipocorte where nome_corte like '%"+mod.getPesquisa()+"%'");
                try 
                    {
                        conex.rs.first();
                        
                        mod.setNome(conex.rs.getString("nome_corte"));
                        mod.setCod(conex.rs.getInt("cod_corte"));
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"servico não cadastrado"+ex);
                    }
                conex.desconecta();
                return mod;
            }
}