package ModeloDao;

import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import ModeloBeans.BeansFuncionario;

public class DaoFuncionario 
    {
        ConexaoBD conex = new ConexaoBD();
        BeansFuncionario mod = new BeansFuncionario();
    
        public void Salvar(BeansFuncionario mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("insert into funcionario (nome_funcionario,cargo_funcionario,login_funcionario) values(?,?,?)");
                        pst.setString(1, mod.getNome());
                        pst.setString(2, mod.getCargo()); 
                        pst.setInt(3, mod.getLogin());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao inserir dados!\n"+ex );
                    }
                conex.desconecta();
            }
        public void Editar(BeansFuncionario mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("update funcionario set nome_funcionario=?, cargo_funcionario=?,login_funcionario=? where cod_funcionario = ?");
                        pst.setString(1, mod.getNome());
                        pst.setString(2, mod.getCargo());
                        pst.setInt(3, mod.getLogin());
                        pst.setInt(4, mod.getCodigo());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados alterados com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao atualizar dados!\n"+ex );
                    }
                conex.desconecta();
            }
        public void Excluir(BeansFuncionario mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("delete from funcionario where cod_funcionario=?");
                        pst.setInt(1, mod.getCodigo());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados excluidos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao excluir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public BeansFuncionario buscaFuncionario(BeansFuncionario mod)
            {
                conex.conexao();
                conex.executaSql("select * from funcionario where nome_funcionario like '%"+mod.getPesquisa()+"%'");
                try 
                    {
                        conex.rs.first();
                        mod.setCodigo(conex.rs.getInt("cod_funcionario"));
                        mod.setNome(conex.rs.getString("nome_funcionario"));
                        mod.setLogin(conex.rs.getInt("login_funcionario"));
                        mod.setCargo(conex.rs.getString("cargo_funcionario"));
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Funcionario não cadastrado");
                    }
                conex.desconecta();
                return mod;
            }
    }
