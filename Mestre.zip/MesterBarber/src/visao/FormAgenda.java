package visao;

import ModeloBeans.ModeloTabela;
import ModeloConection.ConexaoBD;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormAgenda extends javax.swing.JFrame 
    {
        ConexaoBD conex = new ConexaoBD();
        public FormAgenda()
            {
                initComponents();
                preencherTabela("select * from cliente a join agenda b on a.cli_cod=b.codcli_agenda order by hora_agenda desc");
            }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableAgenda = new javax.swing.JTable();
        jLabelDescrição = new javax.swing.JLabel();
        jTextFieldData = new javax.swing.JTextField();
        jButtonAbrir = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jTableAgenda.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTableAgenda);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(0, 0, 510, 430);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 70, 510, 430);

        jLabelDescrição.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabelDescrição.setText("AGENDA DO DIA");
        getContentPane().add(jLabelDescrição);
        jLabelDescrição.setBounds(30, 0, 280, 60);
        getContentPane().add(jTextFieldData);
        jTextFieldData.setBounds(310, 10, 110, 50);

        jButtonAbrir.setText("ABRIR");
        jButtonAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbrir);
        jButtonAbrir.setBounds(433, 10, 80, 50);

        jPanel2.setBackground(new java.awt.Color(0, 248, 253));
        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 0, 540, 520);

        setSize(new java.awt.Dimension(558, 559));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirActionPerformed
    preencherTabela  ("select * from cliente a join agenda b on a.cli_cod=b.codcli_agenda where datas like '"+jTextFieldData.getText()+"' order by hora_agenda");
    }//GEN-LAST:event_jButtonAbrirActionPerformed
    public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"NOME",
                                              "TELEFONE",
                                              "HORA",
                                              "DATA",
                                              "BARBEIRO"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{conex.rs.getString("cli_nome")
                                                  ,conex.rs.getString("cli_tel")
                                                  ,conex.rs.getString("hora_agenda")
                                                  ,conex.rs.getString("datas")
                                                  ,conex.rs.getString("barbeiro")});
                                                 
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados");
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTableAgenda.setModel(modelo);
             
            jTableAgenda.getColumnModel().getColumn(0).setPreferredWidth(130);
            jTableAgenda.getColumnModel().getColumn(0).setResizable(false);
            
            jTableAgenda.getColumnModel().getColumn(1).setPreferredWidth(100);
            jTableAgenda.getColumnModel().getColumn(1).setResizable(false);
            
            jTableAgenda.getColumnModel().getColumn(2).setPreferredWidth(55);
            jTableAgenda.getColumnModel().getColumn(2).setResizable(false);
            
            jTableAgenda.getColumnModel().getColumn(3).setPreferredWidth(90);
            jTableAgenda.getColumnModel().getColumn(3).setResizable(false);
            
            jTableAgenda.getColumnModel().getColumn(4).setPreferredWidth(129);
            jTableAgenda.getColumnModel().getColumn(4).setResizable(false);
            
            jTableAgenda.getTableHeader().setReorderingAllowed(false);
            jTableAgenda.setAutoResizeMode(jTableAgenda.AUTO_RESIZE_OFF);
            jTableAgenda.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormAgenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormAgenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormAgenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormAgenda.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormAgenda().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbrir;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabelDescrição;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableAgenda;
    private javax.swing.JTextField jTextFieldData;
    // End of variables declaration//GEN-END:variables
}
