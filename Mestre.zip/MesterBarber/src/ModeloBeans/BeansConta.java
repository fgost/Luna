package ModeloBeans;

public class BeansConta{
    private String data;
    private String nome;
    private String tipo;
    private String pesquisa;
    private String fornecedor;
    private String status;
    private int cod;
    private int qtd;
    private double total;
    private double preco;
        
    public String getStatus(){
        return status;}
    public void setStatus(String status){
        this.status = status;}
    public double getTotal(){
        return total;}
    public void setTotal(double total){
        this.total = total;}
    public int getQtd(){
        return qtd;}
    public void setQtd(int qtd){
        this.qtd = qtd;}
    public String getFornecedor(){
        return fornecedor;}
    public void setFornecedor(String fornecedor){
        this.fornecedor = fornecedor;}
    public String getData(){
        return data;}
    public void setData(String data){
        this.data = data;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public String getTipo(){
        return tipo;}
    public void setTipo(String tipo){
        this.tipo = tipo;}
    public int getCod(){
        return cod;}
    public void setCod(int cod){
        this.cod = cod;}
    public double getPreco(){
        return preco;}
    public void setPreco(double preco){
        this.preco = preco;}
    public String getPesquisa(){
        return pesquisa;}
    public void setPesquisa(String pesquisa){
        this.pesquisa = pesquisa;}}