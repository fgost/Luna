package ModeloBeans;

import java.util.Date;

public class BeansEntrada{
    private String nome;
    private String data;
    private String pesquisa;
    private String mostrar;
    private int preco;
    private int pesquisa1;
    private int total;
    private int saldo;
        
    public String getMostrar(){
        return mostrar;}
    public void setMostrar(String mostrar){
        this.mostrar = mostrar;}
    public int getSaldo(){
        return saldo;}
    public void setSaldo(int saldo){
        this.saldo = saldo;}
    public int getTotal(){
        return total;}
    public void setTotal(int total){
        this.total = total;}
    public String getPesquisa(){
        return pesquisa;}
    public void setPesquisa(String pesquisa){
        this.pesquisa = pesquisa;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public int getPreco(){
        return preco;}
    public void setPreco(int preco){
        this.preco = preco;}
    public String getData(){
        return data;}
    public void setData(String data){
        this.data = data;}
    public int getPesquisa1(){
        return pesquisa1;}
    public void setPesquisa1(String pesquisa){
        this.pesquisa = pesquisa;}}