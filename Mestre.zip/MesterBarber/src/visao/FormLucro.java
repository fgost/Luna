package visao;

import ModeloBeans.ModeloTabela;
import ModeloConection.ConexaoBD;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormLucro extends javax.swing.JFrame 
    {
        ConexaoBD conex = new ConexaoBD();
    
        public FormLucro() 
            {
                initComponents();
                
                preencherEntrada("select * from caixa order by nome");
                preencherSaida("select * from conta order by nome");
            }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonSaida = new javax.swing.JButton();
        jButtonSaldo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableSaida = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableEntrada = new javax.swing.JTable();
        jTextFieldSaida = new javax.swing.JTextField();
        jTextFieldSaldo = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButtonEntrada = new javax.swing.JButton();
        jTextFieldEntrada = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldData = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jButtonSaida.setText("ABRIR");
        jButtonSaida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaidaActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSaida);
        jButtonSaida.setBounds(810, 470, 73, 30);

        jButtonSaldo.setText("VER SALDO");
        jButtonSaldo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaldoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSaldo);
        jButtonSaldo.setBounds(520, 530, 100, 30);

        jTableSaida.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTableSaida);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(710, 100, 540, 360);

        jTableEntrada.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTableEntrada);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(10, 100, 690, 360);
        getContentPane().add(jTextFieldSaida);
        jTextFieldSaida.setBounds(700, 470, 80, 30);
        getContentPane().add(jTextFieldSaldo);
        jTextFieldSaldo.setBounds(430, 530, 80, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setText("LUCROS DO MES");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(570, 0, 290, 50);

        jButtonEntrada.setText("ABRIR");
        jButtonEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEntradaActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonEntrada);
        jButtonEntrada.setBounds(320, 470, 73, 30);
        getContentPane().add(jTextFieldEntrada);
        jTextFieldEntrada.setBounds(200, 470, 80, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel2.setText("SAÍDA");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(950, 60, 80, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel3.setText("ENTRADA");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(300, 60, 110, 30);
        getContentPane().add(jTextFieldData);
        jTextFieldData.setBounds(880, 10, 120, 30);

        jButton1.setText("ABRIR");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(1030, 10, 63, 30);

        setSize(new java.awt.Dimension(1275, 605));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEntradaActionPerformed
    conex.conexao();
    conex.executaSql("SELECT sum(total) FROM caixa where SUBSTRING(datas, 4, 2) like '"+jTextFieldData.getText()+"'");
    try
        {   
            conex.rs.first();// pega o primeiro registro
            jTextFieldEntrada.setText(String.valueOf(conex.rs.getDouble(1)));// converte ele no primeiro registro para o textField
        }      
    catch (SQLException erro)  
        {   
            JOptionPane.showMessageDialog(null,"Erro ao somar os campos..."+erro);   
        }   
    }//GEN-LAST:event_jButtonEntradaActionPerformed

    private void jButtonSaidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaidaActionPerformed
    conex.conexao();
    conex.executaSql("SELECT sum(total) FROM conta where SUBSTRING(datas, 4, 2) like '"+jTextFieldData.getText()+"'");
    try
        {   
            conex.rs.first();// pega o primeiro registro
            jTextFieldSaida.setText(String.valueOf(conex.rs.getDouble(1)));// converte ele no primeiro registro para o textField
        }      
    catch (SQLException erro)   
        {   
            JOptionPane.showMessageDialog(null,"Erro ao somar os campos..."+erro);   
        }
    }//GEN-LAST:event_jButtonSaidaActionPerformed

    private void jButtonSaldoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaldoActionPerformed
    double entrada = Double.parseDouble(jTextFieldEntrada.getText());
    double saida = Double.parseDouble(jTextFieldSaida.getText());
    double r = entrada - saida;
    
    jTextFieldSaldo.setText(String.valueOf(r));   
    }//GEN-LAST:event_jButtonSaldoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    preencherSaida  ("SELECT *, SUBSTRING(datas, 4, 2) AS Initial FROM conta where SUBSTRING(datas, 4, 2) like '"+jTextFieldData.getText()+"'");
    preencherEntrada("SELECT *, SUBSTRING(datas, 4, 2) AS Initial FROM caixa where SUBSTRING(datas, 4, 2) like '"+jTextFieldData.getText()+"'");
    }//GEN-LAST:event_jButton1ActionPerformed
    public void preencherEntrada (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{  "DATA"
                                                ,"NOME"
                                                ,"SERVIÇO"
                                                ,"PREÇO"
                                                ,"PRODUTO"
                                                ,"PREÇO"
                                                ,"CONSUMO"
                                                ,"PREÇO"
                                                ,"PAGAMENTO"
                                                ,"TOTAL"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{ conex.rs.getString("DATAS")
                                                    ,conex.rs.getString("nome")
                                                    ,conex.rs.getString("servico")
                                                    ,conex.rs.getDouble("precoservico")
                                                    ,conex.rs.getString("produto")
                                                    ,conex.rs.getDouble("precoproduto")
                                                    ,conex.rs.getString("consumo")
                                                    ,conex.rs.getDouble("precoconsumo")
                                                    ,conex.rs.getString("pagamento")
                                                    ,conex.rs.getDouble("total")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTableEntrada.setModel(modelo);
            
            jTableEntrada.getColumnModel().getColumn(0).setPreferredWidth(75);
            jTableEntrada.getColumnModel().getColumn(0).setResizable(false);
            
            jTableEntrada.getColumnModel().getColumn(1).setPreferredWidth(90);
            jTableEntrada.getColumnModel().getColumn(1).setResizable(false);
            
            jTableEntrada.getColumnModel().getColumn(2).setPreferredWidth(80);
            jTableEntrada.getColumnModel().getColumn(2).setResizable(false);
            
            jTableEntrada.getColumnModel().getColumn(3).setPreferredWidth(55);
            jTableEntrada.getColumnModel().getColumn(3).setResizable(false);
            
            jTableEntrada.getColumnModel().getColumn(4).setPreferredWidth(130);
            jTableEntrada.getColumnModel().getColumn(4).setResizable(false);
            
            jTableEntrada.getColumnModel().getColumn(5).setPreferredWidth(55);
            jTableEntrada.getColumnModel().getColumn(5).setResizable(false);
            
            jTableEntrada.getColumnModel().getColumn(6).setPreferredWidth(100);
            jTableEntrada.getColumnModel().getColumn(6).setResizable(false);
            
            jTableEntrada.getColumnModel().getColumn(7).setPreferredWidth(55);
            jTableEntrada.getColumnModel().getColumn(7).setResizable(false);
            
            jTableEntrada.getColumnModel().getColumn(8).setPreferredWidth(85);
            jTableEntrada.getColumnModel().getColumn(8).setResizable(false);
            
            jTableEntrada.getColumnModel().getColumn(9).setPreferredWidth(50);
            jTableEntrada.getColumnModel().getColumn(9).setResizable(false);
            
            jTableEntrada.getTableHeader().setReorderingAllowed(false);
            jTableEntrada.setAutoResizeMode(jTableEntrada.AUTO_RESIZE_OFF);
            jTableEntrada.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    public void preencherSaida (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []
                {   
                    "DATA"
                   ,"NOME"
                   ,"TIPO"
                   ,"PREÇO"
                   ,"FORNECEDOR"
                   ,"QTD"
                   ,"TOTAL"                                               
                };            
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]
                                {  
                                    conex.rs.getString("datas")
                                   ,conex.rs.getString("nome")
                                   ,conex.rs.getString("tipo")
                                   ,conex.rs.getDouble("preco")
                                   ,conex.rs.getString("fornecedor")
                                   ,conex.rs.getInt("qtd")
                                   ,conex.rs.getDouble("total")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTableSaida.setModel(modelo);
            jTableSaida.getColumnModel().getColumn(0).setPreferredWidth(80);
            jTableSaida.getColumnModel().getColumn(0).setResizable(false);
            
            jTableSaida.getColumnModel().getColumn(1).setPreferredWidth(100);
            jTableSaida.getColumnModel().getColumn(1).setResizable(false);
            
            jTableSaida.getColumnModel().getColumn(2).setPreferredWidth(90);
            jTableSaida.getColumnModel().getColumn(2).setResizable(false);
            
            jTableSaida.getColumnModel().getColumn(3).setPreferredWidth(54);
            jTableSaida.getColumnModel().getColumn(3).setResizable(false);
            
            jTableSaida.getColumnModel().getColumn(4).setPreferredWidth(100);
            jTableSaida.getColumnModel().getColumn(4).setResizable(false);
            
            jTableSaida.getColumnModel().getColumn(5).setPreferredWidth(50);
            jTableSaida.getColumnModel().getColumn(5).setResizable(false);
            
            jTableSaida.getColumnModel().getColumn(6).setPreferredWidth(60);
            jTableSaida.getColumnModel().getColumn(6).setResizable(false);
                        
            jTableSaida.getTableHeader().setReorderingAllowed(false);
            jTableSaida.setAutoResizeMode(jTableSaida.AUTO_RESIZE_OFF);
            jTableSaida.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormLucro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormLucro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormLucro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormLucro.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormLucro().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonEntrada;
    private javax.swing.JButton jButtonSaida;
    private javax.swing.JButton jButtonSaldo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableEntrada;
    private javax.swing.JTable jTableSaida;
    private javax.swing.JTextField jTextFieldData;
    private javax.swing.JTextField jTextFieldEntrada;
    private javax.swing.JTextField jTextFieldSaida;
    private javax.swing.JTextField jTextFieldSaldo;
    // End of variables declaration//GEN-END:variables
}