package visao;

import ModeloBeans.BeansEntrada;
import ModeloConection.ConexaoBD;
import ModeloDao.DaoEntrada;
import ModeloBeans.ModeloTabela;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormEntrada extends javax.swing.JFrame 
    {
        BeansEntrada mod = new BeansEntrada();
        DaoEntrada control = new DaoEntrada();
        ConexaoBD conex = new ConexaoBD();
        
        public FormEntrada() 
            {
                initComponents();
                preencherTabela("select * from caixa order by nome");
            }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jButtonNome = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldNome = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jTextFieldPreço = new javax.swing.JTextField();
        jButtonPreço = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTablePesquisa);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(12, 102, 543, 320);

        jButtonNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonNome.setText("BUSCAR");
        jButtonNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNomeActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonNome);
        jButtonNome.setBounds(440, 20, 110, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("BUSCAR POR NOME");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(12, 17, 140, 30);

        jTextFieldNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldNome);
        jTextFieldNome.setBounds(150, 20, 280, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("BUSCAR POR PREÇO");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(10, 60, 140, 30);

        jTextFieldPreço.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldPreço);
        jTextFieldPreço.setBounds(150, 60, 280, 30);

        jButtonPreço.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonPreço.setText("BUSCAR");
        jButtonPreço.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPreçoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonPreço);
        jButtonPreço.setBounds(440, 60, 110, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 80, 567, 430);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 36)); // NOI18N
        jLabel1.setText("ENTRADA CAIXA");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(168, 20, 277, 60);

        setSize(new java.awt.Dimension(603, 574));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNomeActionPerformed
    BeansEntrada model = control.buscaPorNome(mod);
    mod.setPesquisa(jTextFieldNome.getText());
    jTextFieldNome.setText(model.getNome());
    
    preencherTabela("select * from caixa where nome like '%"+mod.getPesquisa()+"%'");
    }//GEN-LAST:event_jButtonNomeActionPerformed

    private void jButtonPreçoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPreçoActionPerformed
    BeansEntrada model = control.buscaPreco(mod);
    mod.setPesquisa(jTextFieldPreço.getText());
    jTextFieldPreço.setText(String.valueOf(model.getPreco()));
    
    preencherTabela("select * from caixa where total = '"+mod.getPesquisa()+"'");
    }//GEN-LAST:event_jButtonPreçoActionPerformed
        public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{   "nome"
                                                ,"serviço"
                                                ,"preço"
                                                ,"produto"
                                                ,"preço"
                                                ,"consumo"
                                                ,"preço"
                                                ,"corte"
                                                ,"pagamento"
                                                ,"total"
                                                ,"barbeiro"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{  conex.rs.getString("nome")
                                                    ,conex.rs.getString("servico")
                                                    ,conex.rs.getDouble("precoservico")
                                                    ,conex.rs.getString("produto")
                                                    ,conex.rs.getDouble("precoproduto")
                                                    ,conex.rs.getString("consumo")
                                                    ,conex.rs.getDouble("precoconsumo")
                                                    ,conex.rs.getString("tipocorte")
                                                    ,conex.rs.getString("pagamento")
                                                    ,conex.rs.getDouble("total")
                                                    ,conex.rs.getString("barbeiro")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTablePesquisa.setModel(modelo);
            jTablePesquisa.getColumnModel().getColumn(0).setPreferredWidth(100);
            jTablePesquisa.getColumnModel().getColumn(0).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(1).setPreferredWidth(100);
            jTablePesquisa.getColumnModel().getColumn(1).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(2).setPreferredWidth(50);
            jTablePesquisa.getColumnModel().getColumn(2).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(3).setPreferredWidth(100);
            jTablePesquisa.getColumnModel().getColumn(3).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(4).setPreferredWidth(50);
            jTablePesquisa.getColumnModel().getColumn(4).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(5).setPreferredWidth(100);
            jTablePesquisa.getColumnModel().getColumn(5).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(6).setPreferredWidth(50);
            jTablePesquisa.getColumnModel().getColumn(6).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(7).setPreferredWidth(100);
            jTablePesquisa.getColumnModel().getColumn(7).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(8).setPreferredWidth(100);
            jTablePesquisa.getColumnModel().getColumn(8).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(9).setPreferredWidth(50);
            jTablePesquisa.getColumnModel().getColumn(9).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(10).setPreferredWidth(100);
            jTablePesquisa.getColumnModel().getColumn(10).setResizable(false);
            
            jTablePesquisa.getTableHeader().setReorderingAllowed(false);
            jTablePesquisa.setAutoResizeMode(jTablePesquisa.AUTO_RESIZE_OFF);
            jTablePesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }    
    public static void main(String args[]) 
        {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormEntrada.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormEntrada.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormEntrada.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormEntrada.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                        {
                            new FormEntrada().setVisible(true);
                        }
                });
        }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonNome;
    private javax.swing.JButton jButtonPreço;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldPreço;
    // End of variables declaration//GEN-END:variables
    }