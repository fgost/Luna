package visao;

import ModeloConection.ConexaoBD;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class TelaLogin extends javax.swing.JFrame 
    {
        ConexaoBD con = new ConexaoBD();
        public TelaLogin() 
            {
                initComponents();
                con.conexao();
            }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButtonAcessar = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();
        jLabelUsuario = new javax.swing.JLabel();
        jLabelSenha = new javax.swing.JLabel();
        jTextFieldUsuario = new javax.swing.JTextField();
        jPasswordFieldSenha = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        jLabelLogo1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 153, 0));
        getContentPane().setLayout(null);

        jButtonAcessar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonAcessar.setText("ACESSAR");
        jButtonAcessar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAcessarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAcessar);
        jButtonAcessar.setBounds(140, 170, 110, 40);

        jButtonSair.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonSair.setText("SAIR");
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(320, 170, 110, 40);

        jLabelUsuario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelUsuario.setText("USUÁRIO");
        getContentPane().add(jLabelUsuario);
        jLabelUsuario.setBounds(30, 100, 70, 40);

        jLabelSenha.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelSenha.setText("SENHA");
        getContentPane().add(jLabelSenha);
        jLabelSenha.setBounds(350, 100, 50, 40);

        jTextFieldUsuario.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jTextFieldUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldUsuarioActionPerformed(evt);
            }
        });
        getContentPane().add(jTextFieldUsuario);
        jTextFieldUsuario.setBounds(100, 100, 240, 40);

        jPasswordFieldSenha.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jPasswordFieldSenha.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPasswordFieldSenhaMouseEntered(evt);
            }
        });
        getContentPane().add(jPasswordFieldSenha);
        jPasswordFieldSenha.setBounds(400, 100, 160, 40);

        jLabel1.setText(" Developed by Frn System");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(400, 270, 170, 20);

        jLabelLogo1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/login.png"))); // NOI18N
        getContentPane().add(jLabelLogo1);
        jLabelLogo1.setBounds(0, -10, 590, 460);

        setSize(new java.awt.Dimension(603, 338));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAcessarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAcessarActionPerformed
            try 
                {
                    con.executaSql("select * from usuarios where usu_nome = '"+jTextFieldUsuario.getText()+"'");
                    con.rs.first();
                if(con.rs.getString("usu_senha").equals(jPasswordFieldSenha.getText()))
                    {
                        TelaPrincipal tela = new TelaPrincipal(jTextFieldUsuario.getText());
                        tela.setVisible(true);
                        dispose();
                    }
                else
                    {
                        JOptionPane.showMessageDialog(rootPane, "senha ou usuario incorretos");
                    }
                }
            catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(rootPane, "senha ou usuario incorretos"+ex);
                }
            
    }//GEN-LAST:event_jButtonAcessarActionPerformed

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
    System.exit(0);
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jPasswordFieldSenhaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPasswordFieldSenhaMouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordFieldSenhaMouseEntered

    private void jTextFieldUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldUsuarioActionPerformed

    public static void main(String args[]) 
        {
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                        {
                            new TelaLogin().setVisible(true);
                        }
                });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAcessar;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelLogo1;
    private javax.swing.JLabel jLabelSenha;
    private javax.swing.JLabel jLabelUsuario;
    private javax.swing.JPasswordField jPasswordFieldSenha;
    private javax.swing.JTextField jTextFieldUsuario;
    // End of variables declaration//GEN-END:variables
}