package visao;

import ModeloConection.ConexaoBD;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class TelaPrincipal extends javax.swing.JFrame 
    {
        ConexaoBD conecta = new ConexaoBD();
        FormFuncionario tela = new FormFuncionario();
        FormUsuario telaUsu = new FormUsuario();
        FormClientes telacli = new FormClientes();
        FormServiços telapro = new FormServiços();
        FormAgendamento telaagen = new FormAgendamento();        
        FormFornecedor telafor = new FormFornecedor();
        FormContas telacon = new FormContas();
        FormAgenda telaage = new FormAgenda();
        FormEntrada telaent = new FormEntrada();
        FormSaida telasai = new FormSaida();
        FormCadastro telacad = new FormCadastro();
        FormLucro telaluc = new FormLucro();
        FormInicioia telaini = new FormInicioia();
        FormPagamento telapag = new FormPagamento();
    public TelaPrincipal(String Usuario) 
        {
            initComponents();
            jLabelUsuario.setText(Usuario);
            conecta.conexao();
        }

    TelaPrincipal() 
        {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jInternalFrameBemVindo = new javax.swing.JInternalFrame();
        jLabelSistema = new javax.swing.JLabel();
        jPanelInternalFrame = new javax.swing.JPanel();
        jLabelCadastros = new javax.swing.JLabel();
        jButtonFuncionarios = new javax.swing.JButton();
        jButtonClientes = new javax.swing.JButton();
        jButtonProdutos = new javax.swing.JButton();
        jButtonUsuarios = new javax.swing.JButton();
        jLabelAgenda = new javax.swing.JLabel();
        jButtonAgenda = new javax.swing.JButton();
        jButtonAgendamento = new javax.swing.JButton();
        jLabelRelatorios = new javax.swing.JLabel();
        jButtonCaixa = new javax.swing.JButton();
        jButtonEntrada = new javax.swing.JButton();
        jLabelCaixa = new javax.swing.JLabel();
        jButtonSaida = new javax.swing.JButton();
        jButtonFornecedor = new javax.swing.JButton();
        jButtonConta = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButtonFecharBemVindo = new javax.swing.JButton();
        jLabelUsuario1 = new javax.swing.JLabel();
        jLabelUsuario = new javax.swing.JLabel();
        jLabellAtalhoAgendamento = new javax.swing.JLabel();
        jLabellAtalhoContas = new javax.swing.JLabel();
        jLabellAtalhoEntrada = new javax.swing.JLabel();
        jLabellAtalhoSaida = new javax.swing.JLabel();
        jLabellAtalhoFornecedores = new javax.swing.JLabel();
        jLabellAtalhoAgenda = new javax.swing.JLabel();
        jLabelAtalhoCaixa = new javax.swing.JLabel();
        jLabellAtalhoCadastros = new javax.swing.JLabel();
        jLabellAtalhoSair = new javax.swing.JLabel();
        jLabelAtalhoCaixa1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenuCadastros = new javax.swing.JMenu();
        jMenuItemFornecedor = new javax.swing.JMenuItem();
        jMenuItemContas = new javax.swing.JMenuItem();
        jMenuItemCadastros = new javax.swing.JMenuItem();
        jMenuRelatorios = new javax.swing.JMenu();
        jMenuItemAuditoria = new javax.swing.JMenuItem();
        jMenuItemEntrada = new javax.swing.JMenuItem();
        jMenuItemSaida = new javax.swing.JMenuItem();
        jMenuFerramentas = new javax.swing.JMenu();
        jMenuItemTelaBemVindo = new javax.swing.JMenuItem();
        jMenuItemCaixa = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuAgenda = new javax.swing.JMenu();
        jMenuItemAgenda = new javax.swing.JMenuItem();
        jMenuItemAgendamento = new javax.swing.JMenuItem();
        jMenuSair = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jInternalFrameBemVindo.setTitle("BEM-VINDO");
        jInternalFrameBemVindo.setVisible(true);
        jInternalFrameBemVindo.getContentPane().setLayout(null);

        jLabelSistema.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabelSistema.setText("ATIVIDADES");
        jInternalFrameBemVindo.getContentPane().add(jLabelSistema);
        jLabelSistema.setBounds(190, 10, 150, 30);

        jPanelInternalFrame.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanelInternalFrame.setLayout(null);

        jLabelCadastros.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelCadastros.setText("CADASTROS");
        jPanelInternalFrame.add(jLabelCadastros);
        jLabelCadastros.setBounds(12, 13, 100, 17);

        jButtonFuncionarios.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonFuncionarios.setText("FUNCIONARIOS");
        jButtonFuncionarios.setToolTipText("Cadastro de Funcionários");
        jButtonFuncionarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFuncionariosActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonFuncionarios);
        jButtonFuncionarios.setBounds(10, 40, 130, 40);

        jButtonClientes.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonClientes.setText("CLIENTES");
        jButtonClientes.setToolTipText("Cadastro de clientes");
        jButtonClientes.setMaximumSize(new java.awt.Dimension(93, 23));
        jButtonClientes.setMinimumSize(new java.awt.Dimension(93, 23));
        jButtonClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonClientesActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonClientes);
        jButtonClientes.setBounds(150, 90, 130, 40);

        jButtonProdutos.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonProdutos.setText("PRODUTOS");
        jButtonProdutos.setToolTipText("Cadastro de Produtos");
        jButtonProdutos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonProdutosActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonProdutos);
        jButtonProdutos.setBounds(10, 90, 130, 40);

        jButtonUsuarios.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonUsuarios.setText("USUÁRIOS");
        jButtonUsuarios.setToolTipText("Cadastro de  Usuários");
        jButtonUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonUsuariosActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonUsuarios);
        jButtonUsuarios.setBounds(150, 40, 130, 40);

        jLabelAgenda.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelAgenda.setText("AGENDA");
        jPanelInternalFrame.add(jLabelAgenda);
        jLabelAgenda.setBounds(10, 140, 70, 17);

        jButtonAgenda.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonAgenda.setText("AGENDA");
        jButtonAgenda.setToolTipText("Tarefas do dia");
        jButtonAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAgendaActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonAgenda);
        jButtonAgenda.setBounds(10, 160, 130, 40);

        jButtonAgendamento.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonAgendamento.setText("AGENDAMENTO");
        jButtonAgendamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAgendamentoActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonAgendamento);
        jButtonAgendamento.setBounds(150, 160, 130, 40);

        jLabelRelatorios.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelRelatorios.setText("RELATORIOS");
        jPanelInternalFrame.add(jLabelRelatorios);
        jLabelRelatorios.setBounds(10, 210, 90, 20);

        jButtonCaixa.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonCaixa.setText("CAIXA");
        jButtonCaixa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCaixaActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonCaixa);
        jButtonCaixa.setBounds(10, 330, 130, 40);

        jButtonEntrada.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonEntrada.setText("ENTRADA");
        jButtonEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEntradaActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonEntrada);
        jButtonEntrada.setBounds(10, 240, 130, 40);

        jLabelCaixa.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelCaixa.setText("CAIXA");
        jPanelInternalFrame.add(jLabelCaixa);
        jLabelCaixa.setBounds(20, 300, 60, 30);

        jButtonSaida.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonSaida.setText("SAIDA");
        jButtonSaida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaidaActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonSaida);
        jButtonSaida.setBounds(150, 240, 130, 40);

        jButtonFornecedor.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonFornecedor.setText("FORNECEDOR");
        jButtonFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFornecedorActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonFornecedor);
        jButtonFornecedor.setBounds(290, 40, 130, 40);

        jButtonConta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonConta.setText("CONTAS");
        jButtonConta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonContaActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButtonConta);
        jButtonConta.setBounds(290, 90, 130, 40);

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("LUCROS");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanelInternalFrame.add(jButton1);
        jButton1.setBounds(290, 240, 130, 40);

        jInternalFrameBemVindo.getContentPane().add(jPanelInternalFrame);
        jPanelInternalFrame.setBounds(60, 50, 430, 380);

        jButtonFecharBemVindo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonFecharBemVindo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/sair2.png"))); // NOI18N
        jButtonFecharBemVindo.setToolTipText("Fechar Tela Bem-vindo");
        jButtonFecharBemVindo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFecharBemVindoActionPerformed(evt);
            }
        });
        jInternalFrameBemVindo.getContentPane().add(jButtonFecharBemVindo);
        jButtonFecharBemVindo.setBounds(510, 0, 30, 30);

        getContentPane().add(jInternalFrameBemVindo);
        jInternalFrameBemVindo.setBounds(10, 10, 560, 470);

        jLabelUsuario1.setText("Usuário: ");
        getContentPane().add(jLabelUsuario1);
        jLabelUsuario1.setBounds(10, 470, 50, 30);
        getContentPane().add(jLabelUsuario);
        jLabelUsuario.setBounds(60, 470, 120, 30);

        jLabellAtalhoAgendamento.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabellAtalhoAgendamento.setText("F5 - ABRIR AGENDAMENTO");
        getContentPane().add(jLabellAtalhoAgendamento);
        jLabellAtalhoAgendamento.setBounds(10, 130, 170, 30);

        jLabellAtalhoContas.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabellAtalhoContas.setText("F7 - ABRIR CONTAS");
        getContentPane().add(jLabellAtalhoContas);
        jLabellAtalhoContas.setBounds(10, 190, 130, 30);

        jLabellAtalhoEntrada.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabellAtalhoEntrada.setText("F2 - ABRIR ENTRADA");
        getContentPane().add(jLabellAtalhoEntrada);
        jLabellAtalhoEntrada.setBounds(10, 40, 140, 30);

        jLabellAtalhoSaida.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabellAtalhoSaida.setText("F3 - ABRIR SAIDA");
        getContentPane().add(jLabellAtalhoSaida);
        jLabellAtalhoSaida.setBounds(10, 70, 120, 30);

        jLabellAtalhoFornecedores.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabellAtalhoFornecedores.setText("F6 - ABRIR FORNECEDORES");
        getContentPane().add(jLabellAtalhoFornecedores);
        jLabellAtalhoFornecedores.setBounds(10, 160, 180, 30);

        jLabellAtalhoAgenda.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabellAtalhoAgenda.setText("F4 - ABRIR AGENDA");
        getContentPane().add(jLabellAtalhoAgenda);
        jLabellAtalhoAgenda.setBounds(10, 100, 130, 30);

        jLabelAtalhoCaixa.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelAtalhoCaixa.setText("0 - SALARIOS");
        getContentPane().add(jLabelAtalhoCaixa);
        jLabelAtalhoCaixa.setBounds(10, 280, 110, 30);

        jLabellAtalhoCadastros.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabellAtalhoCadastros.setText("F8 - CADASTROS");
        getContentPane().add(jLabellAtalhoCadastros);
        jLabellAtalhoCadastros.setBounds(10, 220, 120, 30);

        jLabellAtalhoSair.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabellAtalhoSair.setText("ALT + F4 - SAIR");
        getContentPane().add(jLabellAtalhoSair);
        jLabellAtalhoSair.setBounds(10, 250, 110, 30);

        jLabelAtalhoCaixa1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelAtalhoCaixa1.setText("F1 - ABRIR CAIXA");
        getContentPane().add(jLabelAtalhoCaixa1);
        jLabelAtalhoCaixa1.setBounds(10, 10, 110, 30);

        jMenuCadastros.setText("Cadastros");

        jMenuItemFornecedor.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F6, 0));
        jMenuItemFornecedor.setText("Fornecedor");
        jMenuItemFornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemFornecedorActionPerformed(evt);
            }
        });
        jMenuCadastros.add(jMenuItemFornecedor);

        jMenuItemContas.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F7, 0));
        jMenuItemContas.setText("Contas");
        jMenuItemContas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemContasActionPerformed(evt);
            }
        });
        jMenuCadastros.add(jMenuItemContas);

        jMenuItemCadastros.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F8, 0));
        jMenuItemCadastros.setText("Cadastros");
        jMenuItemCadastros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemCadastrosActionPerformed(evt);
            }
        });
        jMenuCadastros.add(jMenuItemCadastros);

        jMenuBar1.add(jMenuCadastros);

        jMenuRelatorios.setText("Relatorios");

        jMenuItemAuditoria.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F9, 0));
        jMenuItemAuditoria.setText("Auditoria");
        jMenuItemAuditoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemAuditoriaActionPerformed(evt);
            }
        });
        jMenuRelatorios.add(jMenuItemAuditoria);

        jMenuItemEntrada.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F2, 0));
        jMenuItemEntrada.setText("Entrada");
        jMenuItemEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemEntradaActionPerformed(evt);
            }
        });
        jMenuRelatorios.add(jMenuItemEntrada);

        jMenuItemSaida.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, 0));
        jMenuItemSaida.setText("Saída");
        jMenuItemSaida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemSaidaActionPerformed(evt);
            }
        });
        jMenuRelatorios.add(jMenuItemSaida);

        jMenuBar1.add(jMenuRelatorios);

        jMenuFerramentas.setText("Ferramentas");

        jMenuItemTelaBemVindo.setText("Tela Bem-Vindo");
        jMenuItemTelaBemVindo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemTelaBemVindoActionPerformed(evt);
            }
        });
        jMenuFerramentas.add(jMenuItemTelaBemVindo);

        jMenuItemCaixa.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, 0));
        jMenuItemCaixa.setText("Caixa");
        jMenuItemCaixa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemCaixaActionPerformed(evt);
            }
        });
        jMenuFerramentas.add(jMenuItemCaixa);

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_0, 0));
        jMenuItem1.setText("Salarios");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenuFerramentas.add(jMenuItem1);

        jMenuBar1.add(jMenuFerramentas);

        jMenuAgenda.setText("Agenda");

        jMenuItemAgenda.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, 0));
        jMenuItemAgenda.setText("Agenda");
        jMenuItemAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemAgendaActionPerformed(evt);
            }
        });
        jMenuAgenda.add(jMenuItemAgenda);

        jMenuItemAgendamento.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F5, 0));
        jMenuItemAgendamento.setText("Agendamento");
        jMenuItemAgendamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemAgendamentoActionPerformed(evt);
            }
        });
        jMenuAgenda.add(jMenuItemAgendamento);

        jMenuBar1.add(jMenuAgenda);

        jMenuSair.setText("Sair");
        jMenuSair.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenuSairMouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenuSair);

        setJMenuBar(jMenuBar1);

        setSize(new java.awt.Dimension(598, 561));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonFecharBemVindoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFecharBemVindoActionPerformed
    jInternalFrameBemVindo.dispose();
    }//GEN-LAST:event_jButtonFecharBemVindoActionPerformed

    private void jMenuItemTelaBemVindoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemTelaBemVindoActionPerformed
    jInternalFrameBemVindo.setVisible(true);
    }//GEN-LAST:event_jMenuItemTelaBemVindoActionPerformed

    private void jButtonFuncionariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFuncionariosActionPerformed
    try 
        {
            conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
            conecta.rs.first();
            if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente"))
                {
                    if(tela==null)
                        {
                            tela.setVisible(true);
                            tela.setResizable(false);
                        }
                    else
                        {
                            tela.setVisible(true);
                            tela.setResizable(false);
                        }    
                }
            else
                {
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
        } 
    catch (SQLException ex) 
        {
            JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
        }
    }//GEN-LAST:event_jButtonFuncionariosActionPerformed

    private void jButtonUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonUsuariosActionPerformed
    try 
        {
            conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
            conecta.rs.first();
            if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente"))
                {
                    if(tela==null)
                        {
                            telaUsu.setVisible(true);
                            telaUsu.setResizable(false);
                        }
                    else
                        {
                            telaUsu.setVisible(true);
                            telaUsu.setResizable(false);
                        }
                }  
            else 
                {
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
             }
        catch (SQLException ex) 
            {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jButtonUsuariosActionPerformed

    private void jButtonClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonClientesActionPerformed
    try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                    if(telacli==null){
                        telacli.setVisible(true);
                        telacli.setResizable(false);
                    }else{
                        telacli.setVisible(true);
                        telacli.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jButtonClientesActionPerformed

    private void jButtonProdutosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonProdutosActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telapro.setVisible(true);
                        telapro.setResizable(false);
                    }else{
                        telapro.setVisible(true);
                        telapro.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jButtonProdutosActionPerformed

    private void jButtonAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAgendaActionPerformed
    if(telaage==null){
        telaage.setVisible(true);
        telaage.setResizable(false);
        }
       else
        {
            telaage.setVisible(true);
            telaage.setResizable(false);
        }         
    }//GEN-LAST:event_jButtonAgendaActionPerformed

    private void jMenuItemCaixaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemCaixaActionPerformed
    try 
        {
            conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
            conecta.rs.first();
            if(conecta.rs.getString("usu_tipo").equals("Administrador"))
                {
                    if(telaini==null)
                        {
                            telaini.setVisible(true);
                            telaini.setResizable(false);
                        }
                    else
                        {
                            telaini.setVisible(true);
                            telaini.setResizable(false);
                        }

                    //FormClientes tela = new FormClientes();
                    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jMenuItemCaixaActionPerformed

    private void jButtonAgendamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAgendamentoActionPerformed
        if(telaagen==null){
                        telaagen.setVisible(true);
                        telaagen.setResizable(false);
                    }else{
                        telaagen.setVisible(true);
                        telaagen.setResizable(false);
                    }
    }//GEN-LAST:event_jButtonAgendamentoActionPerformed

    private void jButtonCaixaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCaixaActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")||conecta.rs.getString("usu_tipo").equals("Barbeiro")){
                    if(telaini==null){
                        telaini.setVisible(true);
                        telaini.setResizable(false);
                    }else{
                        telaini.setVisible(true);
                        telaini.setResizable(false);
                    }

                    
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jButtonCaixaActionPerformed

    private void jButtonEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEntradaActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telaent.setVisible(true);
                        telaent.setResizable(false);
                    }else{
                        telaent.setVisible(true);
                        telaent.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jButtonEntradaActionPerformed

    private void jButtonFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFornecedorActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telafor.setVisible(true);
                        telafor.setResizable(false);
                    }else{
                        telafor.setVisible(true);
                        telafor.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jButtonFornecedorActionPerformed

    private void jButtonContaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonContaActionPerformed
       try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telacon.setVisible(true);
                        telacon.setResizable(false);
                    }else{
                        telacon.setVisible(true);
                        telacon.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jButtonContaActionPerformed

    private void jButtonSaidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaidaActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telasai.setVisible(true);
                        telasai.setResizable(false);
                    }else{
                        telasai.setVisible(true);
                        telasai.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jButtonSaidaActionPerformed

    private void jMenuItemEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemEntradaActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telaent.setVisible(true);
                        telaent.setResizable(false);
                    }else{
                        telaent.setVisible(true);
                        telaent.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jMenuItemEntradaActionPerformed

    private void jMenuSairMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenuSairMouseClicked
        dispose();
    }//GEN-LAST:event_jMenuSairMouseClicked

    private void jMenuItemFornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemFornecedorActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telafor.setVisible(true);
                        telafor.setResizable(false);
                    }else{
                        telafor.setVisible(true);
                        telafor.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jMenuItemFornecedorActionPerformed

    private void jMenuItemCadastrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemCadastrosActionPerformed
    telacad = new FormCadastro();
    telacad.setVisible(true);
    telacad.setResizable(false);
    }//GEN-LAST:event_jMenuItemCadastrosActionPerformed

    private void jMenuItemAuditoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemAuditoriaActionPerformed

    }//GEN-LAST:event_jMenuItemAuditoriaActionPerformed

    private void jMenuItemContasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemContasActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telacon.setVisible(true);
                        telacon.setResizable(false);
                    }else{
                        telacon.setVisible(true);
                        telacon.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jMenuItemContasActionPerformed

    private void jMenuItemSaidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemSaidaActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telasai.setVisible(true);
                        telasai.setResizable(false);
                    }else{
                        telasai.setVisible(true);
                        telasai.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jMenuItemSaidaActionPerformed

    private void jMenuItemAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemAgendaActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telaage.setVisible(true);
                        telaage.setResizable(false);
                    }else{
                        telaage.setVisible(true);
                        telaage.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jMenuItemAgendaActionPerformed

    private void jMenuItemAgendamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemAgendamentoActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(tela==null){
                        telaagen.setVisible(true);
                        telaagen.setResizable(false);
                    }else{
                        telaagen.setVisible(true);
                        telaagen.setResizable(false);
                    }

                    //FormClientes tela = new FormClientes();
    //tela.setVisible(true);
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jMenuItemAgendamentoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
                conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
                conecta.rs.first();
                if(conecta.rs.getString("usu_tipo").equals("Administrador")||conecta.rs.getString("usu_tipo").equals("Gerente")){
                   if(telaluc==null){
                        telaluc.setVisible(true);
                        telaluc.setResizable(false);
                    }else{
                        telaluc.setVisible(true);
                        telaluc.setResizable(false);
                    }
                }
            else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
       try 
        {
            conecta.executaSql("select * from usuarios where usu_nome ='"+jLabelUsuario.getText()+"'");
            conecta.rs.first();
            if(conecta.rs.getString("usu_tipo").equals("Administrador"))
                {
                    if(telaini==null)
                        {
                            telapag.setVisible(true);
                            telapag.setResizable(false);
                        }
                    else
                        {
                            telapag.setVisible(true);
                            telapag.setResizable(false);
                        }
    
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema");
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, "Acesso Negado!\n Contate o administrador do sistema"+ex);
            }
    }//GEN-LAST:event_jMenuItem1ActionPerformed
    public static void main(String args[]) 
        {
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                        {
                              new TelaPrincipal().setVisible(true);
                        }
                });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButtonAgenda;
    private javax.swing.JButton jButtonAgendamento;
    private javax.swing.JButton jButtonCaixa;
    private javax.swing.JButton jButtonClientes;
    private javax.swing.JButton jButtonConta;
    private javax.swing.JButton jButtonEntrada;
    private javax.swing.JButton jButtonFecharBemVindo;
    private javax.swing.JButton jButtonFornecedor;
    private javax.swing.JButton jButtonFuncionarios;
    private javax.swing.JButton jButtonProdutos;
    private javax.swing.JButton jButtonSaida;
    private javax.swing.JButton jButtonUsuarios;
    private javax.swing.JInternalFrame jInternalFrameBemVindo;
    private javax.swing.JLabel jLabelAgenda;
    private javax.swing.JLabel jLabelAtalhoCaixa;
    private javax.swing.JLabel jLabelAtalhoCaixa1;
    private javax.swing.JLabel jLabelCadastros;
    private javax.swing.JLabel jLabelCaixa;
    private javax.swing.JLabel jLabelRelatorios;
    private javax.swing.JLabel jLabelSistema;
    private javax.swing.JLabel jLabelUsuario;
    private javax.swing.JLabel jLabelUsuario1;
    private javax.swing.JLabel jLabellAtalhoAgenda;
    private javax.swing.JLabel jLabellAtalhoAgendamento;
    private javax.swing.JLabel jLabellAtalhoCadastros;
    private javax.swing.JLabel jLabellAtalhoContas;
    private javax.swing.JLabel jLabellAtalhoEntrada;
    private javax.swing.JLabel jLabellAtalhoFornecedores;
    private javax.swing.JLabel jLabellAtalhoSaida;
    private javax.swing.JLabel jLabellAtalhoSair;
    private javax.swing.JMenu jMenuAgenda;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenu jMenuCadastros;
    private javax.swing.JMenu jMenuFerramentas;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItemAgenda;
    private javax.swing.JMenuItem jMenuItemAgendamento;
    private javax.swing.JMenuItem jMenuItemAuditoria;
    private javax.swing.JMenuItem jMenuItemCadastros;
    private javax.swing.JMenuItem jMenuItemCaixa;
    private javax.swing.JMenuItem jMenuItemContas;
    private javax.swing.JMenuItem jMenuItemEntrada;
    private javax.swing.JMenuItem jMenuItemFornecedor;
    private javax.swing.JMenuItem jMenuItemSaida;
    private javax.swing.JMenuItem jMenuItemTelaBemVindo;
    private javax.swing.JMenu jMenuRelatorios;
    private javax.swing.JMenu jMenuSair;
    private javax.swing.JPanel jPanelInternalFrame;
    // End of variables declaration//GEN-END:variables
}