package mesterbarber;

public class MesterBarber {
    public static void main(String[] args) {}}
