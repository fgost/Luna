package ModeloBeans;

public class BeansFuncionario {
    private int codigo;
    private String nome;
    private String cargo;
    private int login;
    private String pesquisa;
    
    public String getPesquisa(){
        return pesquisa;}
    public void setPesquisa(String pesquisa){
        this.pesquisa = pesquisa;}
    public int getCodigo(){
        return codigo;}
    public void setCodigo(int codigo){
        this.codigo = codigo;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public String getCargo(){
        return cargo;}
    public void setCargo(String cargo){
        this.cargo = cargo;}
    public int getLogin(){
        return login;}
    public void setLogin(int login){
        this.login = login;}}