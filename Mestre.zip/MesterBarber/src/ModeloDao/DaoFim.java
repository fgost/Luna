package ModeloDao;

import ModeloBeans.BeansFim;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoFim 
    {
    BeansFim mod = new BeansFim();
    ConexaoBD conex = new ConexaoBD();
        public void Salvar(BeansFim mod)
        {
            conex.conexao();
            try 
                {   
                    PreparedStatement pst = conex.con.prepareStatement("insert into fim (nome,datas,valor,usuario1,senha1) values (?,?,?,?,?)");
                    pst.setString(1, mod.getNome());   
                   pst.setDate(2,new java.sql.Date(mod.getData().getTime()));
                    pst.setDouble(3, mod.getValor());            
                    pst.setString(4,mod.getUsuario1());
                    pst.setString(5, mod.getSenha1());
                    pst.execute();
                    JOptionPane.showMessageDialog(null,"DIA FINALIZADO COM SUCESSO");
                }     
            catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(null,"ERRO AO FINALIZAR O DIA!\n"+ex );
                }
            conex.desconecta();
        }
    }