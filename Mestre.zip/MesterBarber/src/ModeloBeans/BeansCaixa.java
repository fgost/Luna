package ModeloBeans;

public class BeansCaixa{
    private String nome;
    private String data;
    private String produto;
    private String tipo;
    private String pagamento;
    private String barbeiro;
    private String obs;
    private int qtd;
    private int codigo;
    private double preco;
    private double total;
    private double totalpago;
    private double totalaberto;

    public double getTotalaberto() {
        return totalaberto;
    }

    public void setTotalaberto(double totalaberto) {
        this.totalaberto = totalaberto;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public double getTotalpago() {
        return totalpago;
    }

    public void setTotalpago(double totalpago) {
        this.totalpago = totalpago;
    }
    private String pesquisa;
    
    public int getCodigo(){
        return codigo;}
    public void setCodigo(int codigo){
        this.codigo = codigo;}
    public String getPesquisa(){
        return pesquisa;}
    public void setPesquisa(String pesquisa){
        this.pesquisa = pesquisa;}
    public String getBarbeiro(){
        return barbeiro;}
    public void setBarbeiro(String barbeiro){
        this.barbeiro = barbeiro;}
    public int getQtd(){
        return qtd;}
    public void setQtd(int qtd){
        this.qtd = qtd;}
    
    public String getData(){
        return data;}
    public void setData(String data){
        this.data = data;}
    public String getNome(){
        return nome;}
    public void setNome(String nome){
        this.nome = nome;}
    public String getProduto(){
        return produto;}
    public void setProduto(String produto){
        this.produto = produto;}
    
    public String getTipo(){
        return tipo;}
    public void setTipo(String tipo){
        this.tipo = tipo;}
    public String getPagamento(){
        return pagamento;}
    public void setPagamento(String pagamento){
        this.pagamento = pagamento;}
    public double getPreco(){
        return preco;}
    public void setPreco(double preco){
        this.preco = preco;}
    public double getTotal(){
        return total;}
    public void setTotal(double total){
        this.total = total;}}