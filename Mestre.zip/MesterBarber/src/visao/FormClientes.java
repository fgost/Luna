package visao;

import ModeloBeans.BeansCliente;
import ModeloConection.ConexaoBD;
import ModeloBeans.ModeloTabela;
import ModeloDao.DaoCliente;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormClientes extends javax.swing.JFrame 
    {
        BeansCliente mod = new BeansCliente();
        DaoCliente control = new DaoCliente();
        ConexaoBD conex = new ConexaoBD();
        int flag = 0;
    
        public FormClientes() 
            {
                initComponents();
                preencherTabela("select * from cliente order by cli_nome");
            }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabelNome = new javax.swing.JLabel();
        jLabelCargo = new javax.swing.JLabel();
        jTextFieldNomeCliente = new javax.swing.JTextField();
        jButtonNovo = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableCliente = new javax.swing.JTable();
        jTextFieldPesquisa = new javax.swing.JTextField();
        jButtonPesquisar = new javax.swing.JButton();
        jTextFieldTelefoneCliente = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldCodCliente = new javax.swing.JTextField();
        jLabelCad = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabelNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelNome.setText("NOME");
        jPanel1.add(jLabelNome);
        jLabelNome.setBounds(190, 20, 50, 30);

        jLabelCargo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabelCargo.setText("TELEFONE");
        jPanel1.add(jLabelCargo);
        jLabelCargo.setBounds(140, 60, 70, 30);

        jTextFieldNomeCliente.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldNomeCliente.setEnabled(false);
        jPanel1.add(jTextFieldNomeCliente);
        jTextFieldNomeCliente.setBounds(240, 20, 160, 30);

        jButtonNovo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonNovo.setText("NOVO");
        jButtonNovo.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonNovo);
        jButtonNovo.setBounds(10, 20, 100, 30);

        jButtonSalvar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonSalvar.setText("SALVAR");
        jButtonSalvar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalvar);
        jButtonSalvar.setBounds(10, 70, 100, 30);

        jButtonCancelar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonCancelar.setText("CANCELAR");
        jButtonCancelar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonCancelar.setEnabled(false);
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCancelar);
        jButtonCancelar.setBounds(10, 120, 100, 30);

        jButtonEditar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonEditar.setText("EDITAR");
        jButtonEditar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonEditar.setEnabled(false);
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonEditar);
        jButtonEditar.setBounds(10, 170, 100, 30);

        jButtonExcluir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonExcluir.setText("EXCLUIR");
        jButtonExcluir.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonExcluir.setEnabled(false);
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonExcluir);
        jButtonExcluir.setBounds(10, 220, 100, 30);

        jTableCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableCliente.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jTableCliente.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableClienteMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableCliente);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(120, 140, 280, 110);

        jTextFieldPesquisa.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldPesquisa);
        jTextFieldPesquisa.setBounds(120, 100, 160, 30);

        jButtonPesquisar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonPesquisar.setText("PESQUISAR");
        jButtonPesquisar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(290, 100, 110, 30);

        jTextFieldTelefoneCliente.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldTelefoneCliente.setEnabled(false);
        jPanel1.add(jTextFieldTelefoneCliente);
        jTextFieldTelefoneCliente.setBounds(240, 60, 160, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("ID");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(130, 20, 20, 30);

        jTextFieldCodCliente.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldCodCliente.setEnabled(false);
        jPanel1.add(jTextFieldCodCliente);
        jTextFieldCodCliente.setBounds(150, 20, 30, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 50, 420, 260);

        jLabelCad.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabelCad.setText("CADASTRO DE CLIENTES");
        getContentPane().add(jLabelCad);
        jLabelCad.setBounds(120, 10, 230, 30);

        setSize(new java.awt.Dimension(456, 355));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
    if(jTextFieldNomeCliente.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o nome para continuar");
            jTextFieldNomeCliente.requestFocus();
        }
        else if(jTextFieldTelefoneCliente.getText().isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Preencha o Telefone para continuar");
                jTextFieldTelefoneCliente.requestFocus();
            }
    if(flag==1)
        {
            mod.setNome(jTextFieldNomeCliente.getText());
            
            mod.setTelefone(jTextFieldTelefoneCliente.getText());        
            control.Salvar(mod);
            jTextFieldNomeCliente.setText("");
            jTextFieldTelefoneCliente.setText("");
            jTextFieldNomeCliente.setEnabled(false);
            jTextFieldTelefoneCliente.setEnabled(false);
            
            jButtonSalvar.setEnabled(false);
            jButtonCancelar.setEnabled(false);
            preencherTabela("select * from cliente order by cli_nome");
        }
    else
        {
            mod.setCodigo((Integer.parseInt(jTextFieldCodCliente.getText())));
            mod.setNome(jTextFieldNomeCliente.getText());
            
            mod.setTelefone(jTextFieldTelefoneCliente.getText());
            control.Editar(mod);
            jTextFieldNomeCliente.setEnabled(false);
            jTextFieldTelefoneCliente.setEnabled(false);
            
            jButtonSalvar.setEnabled(false);
            jButtonCancelar.setEnabled(false);  
            jTextFieldNomeCliente.setText("");
            jTextFieldTelefoneCliente.setText("");
            jTextFieldCodCliente.setText("");
            jTextFieldPesquisa.setText("");
            preencherTabela("select * from cliente order by cli_nome");
        }
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
    BeansCliente model = control.buscaCliente(mod);
    mod.setPesquisa(jTextFieldPesquisa.getText());
    jTextFieldNomeCliente.setText(model.getNome());
    jTextFieldTelefoneCliente.setText(String.valueOf(model.getTelefone()));
    jTextFieldCodCliente.setText(String.valueOf(model.getCodigo()));
    jButtonEditar.setEnabled(true);
    jButtonExcluir.setEnabled(true);
    jButtonNovo.setEnabled(false);
    jButtonSalvar.setEnabled(false);
    jTextFieldNomeCliente.setEnabled(false);
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
    flag = 1;
    jTextFieldNomeCliente.setEnabled(true);
    jTextFieldTelefoneCliente.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    jTextFieldNomeCliente.setText("");
    jTextFieldTelefoneCliente.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldCodCliente.setText("");
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
    jTextFieldNomeCliente.setEnabled(!true);
    jTextFieldTelefoneCliente.setEnabled(!true);
    jButtonSalvar.setEnabled(!true);
    jButtonCancelar.setEnabled(!true);
    jButtonNovo.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    jTextFieldNomeCliente.setText("");
    jTextFieldTelefoneCliente.setText("");
    jTextFieldCodCliente.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldPesquisa.setEnabled(true);
    jButtonPesquisar.setEnabled(true);
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jTableClienteMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableClienteMouseClicked
    String cli_nome = ""+jTableCliente.getValueAt(jTableCliente.getSelectedRow(), 1);
    conex.conexao();
    conex.executaSql("select * from cliente where cli_nome ='"+cli_nome+"'");
    try 
        {      
            conex.rs.first();
            jTextFieldCodCliente.setText(String.valueOf(conex.rs.getInt("cli_cod")));
            jTextFieldNomeCliente.setText(conex.rs.getString("cli_nome"));
            jTextFieldTelefoneCliente.setText(conex.rs.getString("cli_tel"));
        } 
    catch (SQLException ex) 
        {
                JOptionPane.showMessageDialog(rootPane, "Erro ao selecionar dados"+ex);
        }
    conex.desconecta();
    jButtonEditar.setEnabled(true);
    jButtonExcluir.setEnabled(true);
    }//GEN-LAST:event_jTableClienteMouseClicked

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
    int resposta = 0;
    resposta = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente excluir?");
    if(resposta==JOptionPane.YES_OPTION)
        {
            mod.setCodigo((Integer.parseInt(jTextFieldCodCliente.getText())));
            control.Excluir(mod);
            jButtonEditar.setEnabled(false);
            jButtonExcluir.setEnabled(false);
            jButtonCancelar.setEnabled(false);
            jButtonNovo.setEnabled(true);
            jTextFieldNomeCliente.setText("");
            jTextFieldTelefoneCliente.setText("");
            jTextFieldCodCliente.setText("");
            jTextFieldPesquisa.setText("");
            preencherTabela("select * from cliente order by cli_nome");
        }    
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
    flag = 2;
    jTextFieldNomeCliente.setEnabled(true);
    jTextFieldTelefoneCliente.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jButtonEditar.setEnabled(false);
    jButtonNovo.setEnabled(false);
    jButtonExcluir.setEnabled(false);
    }//GEN-LAST:event_jButtonEditarActionPerformed
    public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"id"
                                             ,"nome"
                                             ,"telefone"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{conex.rs.getInt("cli_cod")
                                                  ,conex.rs.getString("cli_nome")
                                                  ,conex.rs.getString("cli_tel")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTableCliente.setModel(modelo);
            jTableCliente.getColumnModel().getColumn(0).setPreferredWidth(37);
            jTableCliente.getColumnModel().getColumn(0).setResizable(false);
            
            jTableCliente.getColumnModel().getColumn(1).setPreferredWidth(140);
            jTableCliente.getColumnModel().getColumn(1).setResizable(false);
            
            jTableCliente.getColumnModel().getColumn(2).setPreferredWidth(100);
            jTableCliente.getColumnModel().getColumn(2).setResizable(false);
            
            jTableCliente.getTableHeader().setReorderingAllowed(false);
            jTableCliente.setAutoResizeMode(jTableCliente.AUTO_RESIZE_OFF);
            jTableCliente.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    public static void main(String args[]) 
        {
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                    {
                        new FormClientes().setVisible(true);
                    }
                });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabelCad;
    private javax.swing.JLabel jLabelCargo;
    private javax.swing.JLabel jLabelNome;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableCliente;
    private javax.swing.JTextField jTextFieldCodCliente;
    private javax.swing.JTextField jTextFieldNomeCliente;
    private javax.swing.JTextField jTextFieldPesquisa;
    private javax.swing.JTextField jTextFieldTelefoneCliente;
    // End of variables declaration//GEN-END:variables
}