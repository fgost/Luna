package ModeloDao;

import ModeloBeans.BeansEntrada;
import ModeloConection.ConexaoBD;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoEntrada 
    {
        ConexaoBD conex = new ConexaoBD();
        BeansEntrada mod = new BeansEntrada();
        
        public BeansEntrada buscaPorNome(BeansEntrada mod)
            {
                conex.conexao();
                conex.executaSql("select * from caixa where nome like '%"+mod.getPesquisa()+"%'");
                try 
                    {
                        conex.rs.first();
                        mod.setNome(conex.rs.getString("nome"));
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"não cadastrado!\n"+ex );
                    }
                conex.desconecta();
                return mod;
            }
        
         public BeansEntrada buscaPreco(BeansEntrada mod)
            {
                conex.conexao();
                conex.executaSql("select * from caixa where total ='"+mod.getPesquisa1()+"'");
                try  
                    {
                        conex.rs.first();
                        mod.setPreco(conex.rs.getInt("total"));
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"não cadastrado!\n"+ex );
                    }
                conex.desconecta();
                return mod;
            }  
    }