package ModeloDao;

import ModeloBeans.BeansCliente;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoCliente 
    {
        ConexaoBD conex = new ConexaoBD();
        BeansCliente mod = new BeansCliente();
    
        public void Salvar(BeansCliente mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("insert into cliente (cli_nome,cli_tel) values(?,?)");
                        pst.setString(1, mod.getNome());
                        pst.setString(2, mod.getTelefone()); 
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados inseridos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao inserir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public void Editar(BeansCliente mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("update cliente set cli_nome=?, cli_tel=? where cli_cod = ?");
                        pst.setString(1, mod.getNome());
                        pst.setString(2, mod.getTelefone()); 
                        pst.setInt(3, mod.getCodigo());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados alterados com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao atualizar dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public void Excluir(BeansCliente mod)
            {
                conex.conexao();
                try 
                    {
                        PreparedStatement pst = conex.con.prepareStatement("delete from cliente where cli_cod=?");
                        pst.setInt(1, mod.getCodigo());
                        pst.execute();
                        JOptionPane.showMessageDialog(null,"Dados excluidos com sucesso!");
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Erro ao excluir dados!\n"+ex );
                    }
                conex.desconecta();
            }
    
        public BeansCliente buscaCliente(BeansCliente mod)
            {
                conex.conexao();
                conex.executaSql("select * from cliente where cli_nome like '%"+mod.getPesquisa()+"%'");
                try 
                    {
                        conex.rs.first();
                        mod.setCodigo(conex.rs.getInt("cli_cod"));
                        mod.setNome(conex.rs.getString("cli_nome"));
                        mod.setTelefone(conex.rs.getString("cli_tel"));
                    } 
                catch (SQLException ex) 
                    {
                        JOptionPane.showMessageDialog(null,"Funcionario não cadastrado");
                    }
                conex.desconecta();
                return mod;
            }
    }
