package visao;

import ModeloBeans.BeansConta;
import ModeloBeans.ModeloTabela;
import ModeloConection.ConexaoBD;
import ModeloDao.DaoConta;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

public class FormContas extends javax.swing.JFrame 
    {
        BeansConta mod = new BeansConta();
        DaoConta dao = new DaoConta();
        ConexaoBD conex = new ConexaoBD();

    public FormContas() 
        {
            initComponents();
            preencherTipo();
            preencherTabela("select * from conta order by datas");
        }
     public void preencherTipo()
        {
            conex.conexao();
            conex.executaSql("select * from produto");
            try
                {
                    conex.rs.first();
                    jComboBoxTipo.removeAllItems();
                    do
                        {
                            jComboBoxTipo.addItem(conex.rs.getString("tipo_pro"));
                        }
                    while(conex.rs.next());
                }
            catch (SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher produto\n"+ex);
                }
            conex.desconecta();
        }    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldPesquisa = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jTextFieldPreco = new javax.swing.JTextField();
        jComboBoxTipo = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jButtonSalvar = new javax.swing.JButton();
        jButtonBuscar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jTextFieldCod = new javax.swing.JTextField();
        jTextFieldTotal = new javax.swing.JTextField();
        jButtonNovo = new javax.swing.JButton();
        jTextFieldNomeFornecedor = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jTextFieldQtd = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextFieldNome = new javax.swing.JTextField();
        jButtonTotal = new javax.swing.JButton();
        jTextFieldData = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jTextFieldStatus = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("PREÇO");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(120, 110, 60, 30);

        jTextFieldPesquisa.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldPesquisaActionPerformed(evt);
            }
        });
        jPanel1.add(jTextFieldPesquisa);
        jTextFieldPesquisa.setBounds(60, 210, 290, 30);

        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTablePesquisa);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(20, 250, 470, 150);

        jTextFieldPreco.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldPreco.setEnabled(false);
        jPanel1.add(jTextFieldPreco);
        jTextFieldPreco.setBounds(180, 110, 50, 30);

        jComboBoxTipo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jComboBoxTipo.setEnabled(false);
        jPanel1.add(jComboBoxTipo);
        jComboBoxTipo.setBounds(380, 60, 120, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("DATA");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(370, 10, 50, 30);

        jButtonSalvar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonSalvar.setText("SALVAR");
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSalvar);
        jButtonSalvar.setBounds(10, 110, 100, 30);

        jButtonBuscar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonBuscar.setText("buscar");
        jButtonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonBuscar);
        jButtonBuscar.setBounds(370, 210, 90, 30);

        jButtonCancelar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonCancelar.setText("CANCELAR");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonCancelar);
        jButtonCancelar.setBounds(10, 60, 100, 30);

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("ID");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(120, 60, 20, 30);

        jTextFieldCod.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldCod.setEnabled(false);
        jPanel1.add(jTextFieldCod);
        jTextFieldCod.setBounds(140, 60, 20, 30);

        jTextFieldTotal.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldTotal.setEnabled(false);
        jPanel1.add(jTextFieldTotal);
        jTextFieldTotal.setBounds(450, 110, 50, 30);

        jButtonNovo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonNovo.setText("NOVO");
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonNovo);
        jButtonNovo.setBounds(10, 10, 100, 30);

        jTextFieldNomeFornecedor.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldNomeFornecedor.setEnabled(false);
        jPanel1.add(jTextFieldNomeFornecedor);
        jTextFieldNomeFornecedor.setBounds(220, 10, 140, 30);

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("FORNECEDOR");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(120, 10, 100, 30);

        jTextFieldQtd.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldQtd.setEnabled(false);
        jPanel1.add(jTextFieldQtd);
        jTextFieldQtd.setBounds(290, 110, 50, 30);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("QTD");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(240, 110, 40, 30);

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("NOME");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(170, 60, 40, 30);

        jTextFieldNome.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTextFieldNome.setEnabled(false);
        jPanel1.add(jTextFieldNome);
        jTextFieldNome.setBounds(220, 60, 110, 30);

        jButtonTotal.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButtonTotal.setText("total");
        jButtonTotal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonTotalActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonTotal);
        jButtonTotal.setBounds(350, 110, 90, 30);

        jTextFieldData.setEnabled(false);
        jPanel1.add(jTextFieldData);
        jTextFieldData.setBounds(420, 10, 80, 30);

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("TIPO");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(340, 60, 30, 30);

        jTextFieldStatus.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(jTextFieldStatus);
        jTextFieldStatus.setBounds(210, 150, 230, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("STATUS");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(130, 150, 60, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 50, 510, 420);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel1.setText("Contas a pagar");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(190, 0, 190, 40);

        setSize(new java.awt.Dimension(548, 542));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBuscarActionPerformed
    preencherTabela("select * from conta where nome like '%"+jTextFieldPesquisa.getText()+"%' order by datas");        
    }//GEN-LAST:event_jButtonBuscarActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
    jTextFieldPesquisa.setEnabled(true);
    jTextFieldPreco.setEnabled(true);
    jComboBoxTipo.setEnabled(true);
    jTextFieldTotal.setEnabled(true);
    jTextFieldData.setEnabled(true);
    jButtonSalvar.setEnabled(true);
    jButtonCancelar.setEnabled(true);
    jTextFieldNomeFornecedor.setEnabled(true);
    jTextFieldQtd.setEnabled(true);
    
    jButtonBuscar.setEnabled(true);
    jTextFieldNome.setEnabled(true);
    
    jTextFieldPesquisa.setText("");
    jTextFieldPreco.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldCod.setText("");
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jTextFieldPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldPesquisaActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
    jTextFieldTotal.setEnabled(!true);
    jTextFieldPreco.setEnabled(!true);
    jComboBoxTipo.setEnabled(!true);
    jButtonSalvar.setEnabled(!true);
    jButtonCancelar.setEnabled(!true);
    jTextFieldData.setEnabled(!true);
    jButtonNovo.setEnabled(true);
    
    jTextFieldTotal.setText("");
    jTextFieldPreco.setText("");
    jTextFieldCod.setText("");
    jTextFieldPesquisa.setText("");
    jTextFieldPesquisa.setEnabled(true);
    jButtonBuscar.setEnabled(true);
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
    if(jTextFieldTotal.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o nome para continuar");
            jTextFieldTotal.requestFocus();
        }
    else if(jTextFieldPreco.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(null, "Preencha o Telefone para continuar");
            jTextFieldPreco.requestFocus();
        }
    
    mod.setNome(jTextFieldNome.getText());
    mod.setTipo((String)(jComboBoxTipo.getSelectedItem()));
    mod.setData( jTextFieldData.getText());
    mod.setPreco(Double.parseDouble(jTextFieldPreco.getText()));
    mod.setFornecedor(jTextFieldNomeFornecedor.getText());
    mod.setQtd(Integer.parseInt(jTextFieldQtd.getText()));
    mod.setTotal(Double.parseDouble(jTextFieldTotal.getText()));
    mod.setStatus(jTextFieldStatus.getText());
    
    dao.Salvar(mod);
    jTextFieldTotal.setText("");
    jTextFieldPreco.setText("");
    jTextFieldTotal.setEnabled(false);
    jTextFieldPreco.setEnabled(false);
    jComboBoxTipo.setEnabled(false);
    jButtonSalvar.setEnabled(false);
    jButtonCancelar.setEnabled(false);
    preencherTabela("select * from conta order by datas");   
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonTotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonTotalActionPerformed
    int v1 = Integer.parseInt(jTextFieldQtd.getText());
    double v2 = Double.parseDouble(jTextFieldPreco.getText());
    
    double r = v1 * v2;
    
    jTextFieldTotal.setText(String.valueOf(r));  
    }//GEN-LAST:event_jButtonTotalActionPerformed
    public void preencherTabela (String Sql)
        {
            ArrayList dados = new ArrayList();
            String [] colunas = new String []{"ID"
                                             ,"NOME"
                                             ,"TIPO"
                                             ,"FORNECEDOR"
                                             ,"PREÇO"
                                             ,"QTD"
                                             ,"TOTAL"
                                             ,"DATA"
                                             ,"STATUS"};
            conex.conexao();
            conex.executaSql(Sql);
            try
                {
                    conex.rs.first();
                    do
                        {
                            dados.add(new Object[]{  conex.rs.getInt("cod")
                                                    ,conex.rs.getString("nome")
                                                    ,conex.rs.getString("tipo")
                                                    ,conex.rs.getString("fornecedor")
                                                    ,conex.rs.getDouble("preco")
                                                    ,conex.rs.getInt("qtd")
                                                    ,conex.rs.getDouble("total")
                                                    ,conex.rs.getString("datas")
                                                    ,conex.rs.getString("status")});
                        }
                    while(conex.rs.next());
                }
            catch(SQLException ex)
                {
                    JOptionPane.showMessageDialog(rootPane, "Erro ao preencher dados\n"+ex);
                }
            ModeloTabela modelo = new ModeloTabela(dados, colunas);
            jTablePesquisa.setModel(modelo);
            
            jTablePesquisa.getColumnModel().getColumn(0).setPreferredWidth(35);
            jTablePesquisa.getColumnModel().getColumn(0).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(1).setPreferredWidth(110);
            jTablePesquisa.getColumnModel().getColumn(1).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(2).setPreferredWidth(85);
            jTablePesquisa.getColumnModel().getColumn(2).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(3).setPreferredWidth(100);
            jTablePesquisa.getColumnModel().getColumn(3).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(4).setPreferredWidth(80);
            jTablePesquisa.getColumnModel().getColumn(4).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(5).setPreferredWidth(40);
            jTablePesquisa.getColumnModel().getColumn(5).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(6).setPreferredWidth(110);
            jTablePesquisa.getColumnModel().getColumn(6).setResizable(false);
            
            jTablePesquisa.getColumnModel().getColumn(7).setPreferredWidth(75);
            jTablePesquisa.getColumnModel().getColumn(7).setResizable(false);
            
            jTablePesquisa.getTableHeader().setReorderingAllowed(false);
            jTablePesquisa.setAutoResizeMode(jTablePesquisa.AUTO_RESIZE_OFF);
            jTablePesquisa.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            conex.desconecta();
        }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) 
        {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormContas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormContas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormContas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormContas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
            java.awt.EventQueue.invokeLater(new Runnable() 
                {
                    public void run() 
                        {
                            new FormContas().setVisible(true);
                        }
                });
        }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonBuscar;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JButton jButtonTotal;
    private javax.swing.JComboBox<String> jComboBoxTipo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextFieldCod;
    private javax.swing.JTextField jTextFieldData;
    private javax.swing.JTextField jTextFieldNome;
    private javax.swing.JTextField jTextFieldNomeFornecedor;
    private javax.swing.JTextField jTextFieldPesquisa;
    private javax.swing.JTextField jTextFieldPreco;
    private javax.swing.JTextField jTextFieldQtd;
    private javax.swing.JTextField jTextFieldStatus;
    private javax.swing.JTextField jTextFieldTotal;
    // End of variables declaration//GEN-END:variables
}