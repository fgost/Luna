package ModeloDao;

import ModeloBeans.BeansAgenda;
import ModeloConection.ConexaoBD;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DaoAgenda {
    BeansAgenda  agenda = new BeansAgenda();
    ConexaoBD conex = new ConexaoBD();
    ConexaoBD conexCli = new ConexaoBD();
    ConexaoBD conexFun = new ConexaoBD();
    int codCli;
    int codFun;
    
    public void Salvar(BeansAgenda agenda)
        {
            buscaCliente(agenda.getNomeCliente());
            buscaFuncionario(agenda.getNomeBarbeiro());
            conex.conexao();
            try 
                {   
                    PreparedStatement pst = conex.con.prepareStatement("insert into agenda (codcli_agenda,hora_agenda,codfuncionario_agenda,datas,serviço_agenda,barbeiro) values (?,?,?,?,?,?)");
                    pst.setInt(1, codCli);   
                    pst.setString(2, agenda.getHora());
                    pst.setInt(3, codFun);            
                    pst.setString(4, agenda.getData());
                    pst.setString(5, agenda.getServiço());
                    pst.setString(6, agenda.getNomeBarbeiro()); 
                    pst.execute();
                    JOptionPane.showMessageDialog(null,"Agendado com Sucesso");
                }     
            catch (SQLException ex) 
                {
                    JOptionPane.showMessageDialog(null,"Erro ao Gerar Agendamento!\n"+ex );
                }
            conex.desconecta();
        }
    public void buscaFuncionario(String nomeBarbeiro){
    conexFun.conexao();
    conexFun.executaSql("select * from  funcionario where nome_funcionario like '%"+nomeBarbeiro+"%'");
        try {
            conexFun.rs.first();
            codFun=conexFun.rs.getInt("cod_funcionario");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Barbeiro não encontrado!\n"+ex );
        }
}
    public void buscaCliente(String nomeCliente)
        {
            conexCli.conexao();
            conexCli.executaSql("select * from  cliente where cli_nome='"+nomeCliente+"'");
            try {
            conexCli.rs.first();
            codCli=conexCli.rs.getInt("cli_cod");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Cliente não encontrado!\n"+ex );
        }
}
    
}
